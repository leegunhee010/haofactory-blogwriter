# -*- coding: utf-8 -*-
"""
하오팩토리 블로그 작성기 — Claude Code(각자 Max/Pro 구독)로 글 생성
=====================================================================
- 탭 여러 개 = 한 번에 여러 글
- 키워드 직접 입력 또는 통검 글감추천에서 자동삽입
- 사진 폴더 지정 → 그 안 사진을 (사진N) 자리에 자동 배치
- 생성 → 미리보기 → 워드 저장(사진 박힌 채) → 네이버 복붙
엔진: claude.exe -p (각자 자기 구독으로 인증, API 종량제 아님)
실행: 작성기_실행.bat → http://127.0.0.1:5002
"""
import os, sys, json, glob, shutil, subprocess, threading, time, webbrowser, re, datetime, random, hashlib
from flask import Flask, request, jsonify, send_file


# ── CRM 성과추적: 제목 기반 추적키(CRM 피드/포스터와 동일 공식: 엔티티6종복원+공백정리+md5앞16) ──
CRM_GO = "http://mail-crm-mvp.vigo.co.kr/go/"


def crm_track_key(title, prefix="fd"):
    s = title or ""
    for a, b in (("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&#39;", "'"), ("&#039;", "'"), ("&nbsp;", " ")):
        s = s.replace(a, b)
    s = re.sub(r"\s+", " ", s).strip()
    return (prefix or "fd") + hashlib.md5(s.encode("utf-8")).hexdigest()[:16]


def crm_line(brand, title):
    """브랜드별 CRM 추적링크 줄. crm_on=True + crm_prefix 있는 브랜드만. 아니면 ''.
    crm_mode='go'  → CRM 서버 경유(/go/키) — 홈페이지에 분석 도구가 없어 서버가 직접 클릭을 세는 브랜드(dfirst).
    crm_mode='utm' → 브랜드 홈페이지로 바로(UTM + content_키) — 홈페이지 GA4/GTM이 유입을 기록하는 브랜드."""
    b = brand or {}
    prefix = (b.get("crm_prefix") or "").strip()
    if not (b.get("crm_on") and prefix and (title or "").strip()):
        return ""
    label = (b.get("crm_label") or "문의").strip()
    key = crm_track_key(title, prefix)
    if (b.get("crm_mode") or "go").strip() == "utm":
        home = (b.get("homepage") or "").strip().rstrip("/")
        if not home:
            return ""
        url = "%s/?utm_source=naver&utm_medium=post&utm_campaign=content_%s" % (home, key)
    else:
        url = CRM_GO + key
    return "▶ %s: %s" % (label, url)


def _crm_notify_cfg():
    """CRM 게시 보고용 url/token. 우선순위: 앱 폴더 crm-notify.config.json → C:/firstd-control/crm-notify.config.json."""
    for cp in (os.path.join(HERE, "crm-notify.config.json"), r"C:\firstd-control\crm-notify.config.json"):
        try:
            if os.path.isfile(cp):
                c = json.load(open(cp, encoding="utf-8"))
                if c.get("url") and c.get("token"):
                    return c
        except Exception:
            pass
    return None


def crm_report_post(brand, title, keyword, url):
    """게시 완료를 CRM '게시 현황'으로 보고(firstd-control crm-notify와 같은 ingest·payload).
    네이버 수동 게시용 — 실패해도 예외 없이 (ok, msg)만 반환."""
    import urllib.request as _ur
    cfg = _crm_notify_cfg()
    if not cfg:
        return False, "CRM 설정 파일(crm-notify.config.json)을 찾지 못했습니다."
    m = re.search(r"blog\.naver\.com/([A-Za-z0-9_-]+)(?:/(\d+))?", url or "")
    account = m.group(1) if m else "naver"
    log_no = (int(m.group(2)) % 10**9) if (m and m.group(2)) else 0   # logNo 뒤 9자리(CRM blog_no가 int32라 전체 값은 넘침) → 게시물별 키
    payload = {"platform": "naver", "blog_no": log_no, "account": account,
               "category": "", "keyword": keyword or "", "title": title or "",
               "url": (url or "").strip(), "score": None,
               "status": "posted", "posted_at": datetime.datetime.now().isoformat()}
    try:
        req = _ur.Request(cfg["url"], data=json.dumps(payload).encode("utf-8"),
                          headers={"Content-Type": "application/json", "X-CRM-Token": cfg["token"]}, method="POST")
        with _ur.urlopen(req, timeout=10) as r:
            ok = r.status == 200
            return ok, (r.read().decode("utf-8", "ignore")[:200] if not ok else "보고 완료")
    except Exception as e:
        return False, str(e)[:200]

FROZEN = getattr(sys, "frozen", False)
HERE = os.path.dirname(sys.executable) if FROZEN else os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, "출력")
os.makedirs(OUT_DIR, exist_ok=True)
CFG_FILE = os.path.join(HERE, "작성기_설정.json")
TEMPLATE = os.path.join(HERE, "템플릿", "카드뉴스_템플릿.pptx")
sys.path.insert(0, HERE)
import cardnews_pil  # noqa  (순수 Pillow 엔진 — PowerPoint 불필요)
import brands  # noqa  (브랜드 설정 관리)
import charts_pil  # noqa  (C6: 내용 기반 표·차트 이미지)

CARD_JOBS = {}
CARD_LOCK = threading.Lock()


CARD_SRC_DIR = "원본사진"


def sync_card_sources(cdir):
    """카드뉴스 폴더 안 '원본사진/'에 지금 카드에 들어간 원본 사진을 파일째 복사해 둔다(카드N_원본파일명).
    cards.json의 src 기준 = 사용자가 사진 교체한 결과가 그대로 반영된다. 폴더를 옮겨도 사진이 함께 따라간다.
    앱이 만든 '카드N_' 파일만 정리하고, 사용자가 넣은 다른 파일은 건드리지 않는다. 실패해도 조용히 넘어감."""
    try:
        st = jload(os.path.join(cdir, "cards.json"), {})
        want = {}
        for i, c in enumerate(st.get("cards") or [], 1):
            src = (c.get("src") or "").strip()
            if src and os.path.isfile(src):
                want["카드%d_%s" % (i, os.path.basename(src))] = src
        if not want:
            return
        out = os.path.join(cdir, CARD_SRC_DIR)
        os.makedirs(out, exist_ok=True)
        for f in os.listdir(out):
            if re.match(r"^카드\d+_", f) and f not in want:
                try:
                    os.remove(os.path.join(out, f))      # 교체 전 사진 정리
                except Exception:
                    pass
        for name, src in want.items():
            dst = os.path.join(out, name)
            if not os.path.isfile(dst):
                shutil.copy2(src, dst)
    except Exception:
        pass


def _cardnews_job(jid, photo_paths, cards, keyword, assets_dir, subtitle="", bodies=None, title="", chart_specs=None, table_w=None):
    try:
        safe = re.sub(r'[\\/:*?"<>|]', "_", keyword)
        stamp = datetime.datetime.now().strftime("%H%M%S%f")[:9]
        png_dir = os.path.join(OUT_DIR, f"{safe}_카드뉴스_{stamp}")
        res = cardnews_pil.make_cards(photo_paths, cards[:7], png_dir, assets_dir,
                                      subtitle=subtitle, bodies=bodies, title=title)   # 순수 PIL, 즉시
        srcs = [c["src"] for c in res["cards"]]
        sync_card_sources(png_dir)                    # 원본사진/ 에 카드 원본 복사
        # C6: 표·차트를 카드뉴스 색으로 렌더(cards.json accent 사용) → cid별 파일명 반환
        chart_imgs = {}
        if chart_specs:
            col = article_color(png_dir, None) or _hex_rgb(res.get("theme", ""))
            for cid, spec in chart_specs.items():
                try:
                    nm = "chart_%s.png" % cid
                    charts_pil.render_spec(os.path.join(png_dir, nm), spec, col, W=table_w)
                    chart_imgs[cid] = nm
                except Exception:
                    pass
        CARD_JOBS[jid] = {"status": "done", "pngs": res["pngs"], "dir": png_dir, "srcs": srcs,
                          "cards": res["cards"], "chart_imgs": chart_imgs}
    except Exception as e:
        CARD_JOBS[jid] = {"status": "error", "msg": str(e)[:200]}

# 통검 데이터(글감추천용) 기본 경로 — 하오팩토리 통검체크 dist
DEFAULT_TONGGEOM = r"C:/Users/이건희/trevity-노출체크/dist/하오팩토리 통검체크"

app = Flask(__name__)


def jload(p, d):
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return d


def load_cfg():
    c = jload(CFG_FILE, {})
    c.setdefault("tonggeom_dir", DEFAULT_TONGGEOM)
    c.setdefault("brand_name", "하오팩토리")
    c.setdefault("model", "opus")  # 품질 우선(기본). sonnet은 더 빠름
    return c


# ── claude.exe 자동 탐지 ────────────────────────────────
def find_claude():
    p = shutil.which("claude")
    if p:
        return p
    pats = [
        # 데스크톱 앱 번들 — 2026-10 업데이트로 버전 폴더 아래 해시 폴더가 하나 더 생겼다(둘 다 찾는다)
        os.path.expanduser(r"~/AppData/Local/Packages/Claude_*/LocalCache/Roaming/Claude/claude-code/*/*/claude.exe"),
        os.path.expanduser(r"~/AppData/Local/Packages/Claude_*/LocalCache/Roaming/Claude/claude-code/*/claude.exe"),
        os.path.expanduser(r"~/AppData/Roaming/Claude/claude-code/*/*/claude.exe"),
        os.path.expanduser(r"~/AppData/Roaming/Claude/claude-code/*/claude.exe"),
        os.path.expanduser(r"~/.local/bin/claude.exe"),
        os.path.expanduser(r"~/AppData/Roaming/npm/claude.cmd"),
    ]
    hits = []
    for g in pats:
        hits += glob.glob(g)
    if not hits:
        return None
    # 최근에 설치된 것(수정 시각 최신) 우선 — 버전 폴더 이름 정렬보다 안전
    try:
        hits.sort(key=lambda f: os.path.getmtime(f))
    except Exception:
        hits.sort()
    return hits[-1]


CLAUDE = find_claude()


# ── 멀티 Claude 계정 (CLAUDE_CONFIG_DIR로 계정별 분리) ───
# 각 계정은 accounts/<id>/ 폴더 = 그 계정의 CLAUDE_CONFIG_DIR(자격증명 격리).
# "default" 계정은 dir 비움 → 기존 ~/.claude 그대로 사용(앱 최초 동작 보존).
ACCOUNTS_DIR = os.path.join(HERE, "accounts")
ACCOUNTS_FILE = os.path.join(HERE, "accounts.json")
# 사용 한도/요금 한도 도달 메시지 패턴(자동 다른 계정 전환 트리거)
_LIMIT_PAT = re.compile(
    r"(spend limit|usage limit|rate limit|monthly .{0,20}limit|hit your .{0,20}limit|"
    r"limit.{0,40}claude\.ai|reached your|out of .{0,15}usage|사용 한도|한도에 도달|한도를 초과)", re.I)

# 인증 실패 패턴(토큰 만료·철회 등) — 이 경우도 다른 로그인 계정으로 자동 전환, 안 되면 재로그인 안내
_AUTH_FAIL_PAT = re.compile(
    r"(Failed to authenticate|OAuth[^\n]{0,40}(expired|revoked|invalid)|invalid_grant|"
    r"authentication[_ ]error|could not be refreshed|re-?authenticat|token[^\n]{0,20}expired)", re.I)


def load_accounts():
    d = jload(ACCOUNTS_FILE, {})
    accts = d.get("accounts") or []
    if not any(a.get("id") == "default" for a in accts):
        accts.insert(0, {"id": "default", "label": "기본 계정", "dir": ""})
    active = d.get("active") or "default"
    if not any(a.get("id") == active for a in accts):
        active = "default"
    return {"accounts": accts, "active": active}


def save_accounts(d):
    try:
        json.dump(d, open(ACCOUNTS_FILE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    except Exception:
        pass


def account_env(acc_id=None):
    """해당 계정의 CLAUDE_CONFIG_DIR 적용된 env. dir 비면 기본(~/.claude)."""
    d = load_accounts()
    if acc_id is None:
        acc_id = d["active"]
    acc = next((a for a in d["accounts"] if a.get("id") == acc_id), None)
    env = os.environ.copy()
    if acc and acc.get("dir"):
        os.makedirs(acc["dir"], exist_ok=True)
        env["CLAUDE_CONFIG_DIR"] = acc["dir"]
    else:
        env.pop("CLAUDE_CONFIG_DIR", None)
    return env


def auth_status_of(acc_id):
    """계정별 로그인 상태(dict: loggedIn/email/subscriptionType ...)."""
    if not CLAUDE:
        return {}
    try:
        r = subprocess.run([CLAUDE, "auth", "status"], capture_output=True, text=True,
                           encoding="utf-8", errors="ignore", timeout=25, env=account_env(acc_id))
        return json.loads(r.stdout or "{}")
    except Exception:
        return {}


# ── 하오팩토리 문체 프롬프트 ─────────────────────────────
STYLE = """너는 조형물 제작 회사 '하오팩토리(HAOFACTORY)'의 네이버 블로그 글을 쓰는 전문 카피라이터다.
[문체 규칙]
- 차분하고 현장감 있는 실무자 톤. 과장·AI티('~에 대해 알아보겠습니다' 등)·이모지 금지.
- 한 문장(또는 의미단위)마다 줄바꿈(네이버 모바일 가독성). 종결은 ~합니다/~됩니다 위주.
- 도입: "안녕하세요." + 한 줄 소개 + "하오팩토리입니다." 로 시작.
- 넘버링 소제목 **정확히 6개**(개요/요구사항/설계/공정/설치/결과 흐름). 소재 비교(금속·FRP·EPS) 자연스럽게.
- 마무리: "~ 고민되는 경우라면 HAOFACTORY로 편하게 문의 주셔도 좋습니다."
[SEO 규칙]
- 분량은 공백 제외 1,500~2,000자(★2,000자 절대 초과 금지 — 넘칠 것 같으면 군더더기를 덜어낸다).
- 제목에 메인키워드 포함. 본문에 메인키워드 5~8회 자연스럽게(억지 반복 금지).
[출력 형식 — 정확히 이 형식만, 다른 설명/머리말 금지]
제목: (메인키워드 포함한 제목)
(사진1: 파일명)
본문 도입...
**1. 소제목**
(사진2: 파일명)
본문...
(... 정확히 6개 소제목, 각 소제목 아래 사진 1장씩 ...)
★(사진)은 **정확히 7개**: 도입 1장(사진1) + 소제목 6개 각 1장(사진2~사진7). 카드뉴스 7장과 1:1로 맞춘다. 더도 덜도 말 것.
규칙: 사진은 아래 '사용 사진' 목록의 파일명만 (사진N: 정확한파일명) 형태로 배치. 목록에 없는 파일명 만들지 말 것.
★중요: **각 (사진N) 슬롯에는 서로 다른 사진**을, 그 단락 내용(개요/설계/공정/설치/완성 등)에 **가장 어울리는 사진**으로 배치하라. 같은 사진을 두 번 쓰지 말 것. 파일명에 단계 힌트(대표/공정/설치/완성/도장 등)가 있으면 그 단락에 맞춰라.

[카드뉴스 헤드라인]
원고를 다 쓴 뒤, 맨 끝에 아래 형식으로 카드 7장 헤드라인을 출력하라(짧고 강하게, 각 12자 내외, 본문 흐름 요약):
카드뉴스:
1. (메인키워드 그대로 — 표지)
2. (포토존/공간 후킹)
3. (기획/설계 이유)
4. (안전성/구조)
5. (소재/입체감)
6. (설치/현장)
7. (전문회사 선택 마무리)"""


# 매 생성마다 '표현·각도'만 살짝 바꾸는 변주 풀(구조·톤은 건드리지 않음)
_VAR_HOOK = ["고객이 자주 하는 고민·질문을 짚으며", "흔한 오해 하나를 바로잡으며",
             "실제 현장 장면을 그리듯", "핵심 결론을 먼저 던진 뒤 풀어가며",
             "예전 방식과 지금을 비교하며", "비슷한 고민을 했던 사례를 떠올리게 하며"]
_VAR_SUB = ["질문형 소제목 위주로", "단정·선언형 소제목 위주로",
            "호기심을 자극하는 소제목으로", "핵심 키워드 + 짧은 구절형 소제목으로"]
_VAR_EMPH = ["왜 필요한지(필요성)", "흔한 실수·실패 사례", "선택 기준과 체크포인트",
             "작업 과정과 디테일", "결과와 효과", "자주 묻는 질문 관점", "비용·기간의 현실"]
_VAR_RHYTHM = ["사례 중심으로", "실용 정보·팁 중심으로", "공감·스토리 중심으로"]
_VAR_KIND = ["비교·선택형(두세 가지 선택지를 놓고 고르는 기준을 세운다)",
             "순서·일정 역산형(마감일에서 거꾸로 짚어 단계별 결정을 보여준다)",
             "계산·견적형(부수·면수·평량 같은 숫자를 실제로 계산해 보인다)",
             "사례·장면형(하나의 의뢰 장면을 따라가며 판단 지점을 짚는다)",
             "오해 바로잡기형(흔히 믿는 것과 실제 결과를 맞대어 본다)",
             "점검·체크형(발주 전에 확인할 지점을 위험도 순으로 짚는다)"]
_VAR_FLOW = ["두 선택지 비교 → 결론", "숫자 계산 과정을 한 단계씩 풀기", "작업 순서대로 따라가기",
             "구체 장면 하나를 깊게 풀기", "흔한 오해 → 실제 결과", "놓치기 쉬운 점검 포인트 짚기",
             "독자 질문 → 짧은 답 → 이유"]
_VAR_OPEN = ["숫자로 바로 시작하는 결론", "`~라면` 조건문 결론", "정의 한 문장", "`A보다 B가 먼저` 대비",
             "현장 장면 한 줄 뒤 결론", "독자 질문에 대한 한 줄 답", "결과부터 말하고 이유는 뒤로"]
_VAR_FORMAT = ["핵심을 단계별로 짚는 가이드형", "궁금증을 하나씩 풀어주는 Q&A형",
               "준비물·확인사항을 점검하는 체크리스트형", "실제 상황·사례를 중심으로 풀어가는 사례형",
               "하나의 개념을 깊이 파고드는 심층형", "경우·선택지를 비교해 보여주는 비교형"]


def _variation_block(brand=None):
    emph = random.sample(_VAR_EMPH, 2)
    if brand and brands.custom_prompt(brand):
        # 완전 커스텀 스크립트(prompt.md) 브랜드: 고정되는 건 '필수 요소'(요약 블록·소제목 개수·Q&A·CTA)뿐.
        # 글 성격·소제목 전개·첫 문장 형태는 매번 앱이 무작위로 달리 지정 → 글끼리 같은 뼈대로 수렴하는 것을 막는다.
        kind = random.choice(_VAR_KIND)
        flows = random.sample(_VAR_FLOW, 5)
        opens = random.sample(_VAR_OPEN, 5)
        plan = "\n".join("  · 소제목 %d: 전개 = %s / 첫 문장 형태 = %s" % (i + 1, flows[i], opens[i]) for i in range(5))
        return ("[이번 글 변주 — 필수 요소(① 요약 블록·소제목 6개·표·Q&A·CTA)는 지키되, 글의 뼈대는 아래 지정대로 이번 글만의 것으로 짠다]\n"
                f"- 이번 글의 성격: {kind}. 소제목 5개의 순서와 역할을 이 성격에 맞춰 설계한다.\n"
                "- 소제목별 전개·첫 문장 형태(내용에 도저히 안 맞으면 그 소제목만 가장 가까운 다른 형태로 바꿔도 된다. 단 5개가 같은 모양이 되면 안 된다):\n"
                + plan + "\n"
                f"- 이번 글은 특히 '{emph[0]}'·'{emph[1]}' 관점을 조금 더 살린다.\n"
                "- ★가장 중요: 이전 글의 문장·소제목 문구·소제목 흐름·예시·비유·경험 장면을 재활용해 '단어만 바꾸는' 식으로 쓰지 말 것. "
                "같은 키워드·같은 정보라도 이번 독자 상황·사진에서 출발해 매번 완전히 다른 글처럼 읽히게 한다.")
    ffp = brands.final_faq_promo(brand)
    return ("[이번 글 변주 — '구성·표현·각도'를 매번 새롭게 하기 위한 지시다. "
            + ("블로그 뼈대(도입 인사 → 소제목 정확히 6개, 첫째~셋째 = 정보, 넷째·다섯째 = 정보+브랜드 홍보, 여섯째 = FAQ 3~4개+브랜드 홍보+후킹 CTA)·브랜드 톤·정체성·키워드 SEO 규칙은 지키되, "
               if ffp else "블로그 뼈대(도입 인사 → 소제목 정확히 6개 → 마무리)·브랜드 톤·정체성·키워드 SEO 규칙은 지키되, ") +
            "그 안에서 쓰는 방식은 매번 확실히 다르게 한다.]\n"
            f"- 이번 글은 {random.choice(_VAR_FORMAT)}으로 전개한다(6개 소제목의 구성·순서·풀어가는 방식을 이 접근에 맞춘다).\n"
            f"- 도입은 {random.choice(_VAR_HOOK)} 시작하고, 소제목은 {random.choice(_VAR_SUB)} 구성한다.\n"
            f"- 이번 글은 특히 '{emph[0]}'·'{emph[1]}' 관점을 조금 더 살리고, 전체 전개는 {random.choice(_VAR_RHYTHM)} 풀어간다.\n"
            "- ★가장 중요: 이전 글의 구조·문장·소제목 문구·예시·비유를 재활용해 '단어만 바꾸는' 식으로 쓰지 말 것. "
            "같은 키워드·같은 정보라도 첫 문장·소제목·설명 순서·예시·비유를 전부 새로 짜서, 매번 완전히 다른 글처럼 읽히게 한다.\n"
            + ("- 넷째~여섯째 소제목의 브랜드 홍보·CTA도" if ffp else "- 마무리의 브랜드 소개도") +
            " 정형화된 나열을 복붙하지 말고, 이번 글 주제와 연결해 다른 문장·다른 순서·다른 강조점으로 매번 새롭게 쓴다.")


# 가장 중요한 규칙은 프롬프트 맨 끝(작성 직전)에 다시 못박는다 — 긴 기준서에 묻히지 않게.
_CORE_RULES = ("[★★반드시 지킬 핵심 — 이 글의 품질을 좌우한다]\n"
               "1. 제목과 본문이 딱 맞아야 한다: 본문 전체가 제목이 약속한 주제에 답하고, 제목과 동떨어진 내용은 넣지 않는다.\n"
               "2. 각 소제목과 그 아래 본문이 정확히 일치해야 한다: 소제목이 말하는 그 하나의 주제만 그 문단에서 다룬다(소제목과 상관없는 딴 얘기·범위 이탈 금지).\n"
               "3. 매번 구조를 다르게: 지난 글과 같은 소제목 순서·같은 문장 틀·같은 예시·같은 비유를 재사용하지 말고, 이번 글만의 흐름으로 새로 짠다. 뻔한 '개요→절차→비용' 반복을 피한다.")


def _portfolio_prompt(keyword, photo_files, photo_paths, project_hint, brand, title):
    """포트폴리오 모드 — 실제 프로젝트 사례 글. 사진을 직접 열어보고(Read) 쓰고, 각 사진에 alt 텍스트를 붙인다."""
    b = brand or {}
    name = b.get("name", "")
    identity = b.get("identity", "")
    tone = b.get("tone", "")
    cta = (b.get("cta", "") or "").replace("{name}", name)
    fnames = ", ".join(photo_files or []) or "(없음)"
    read_list = "\n".join(f"- {p}" for p in (photo_paths or [])[:7]) or "(사진 없음)"
    hintblk = (f"\n[프로젝트 추가 정보 — 사진으로 알 수 없는 사실(고객·기관·요청·특이사항)]\n{project_hint.strip()}\n"
               "- 이 정보와 사진에서 '실제로 확인되는 것'만 쓴다. 모르는 건 지어내지 말 것."
               if (project_hint or "").strip() else
               "\n[프로젝트 추가 정보 없음] — 사진에서 실제로 보이는 것과 메인키워드가 가리키는 분야·산출물에 근거해서만 쓰고, 없는 사실(고객명·수치 등)은 지어내지 말 것.")
    titleblk = (f"\n[제목 — 이 제목을 그대로 사용]\n{title.strip()}" if (title or "").strip() else "")
    ffp = brands.final_faq_promo(b)
    head = (
        f"너는 '{name}'의 블로그에 '실제 진행한 한 프로젝트'를 사례로 보여주는 포트폴리오 글을 쓰는 전문 카피라이터다.\n"
        f"[회사 소개] {identity}\n"
        f"[문체·톤] {tone}\n"
        "[이 글의 목적] 이 프로젝트로 회사의 실력·서비스·강점을 '증명'하고, 그 분야(산업)의 실무 인사이트를 더해 딱 그 타겟 고객에게 노출·신뢰를 얻는다(AEO·GEO·SEO 최적화). "
        "★소설·스토리텔링처럼 흐르지 말 것 — 그런 글엔 아무도 관심 없다. '과정·디자인 판단·분야 노하우'로 증명한다.\n\n"
        "[★★사진을 실제로 열어보고 쓴다 — 가장 중요]\n"
        "- 아래 사진 파일들을 Read 도구로 하나씩 실제로 열어, 무엇인지(산출물 종류=카탈로그/브로슈어/리플렛/패키지 등·색감·구성·언어·분위기)를 직접 확인한 뒤 그 내용에 근거해 쓴다. 사진과 동떨어진 상상 금지.\n"
        f"{read_list}\n"
        "- 각 사진은 어울리는 단락에 (사진N: 파일명) 으로 배치하고, ★바로 다음 줄에 [alt: 그 이미지 설명] 을 한 줄 넣는다(그 사진이 무엇인지 + 메인키워드/타겟 포함, 12~30자). 예: [alt: 삼성병원 내과 브로슈어 표지 디자인]\n"
        f"- 파일명은 이 목록 그대로만: {fnames}\n\n"
        "[★타겟이 AI에 던질 '진짜 질문'을 먼저 정하라 — 이 글은 그 답이다]\n"
        "이 글을 볼 사람이 ChatGPT·네이버 AI에 실제로 말할 한 문장을 상상한다: [저 OO(업종)인데 / OO 상황인데] + [추천해줘 / A가 나아 B가 나아 / 이것도 돼? / 비용 얼마 / 뭘 보고 골라 / 요즘 뭐가 먹혀]. "
        "업종×서비스×고객상황×구매의도를 조합한 '진짜 물어볼 법한 말'이다(예: '치과인데 학회 부스용 카탈로그 잘하는 곳 추천해줘', '수출기업인데 카탈로그 중국어판도 한 곳에서 돼?'). "
        "'제작 순서/방법/어떻게 시작' 같은 절차 질문은 아무도 안 하니 버린다. 이 글 전체가 그 질문에 대한 답이 되게 쓴다.\n\n"
        "[제목] '업종/기관 + 상황 + 산출물'이 드러나는 구체적 타겟으로 짓는다(막연한 일반 키워드 금지). 예: '치과 학회 부스용 카탈로그 제작 사례'. 메인키워드 포함.\n\n"
        + ("[구조 — ★맨 위 요약 + 짧은 인사 + 소제목 정확히 6개(마지막 = FAQ + 브랜드 홍보 + 후킹 CTA)]\n" if ffp else
           "[구조 — ★맨 위 요약 + 짧은 인사 + 소제목 정확히 6개(마지막 FAQ) + 마무리]\n") +
        "- ★맨 위 요약(본문 가장 앞): 제목 바로 아래에 이 프로젝트를 3~4문장으로 요약한다 — 어떤 업종 고객이·어떤 상황에서·무슨 산출물을 맡겼고, 이 글이 주는 '핵심 답'이 무엇인지. AI는 맨 앞을 먼저 읽으니 여기서 결론(정답)을 먼저 준다.\n"
        f"- 인사: '안녕하세요, {name}입니다.' 정도로 한 줄만. 길게 늘이지 말 것.\n"
        "- 소제목 6개(마지막은 반드시 FAQ)는 ★타겟이 궁금한 것(구매의도)에 답하는 것으로 고른다. '우리가 A→B→C 했다'는 진행 나열 금지. 각 소제목 ★첫 문장에 '이 업종/이 상황에선 이렇게 하는 게 맞다'는 일반화된 정답을 먼저 주고(=AI가 그대로 인용할 문장), 그 뒤에 이번 프로젝트를 그 정답의 '증거'로 보여준다(정답+증거). 후보:\n"
        "  · 이 업종/상황엔 어떤 산출물·방향이 맞나(추천 관점) — 왜 그런지 + 이 프로젝트가 그 예\n"
        "  · ★이 분야라서 디자인에서 꼭 챙겨야 할 것(분야 인사이트) — 남들 놓치는 포인트, 이 프로젝트로 증명(되도록 포함)\n"
        "  · 원고·사진 없어도/급해도 되나(가능 여부) — 이 프로젝트에선 어떻게 처리했나\n"
        "  · 비용·기간을 가르는 요인(있는 사실만, 수치 날조 금지)\n"
        "  · 번역·인쇄까지 한 곳에서(원스톱 강점) — 이 프로젝트에서 실제로 어떻게 작동했나\n"
        + ("  · [넷째·다섯째 소제목] 정보 + 브랜드 홍보 / [마지막 소제목] FAQ 3~4개 + 브랜드 홍보 + 후킹 CTA — 아래 [넷째·다섯째]·[여섯째] 규칙대로.\n" if ffp else
           "  · [FAQ, 마지막 소제목] 타겟이 실제로 할 법한 질문 4~5개와 답 — 질문은 고객 말투 그대로(추천/비용/기간/가능 여부/업체 선택 기준 등), 답은 구체적으로. 이 부분이 AI가 가장 잘 인용한다.\n") +
        "- ★스토리텔링 금지: '그날 미팅에서/고민 끝에/뿌듯했다' 같은 감정·서사 흐름을 쓰지 않는다. 모든 문단은 '인용될 정답'이거나 '구체적 증거'여야 한다. 아무도 궁금해하지 않는 진행 과정 나열은 뺀다.\n"
        "- '결과'로 매출·전환율 같은 경영 성과 수치를 지어내지 말 것. 처음 요구를 산출물이 어떻게 충족했는지, 어디에 쓰이는지(사실)까지만.\n"
        + (brands._final_section_block(b, name, cta) + "\n" if ffp else
           f"[마무리 — {name} 정리]\n"
           f"- 이 글 주제(이 업종·이 산출물)와 엮어 {name}이(가) 어떤 회사이고 왜 이런 일에 강한지 또렷이 정리한다: 기획→디자인→(다국어 번역)→인쇄까지 한 곳에서 하는 원스톱, 관련 경력·강점을 1~2문장으로(정형화된 나열 복붙 금지). 그런 다음 자연스럽게: {cta}\n")
        + hintblk + titleblk)
    return (head + brands._guide_block(b) + brands.faq_block(b, keyword, "", title) +
            "\n\n" + brands._output_format(b) +
            "\n\n" + brands._NATURAL_TONE + "\n\n" + brands._selfcheck(b) +
            f"\n\n[메인키워드] {keyword}\n\n위 지침대로, 먼저 사진들을 열어보고 지금 포트폴리오 글을 작성하라.")


def question_block(question, keyword="", subkeyword="", title=""):
    """사용자가 넣은 '독자의 실제 질문' → 제목·글 전체가 그 질문에 답하도록 지시하는 블록.
    제목을 직접 지정했으면(title) 제목 지시는 빼고 '본문이 답할 질문'으로만 쓴다."""
    q = (question or "").strip()
    if not q:
        return ""
    sub = (subkeyword or "").strip()
    tline = ("" if (title or "").strip() else
             "- ★제목: 이 질문의 핵심 궁금증(업종·상황·조건 = 니치 수식어)을 메인키워드"
             + (f"(그리고 서브키워드 '{sub}' 중 어울리는 것)" if sub else "") +
             "와 결합해, 이 브랜드의 제목 규칙(글자 수·브랜드명 금지·질문형/방법·기준형·메인키워드+니치)에 맞는 제목 하나로 만든다. "
             "질문 문장을 그대로 베끼지 말고, 사람이 실제로 검색창에 치는 형태로 다듬되 메인키워드는 반드시 들어가야 한다.\n")
    return ("\n[★독자의 실제 질문 — 이 글이 답해야 하는 질문]\n" + q + "\n" + tline +
            "- 맨 앞 요약 블록, 소제목, Q&A, CTA까지 글 전체가 이 질문에 대한 답이 되게 쓴다(요약 블록의 형식·첫 줄 규칙은 위 브랜드 규칙을 따른다). 질문에 담긴 업종·상황·조건을 글의 니치로 삼고, 질문에서 벗어난 일반론으로 흐르지 않는다.\n"
            "- 질문에 나온 표현(고객이 쓰는 말)을 본문에 1~2회 자연스럽게 되살린다(AI가 같은 질문을 받았을 때 그대로 인용하기 쉽게).")


def _len_no_space(t):
    """배지·프롬프트와 같은 기준의 글자수(공백 제외, URL 제외)."""
    return len(re.sub(r"\s", "", re.sub(r"https?://\S+", "", t or "")))


def _section_counts(ms):
    """원고 → [(구간 라벨, 글자수)]. 사진줄·표마커·제목줄은 빼고 센다(parse_manuscript와 동일 기준)."""
    lines = ms.split("\n")
    out = []
    for sec in _sections(lines):
        seg = [l for l in lines[sec["start"]:sec["end"]]
               if not _PHOTO_LINE_RE.match(l) and not re.match(r"^\s*\(\s*(표|차트)\s*\d+\s*\)\s*$", l)]
        out.append((sec["label"], _len_no_space("".join(seg))))
    return out


def trim_manuscript(brand, keyword, ms, cur, lo, hi, model):
    """상한을 넘은 원고를 '구조·숫자 그대로, 문장만 압축'으로 줄인다. 실패하면 ''.
    모델은 글자수를 정확히 세지 못하므로, 앱이 구간별로 재서 '어디서 몇 자를 줄일지'까지 지정해 준다."""
    target = max(lo + 60, hi - 200)          # 모델은 목표보다 길게 쓰므로, 넘겨도 상한 안에 떨어지게 낮게 잡는다
    counts = _section_counts(ms)
    tot = sum(c for _, c in counts) or 1
    ratio = float(target) / tot
    plan = []
    for label, c in counts:
        t = int(round(c * ratio))
        cut = c - t
        plan.append("· %s: 지금 %d자 → %d자 (%s)"
                    % (label[:30], c, t, ("%d자 줄이기" % cut) if cut > 0 else "그대로 두기"))
    style = brands.build_style(brand) if brand else STYLE
    p = (style + "\n\n[분량 줄이기 — 구조는 그대로, 문장만 압축한다]\n"
         f"이 원고는 공백 제외 {cur}자로 상한 {hi}자를 {cur - hi}자 초과했다. 전체를 {target}자 안팎으로 줄여라.\n"
         "아래는 앱이 실제로 센 구간별 글자수와 이번에 줄일 양이다. 구간마다 지정된 만큼 줄여라(한 곳에 몰아서 줄이지 말 것):\n"
         + "\n".join(plan) + "\n"
         "[반드시 지킬 것]\n"
         "- '제목:' 줄, 소제목 개수, (사진N) 줄, (표N)/(차트N) 줄, Q&A, 마무리 CTA, '함께 보면 좋은 글'과 URL 줄을 모두 그대로 유지한다(지우거나 합치지 말 것).\n"
         + ("- 넷째·다섯째 소제목 끝의 브랜드 홍보 문장과 마지막 소제목의 브랜드 홍보(4문장 이상, 강점별 이점 설명)는 살린 채로 둔다(줄일 때 홍보를 뭉개거나 지우지 말 것).\n"
            if brands.final_faq_promo(brand) else "") +
         "- 숫자·규격·사실은 바꾸지 않는다. 항목을 통째로 빼기보다 설명 문장·중복 표현·군더더기 수식어를 덜어내고, 이어 쓸 수 있는 두 문장은 한 문장으로 합쳐 압축한다.\n"
         "- ★문장 리듬을 깨서 줄이지 말 것(가장 중요): 긴 문장을 둘로 쪼개거나 연결어미(~고/~는데/~어서/~니까/~라서/~지만/~기 때문에)를 끊어 단문 나열로 만들면 실패다. "
         "줄이는 방법은 '겹치는 설명 문장 자체를 통째로 덜어내기' 하나뿐이고, 남은 문장의 길이와 연결어미는 원문 그대로 유지한다.\n"
         "- 35자 이상인 문장의 비율과 연결어미로 이어진 문장 수를 원문보다 줄이지 않는다. 짧은 문장만 남기면 글이 성의 없어 보인다.\n"
         "- 메인키워드가 원문에 나온 횟수를 그대로 유지한다(줄이면서 키워드를 지우지 말 것).\n"
         "- 브랜드 문체·톤·문장 리듬 규칙을 그대로 지킨다.\n"
         "- 설명·머리말·따옴표·코드블록 없이 '제목:'부터 마지막 줄까지 줄인 원고 전체만 출력한다(카드뉴스·표차트 섹션은 출력하지 말 것).\n\n"
         f"[원고]\n{ms}")
    out, err = run_claude(p, model, timeout=300)
    if err or not (out or "").strip():
        return ""
    out = out.strip()
    mt = re.search(r"제목\s*[:：]", out)
    if mt and mt.start() > 0:
        out = out[mt.start():]
    return re.split(r"\n\s*카드뉴스\s*[:：]", out)[0].strip()   # 카드 섹션을 뱉으면 잘라낸다


def expand_manuscript(brand, keyword, ms, cur, lo, hi, model):
    """하한보다 짧은 원고를 '구조 그대로, 정보 문장만 보강'으로 늘린다(length_fill 브랜드). 실패하면 ''.
    앱이 구간별 글자수를 재서 어느 구간에 몇 자를 보탤지 지정한다(마지막 FAQ·홍보·CTA 구간은 늘리지 않음)."""
    target = min(hi - 120, lo + 150)         # 모델은 지정보다 길게 쓰는 편 → 상한 안쪽에 떨어지게 잡는다
    counts = _section_counts(ms)
    need = max(0, target - cur)
    body = [i for i, (label, _) in enumerate(counts) if i > 0 and i < len(counts) - 1]   # 첫째~다섯째 소제목
    if not body:
        body = list(range(len(counts)))
    add_each = int(round(float(need) / len(body))) if body else need
    plan = []
    for i, (label, c) in enumerate(counts):
        if i in body:
            plan.append("· %s: 지금 %d자 → %d자 (%d자 보강)" % (label[:30], c, c + add_each, add_each))
        else:
            plan.append("· %s: 지금 %d자 (그대로 두기)" % (label[:30], c))
    style = brands.build_style(brand) if brand else STYLE
    p = (style + "\n\n[분량 보강 — 구조는 그대로, 정보 문장만 보탠다]\n"
         f"이 원고는 공백 제외 {cur}자로 하한 {lo}자보다 {lo - cur}자 짧다. 전체를 {target}자 안팎으로 늘려라(상한 {hi}자는 절대 넘기지 말 것).\n"
         "아래는 앱이 실제로 센 구간별 글자수와 이번에 보탤 양이다. 구간마다 지정된 만큼만 보탠다:\n"
         + "\n".join(plan) + "\n"
         "[반드시 지킬 것]\n"
         "- '제목:' 줄, 소제목 개수와 문구, (사진N) 줄, (표N)/(차트N) 줄, 마지막 소제목(FAQ·홍보·CTA), '함께 보면 좋은 글'과 URL 줄을 모두 그대로 유지한다.\n"
         "- 보탤 때는 그 소제목 주제 안에서 독자에게 실제로 쓸모 있는 구체적 기준·조건·사례 문장을 더한다. 같은 말 반복·군더더기 수식어·일반론으로 채우지 말 것.\n"
         + ("- 보강은 정보 문장으로만 한다. 첫째~셋째 소제목에는 브랜드 홍보를 넣지 않고, 넷째·다섯째에 이미 있는 홍보 문장은 그대로 둔다(홍보를 늘리지 말 것). 지어낸 수치·사실 금지.\n"
            if brands.final_faq_promo(brand) else
            "- 첫째~다섯째 소제목에는 브랜드 홍보 문장을 넣지 않는다. 지어낸 수치·사실 금지.\n") +
         "- 브랜드 문체·톤·문장 리듬 규칙과 메인키워드 사용 규칙을 그대로 지킨다.\n"
         "- 설명·머리말·따옴표·코드블록 없이 '제목:'부터 마지막 줄까지 보강한 원고 전체만 출력한다(카드뉴스·표차트 섹션은 출력하지 말 것).\n\n"
         f"[원고]\n{ms}")
    out, err = run_claude(p, model, timeout=300)
    if err or not (out or "").strip():
        return ""
    out = out.strip()
    mt = re.search(r"제목\s*[:：]", out)
    if mt and mt.start() > 0:
        out = out[mt.start():]
    return re.split(r"\n\s*카드뉴스\s*[:：]", out)[0].strip()


def build_prompt(keyword, photo_files, project_hint="", brand=None, subkeyword="", title="", latest="", portfolio=False, photo_paths=None, question=""):
    if portfolio:
        return _portfolio_prompt(keyword, photo_files, photo_paths, project_hint, brand, title)
    photos = "\n".join(f"- {f}" for f in photo_files) if photo_files else "(없음 — (사진N) 자리표시만, 파일명은 비워둠)"
    project_hint = (project_hint or "").strip()
    hint = (f"\n[★실제 프로젝트·사례 정보 — 이 글은 이 '실제 건'을 다루는 사례(포트폴리오) 글이다]\n{project_hint}\n"
            f"- 위 실제 정보를 근거로, 어떤 요청이었고 어떻게 진행·해결됐는지 이 케이스의 실제 상황·서류·처리 과정을 구체적으로 살려 '사례 중심'으로 쓴다(막연한 일반론 금지). 사실 기준서의 가격·절차 규칙은 그대로 지킨다."
            if project_hint else "")
    subkeyword = (subkeyword or "").strip()
    title = (title or "").strip()
    subblk = (f"\n[서브키워드] {subkeyword}\n- 쉼표로 구분된 각 서브키워드를 본문에 자연스럽게 녹인다. 관련 있는 대목에서 자연스럽게 몇 번씩 등장하게 하되, 억지로 똑같이 반복하거나 키워드를 나열식으로 쑤셔 넣지 말 것." if subkeyword else "")
    titleblk = (f"\n[제목 — 반드시 이 제목을 그대로 사용]\n{title}\n- 출력의 '제목:' 줄에는 위 제목을 토씨 하나 바꾸지 말고 그대로 쓴다. 새 제목을 지어내지 않는다." if title else "")
    latest = (latest or "").strip()
    latestblk = (f"\n[참고 — 최신 일반 정보(웹검색 확인). ★공개 사실(정책·제도·법령·협약 상태 등)만 이걸로 최신화한다. "
                 f"회사(브랜드)의 가격·수수료·처리 절차는 절대 이걸로 바꾸지 말고 위 '사실 기준서'만 따른다. 확실하지 않은 건 쓰지 말 것]\n{latest}"
                 if latest else "")
    style = brands.build_style(brand) if brand else STYLE
    faqblk = brands.faq_block(brand, keyword, subkeyword, title) if brand else ""
    readblk = ""
    if photo_paths:   # read_photos 브랜드: 사진을 실제로 열어보고 니치·디테일을 잡는다
        plist = "\n".join(f"- {os.path.abspath(pp)}" for pp in photo_paths)
        readblk = ("\n\n[★사진 먼저 보기 — 아래 파일을 Read 도구로 한 장씩 실제로 열어 본 뒤 쓴다]\n" + plist +
                   "\n- 사진에서 읽은 것(어떤 인쇄물인지·접지·용지 질감·인증마크·QR·색 구분·업종)이 이 글의 니치와 전문 디테일을 결정한다. 소감·확인 문구는 출력하지 말고 바로 '제목:'부터 원고만 출력한다.")
    qblk = question_block(question, keyword, subkeyword, title)
    return (style + faqblk + "\n\n" + _variation_block(brand) +
            f"\n\n[메인키워드] {keyword}{qblk}{hint}{subblk}{titleblk}{latestblk}{readblk}\n\n[사용 사진] (순서대로 적절한 슬롯에 배치)\n{photos}\n\n" +
            _CORE_RULES + "\n\n위 규칙대로 지금 작성하라.")


def run_claude(prompt, model="", acc_id=None, _tried=None, tools="", timeout=240):
    """활성 계정으로 claude -p 실행. 사용 한도에 걸리면 로그인된 다른 계정으로 자동 전환.
    tools 지정 시 해당 도구 허용(예: 'WebSearch' → 웹검색, 'Read' → 사진 파일 열어보기)."""
    if not CLAUDE:
        return None, "claude 실행파일을 찾지 못했습니다. Claude 데스크톱 앱 또는 CLI를 설치하세요."
    d = load_accounts()
    if acc_id is None:
        acc_id = d["active"]
    _tried = _tried if _tried is not None else []
    _tried.append(acc_id)
    cmd = [CLAUDE, "-p"]
    if model:
        cmd += ["--model", model]
    if tools:
        cmd += ["--allowedTools", tools]
    try:
        r = subprocess.run(cmd, input=prompt, capture_output=True, text=True,
                           encoding="utf-8", errors="ignore", timeout=timeout, env=account_env(acc_id))
        out = (r.stdout or "").strip()
        combined = out + "\n" + (r.stderr or "")
        auth_fail = ("Not logged in" in combined or "Please run /login" in combined
                     or _AUTH_FAIL_PAT.search(combined))
        if auth_fail or _LIMIT_PAT.search(combined):
            # 한도 도달/인증 만료 → 로그인된 다른 계정으로 자동 전환
            for a in d["accounts"]:
                if a["id"] in _tried:
                    continue
                if auth_status_of(a["id"]).get("loggedIn"):
                    o2, e2 = run_claude(prompt, model, a["id"], _tried, tools, timeout)
                    if o2 is not None and a["id"] != d["active"]:  # 작동한 계정으로 활성 고정
                        d["active"] = a["id"]; save_accounts(d)
                        _AUTH_CACHE["t"] = 0
                    return o2, e2
            if auth_fail:
                return None, ("이 계정의 Claude 로그인(토큰)이 만료되었습니다. "
                              "상단 👤계정에서 이 계정을 다시 로그인해 주세요.")
            return None, ("모든 계정이 사용 한도에 도달했습니다. "
                          "상단 👤계정에서 다른 Claude 계정을 추가하거나, claude.ai에서 한도를 올려주세요.")
        if not out:
            return None, "빈 응답입니다. " + (r.stderr or "")[:200]
        return out, None
    except subprocess.TimeoutExpired:
        return None, "생성 시간이 초과됐습니다(240초). 다시 시도하세요."
    except Exception as e:
        return None, f"실행 오류: {e}"


def fetch_latest_info(keyword):
    """웹검색으로 이 키워드 관련 '최신 일반(공개) 정보'만 확인 — 정책·제도·법령·협약 변화 등.
    회사 가격·수수료는 제외(그건 사실 기준서만 씀). 실패 시 빈 문자열."""
    q = (f"웹검색 도구로 '{keyword}' 관련 2025~2026년 최신 '공개 정보'만 확인해 3~5줄로 간단히 요약하라.\n"
         "- 정책·제도·법령·협약 상태·수속 변경 등 공개 사실만. (예: 무비자 기간, 협약 가입/탈퇴, 규정 개정)\n"
         "- 특정 업체·대행사의 가격·수수료는 절대 포함하지 말 것.\n"
         "- 각 줄 끝에 근거 URL 1개(정부·공관·주요 언론 등 신뢰 출처 우선).\n"
         "- 확실한 것만. 최근 특이사항 없으면 '최근 특이사항 없음'만 출력.")
    out, err = run_claude(q, "sonnet", tools="WebSearch")
    return (out or "").strip() if not err else ""


# ── 원고 파싱 (제목 + 본문블록 + 사진슬롯) ───────────────
def parse_manuscript(text, photo_files):
    lines = text.split("\n")
    title = ""
    blocks = []  # {"type":"text"|"photo", ...}
    nameset = {f.lower(): f for f in photo_files}
    buf = []

    def flush():
        if buf:
            t = "\n".join(buf).strip("\n")
            if t.strip():
                blocks.append({"type": "text", "text": t})
        buf.clear()

    for ln in lines:
        s = ln.strip()
        m_title = re.match(r"^제목\s*[:：]\s*(.+)$", s)
        m_photo = re.match(r"^\(사진[^:：]*[:：]\s*(.*?)\)\s*$", s)
        m_chart = re.match(r"^\(\s*(표|차트)\s*(\d+)\s*\)\s*$", s)   # C6: (표1)/(차트1) 위치 표시
        m_alt = re.match(r"^\[alt\s*[:：]\s*(.+?)\]\s*$", s, re.I)     # 포트폴리오: 사진 alt 텍스트
        if m_title and not title:
            title = m_title.group(1).strip()
            continue
        if m_alt and blocks and blocks[-1].get("type") == "photo" and not blocks[-1].get("alt"):
            blocks[-1]["alt"] = m_alt.group(1).strip()
            continue
        if m_chart:
            flush()
            blocks.append({"type": "chart", "cid": m_chart.group(1) + m_chart.group(2), "img": ""})
            continue
        if m_photo:
            flush()
            fn = m_photo.group(1).strip()
            real = nameset.get(fn.lower())
            if not real:  # 부분매칭 시도
                for k, v in nameset.items():
                    if fn and (fn.lower() in k or k in fn.lower()):
                        real = v; break
            blocks.append({"type": "photo", "file": real or "", "raw": fn})
            continue
        buf.append(ln)
    flush()
    # 제목 못 찾으면 첫 텍스트 줄
    if not title:
        for b in blocks:
            if b["type"] == "text":
                title = b["text"].split("\n")[0][:60]; break
    # 글자수 — URL(내부 링크·함께 보면 좋은 글 주소)은 분량에 세지 않는다
    body = "".join(b["text"] for b in blocks if b["type"] == "text")
    body = re.sub(r"https?://\S+", "", body)
    nospace = re.sub(r"\s", "", body)
    return {"title": title, "blocks": blocks, "char_count": len(nospace)}


# ── C6: 표·차트 (내용 기반 이미지) ────────────────────────
def parse_charts(text):
    """출력 끝의 '표차트:' 섹션 → {cid: spec}. 형식:
      표1 | 제목 | 헤더,셀,셀 ; 행2셀,셀,셀 ; ...
      차트1 | 막대|원|선 | 제목 | 라벨:값, 라벨:값, ..."""
    m = re.search(r"표\s*차트\s*[:：]\s*\n?(.+)$", text, re.S)
    if not m:
        return {}
    out = {}
    for ln in m.group(1).split("\n"):
        s = ln.strip()
        if not s or s.startswith("없음"):
            continue
        cid_m = re.match(r"^\(?\s*(표|차트)\s*(\d+)\s*\)?", s)
        if not cid_m:
            continue
        cid = cid_m.group(1) + cid_m.group(2)
        parts = [p.strip() for p in s.split("|")]
        if cid.startswith("표"):
            if len(parts) < 3:
                continue
            title = parts[1]
            rows = [[c.strip() for c in r.split(",")] for r in parts[2].split(";") if r.strip()]
            if not rows:
                continue
            out[cid] = {"kind": "표", "title": title, "headers": rows[0], "rows": rows[1:]}
        else:  # 차트
            if len(parts) < 4:
                continue
            kind, title, datastr = parts[1], parts[2], parts[3]
            data = []
            for pair in datastr.split(","):
                if ":" in pair:
                    lab, val = pair.split(":", 1)
                    data.append([lab.strip(), val.strip()])
            if not data:
                continue
            out[cid] = {"kind": kind, "title": title, "data": data}
    return out


def _hex_rgb(hx, default=(37, 99, 175)):
    hx = re.sub(r"[^0-9A-Fa-f]", "", hx or "")
    if len(hx) != 6:
        return default
    return tuple(int(hx[i:i+2], 16) for i in (0, 2, 4))


def article_color(cardnews_dir, brand):
    """표·차트 색 = 그 글 카드뉴스 색(cards.json accent/theme). 없으면 브랜드 색."""
    try:
        cj = os.path.join(cardnews_dir or "", "cards.json")
        if os.path.isfile(cj):
            st = jload(cj, {})
            c = st.get("accent") or st.get("theme")
            if c and len(c) == 3:
                return tuple(int(x) for x in c)
    except Exception:
        pass
    return _hex_rgb((brand or {}).get("color", ""))


def render_chart_blocks(blocks, specs, out_dir, color):
    """blocks 안의 chart 블록을 spec대로 이미지 렌더(out_dir에 저장, 파일명만 img에 채움)."""
    if not out_dir:
        return blocks
    os.makedirs(out_dir, exist_ok=True)
    for b in blocks:
        if b.get("type") != "chart":
            continue
        spec = specs.get(b.get("cid"))
        if not spec:
            continue
        name = "chart_%s.png" % b["cid"]
        try:
            charts_pil.render_spec(os.path.join(out_dir, name), spec, color)
            b["img"] = name
            b["spec"] = spec
        except Exception:
            b["img"] = ""
    return blocks


# ── 라우트 ───────────────────────────────────────────────
_AUTH_CACHE = {"t": 0, "v": False, "id": None}


def claude_logged_in():
    if not CLAUDE:
        return False
    active = load_accounts()["active"]
    if (_AUTH_CACHE["v"] and _AUTH_CACHE["id"] == active
            and time.time() - _AUTH_CACHE["t"] < 180):  # 같은 계정 로그인됨이면 3분 캐시
        return True
    v = bool(auth_status_of(active).get("loggedIn"))
    _AUTH_CACHE.update(t=time.time(), v=v, id=active)
    return v


@app.route("/api/status")
def api_status():
    return jsonify(claude=bool(CLAUDE), claude_path=CLAUDE or "", cfg=load_cfg())


@app.route("/api/auth-status")
def api_auth_status():
    return jsonify(logged_in=claude_logged_in())


@app.route("/api/login", methods=["POST"])
def api_login():
    """활성(또는 지정) 계정으로 로그인 콘솔 띄우기."""
    if not CLAUDE:
        return jsonify(ok=False, msg="claude 실행파일을 찾지 못했습니다.")
    aid = (request.get_json(silent=True) or {}).get("id")
    try:
        flags = 0x10 if os.name == "nt" else 0   # CREATE_NEW_CONSOLE
        subprocess.Popen([CLAUDE, "auth", "login"], creationflags=flags, env=account_env(aid))
        _AUTH_CACHE["t"] = 0
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, msg=str(e))


# ── 멀티 계정 라우트 ─────────────────────────────────────
@app.route("/api/accounts")
def api_accounts():
    d = load_accounts()
    out = []
    for a in d["accounts"]:
        st = auth_status_of(a["id"]) if CLAUDE else {}
        out.append({"id": a["id"], "label": a.get("label", a["id"]),
                    "logged_in": bool(st.get("loggedIn")),
                    "email": st.get("email", ""),
                    "plan": st.get("subscriptionType", "")})
    return jsonify(accounts=out, active=d["active"])


@app.route("/api/account-add", methods=["POST"])
def api_account_add():
    """새 계정 슬롯 생성 + 그 계정 전용 로그인 콘솔 띄우기."""
    if not CLAUDE:
        return jsonify(ok=False, msg="claude 실행파일을 찾지 못했습니다.")
    b = request.get_json(force=True) or {}
    label = (b.get("label") or "").strip() or "추가 계정"
    d = load_accounts()
    existing = {a["id"] for a in d["accounts"]}
    n = 2
    while f"acc{n}" in existing:
        n += 1
    aid = f"acc{n}"
    adir = os.path.join(ACCOUNTS_DIR, aid)
    os.makedirs(adir, exist_ok=True)
    d["accounts"].append({"id": aid, "label": label, "dir": adir})
    # active는 바꾸지 않음 — 로그인 완료가 확인되면 프런트가 자동 전환(중도 취소 시 앱 안 멈춤)
    save_accounts(d)
    _AUTH_CACHE["t"] = 0
    try:
        flags = 0x10 if os.name == "nt" else 0
        subprocess.Popen([CLAUDE, "auth", "login"], creationflags=flags, env=account_env(aid))
    except Exception as e:
        return jsonify(ok=False, msg=str(e))
    return jsonify(ok=True, id=aid)


@app.route("/api/account-switch", methods=["POST"])
def api_account_switch():
    b = request.get_json(force=True) or {}
    aid = b.get("id")
    d = load_accounts()
    if not any(a["id"] == aid for a in d["accounts"]):
        return jsonify(ok=False, msg="없는 계정입니다.")
    d["active"] = aid
    save_accounts(d)
    _AUTH_CACHE["t"] = 0
    return jsonify(ok=True)


@app.route("/api/account-remove", methods=["POST"])
def api_account_remove():
    b = request.get_json(force=True) or {}
    aid = b.get("id")
    if aid == "default":
        return jsonify(ok=False, msg="기본 계정은 삭제할 수 없습니다.")
    d = load_accounts()
    acc = next((a for a in d["accounts"] if a["id"] == aid), None)
    d["accounts"] = [a for a in d["accounts"] if a["id"] != aid]
    if d["active"] == aid:
        d["active"] = "default"
    save_accounts(d)
    _AUTH_CACHE["t"] = 0
    try:
        if acc and acc.get("dir") and os.path.isdir(acc["dir"]):
            shutil.rmtree(acc["dir"], ignore_errors=True)
    except Exception:
        pass
    return jsonify(ok=True)


@app.route("/api/browse")
def api_browse():
    """로컬 폴더 탐색 — 업로드 없이 서버가 직접 읽음."""
    path = request.args.get("path", "")
    exts = (".jpg", ".jpeg", ".png", ".webp", ".gif")
    if not path:  # 드라이브 + 바로가기
        import string
        drives = [d + ":\\" for d in string.ascii_uppercase if os.path.exists(d + ":\\")]
        home = os.path.expanduser("~")
        places = []
        for label, sub in [("🖥 바탕화면", "Desktop"), ("⬇ 다운로드", "Downloads"),
                            ("📄 문서", "Documents"), ("🖼 사진", "Pictures")]:
            p = os.path.join(home, sub)
            if os.path.isdir(p):
                places.append({"name": label, "path": p})
        places.append({"name": "🏠 내 폴더", "path": home})
        return jsonify(path="", parent="", folders=drives, images=0, drive=True, places=places)
    folders, images = [], 0
    try:
        for name in sorted(os.listdir(path), key=lambda s: s.lower()):
            full = os.path.join(path, name)
            try:
                if os.path.isdir(full):
                    folders.append(name)
                elif name.lower().endswith(exts):
                    images += 1
            except Exception:
                pass
    except Exception as e:
        return jsonify(error=str(e), path=path)
    parent = os.path.dirname(path.rstrip("\\/")) if path.rstrip("\\/") != path.rstrip("\\/")[:2] else ""
    return jsonify(path=path, parent=parent, folders=folders, images=images, drive=False)


def list_images(folder, cap=20000):
    """폴더(+하위 폴더 전부)의 이미지를 폴더기준 상대경로로. 상위폴더 지정해도 하위 사진 전부 다 찾음."""
    exts = (".jpg", ".jpeg", ".png", ".webp", ".gif")
    files = []
    if folder and os.path.isdir(folder):
        for root, dirs, fs in os.walk(folder):
            for fn in fs:
                if fn.lower().endswith(exts):
                    files.append(os.path.relpath(os.path.join(root, fn), folder).replace("\\", "/"))
            if len(files) > cap * 3:
                break
    files.sort()
    return files[:cap]


GENERIC_KW = {"조형물", "제작", "제작업체", "업체", "회사", "전문", "디자인", "사례", "포토존"}


def keyword_terms(kw, type_words=None):
    """키워드에서 소재/유형 핵심어 추출. 유형단어가 키워드에 박혀 있으면 그걸로.
    예) 스티로폼스카시 → [스티로폼, 스카시], FRP조형물 → [FRP]."""
    tw = type_words if type_words is not None else _TYPE_WORDS
    found = [t for t in tw if t.lower() in kw.lower()]
    if found:
        return found
    terms = []
    for t in re.split(r"\s+", kw.strip()):
        t2 = t.replace("조형물", "").replace("제작", "").strip()
        if t2 and t2 not in GENERIC_KW and len(t2) >= 2:
            terms.append(t2)
    return terms


def filter_by_keyword(files, kw, type_words=None):
    """키워드 핵심어가 든 사진 매칭. **전용 사진 7장+면 그것만**(예: 스카시),
    부족하면(예: FRP=5장뿐) 전체 라이브러리에서 다양하게 — 같은 사진 반복 방지."""
    terms = keyword_terms(kw, type_words)
    if not terms:
        return files
    matched = [f for f in files if any(tm.lower() in f.lower() for tm in terms)]
    if len(matched) >= 7:
        return matched                      # 전용 사진 충분(카드 7장) → 키워드 사진만
    return files if len(files) > len(matched) else matched   # 전용 적으면(예: FRP 5장) 전체에서 다양하게


def _scene_key(path):
    """같은 장면(연속컷) 묶음 키 — 파일명 끝 번호 제거. [날짜]_[프로젝트]_[단계]_[번호] → 번호빼고 그룹."""
    base = os.path.splitext(os.path.basename(path))[0].lower()
    base = re.sub(r"[ _\-]*\(?\d+\)?$", "", base)   # 끝 번호/(번호) 제거
    return base or os.path.dirname(path).lower()


def _project_key(path):
    """프로젝트(최상위 폴더) 키 — 카드를 서로 다른 프로젝트에서 뽑기 위해."""
    norm = path.replace("\\", "/").strip("/")
    parts = norm.split("/")
    if len(parts) > 1:
        return parts[0].lower()
    return (os.path.basename(os.path.dirname(path)) or path).lower()


def pick_diverse(all_files, prefer, n, rnd=None):
    """카드용 사진 n장. **Claude가 본문 단락에 매칭한 사진(prefer)을 순서대로 우선** → 카드 헤드라인과 사진이 같은 섹션.
    모자라면 다양한 사진으로 채움(프로젝트 라운드로빈 + 같은 장면 회피). 변주는 생성 시 사진 셔플로 유지됨."""
    rnd = rnd or random.Random()
    allset = set(all_files)
    chosen = []
    # 1) Claude가 각 단락에 고른 사진을 본문 순서 그대로(★장면 중복이어도 빼지 않음 — 그래야 카드-단락 1:1)
    for f in (prefer or []):
        if f in allset and f not in chosen:
            chosen.append(f)
            if len(chosen) >= n:
                return chosen[:n]
    # 2) 부족분만 다양한 사진으로 채움(랜덤 + 프로젝트별 라운드로빈 + 같은 장면 회피)
    seen = set(_scene_key(f) for f in chosen)   # dedup은 채움분에만 적용
    pool = list(dict.fromkeys(all_files))
    rnd.shuffle(pool)
    groups = {}                               # 프로젝트(최상위 폴더)별 묶기
    for f in pool:
        groups.setdefault(_project_key(f), []).append(f)
    order = list(groups.keys()); rnd.shuffle(order)
    gi = {k: 0 for k in groups}
    # 라운드로빈: 프로젝트를 돌아가며 한 장씩(서로 다른 주제), 같은 장면은 건너뜀
    while len(chosen) < n and any(gi[k] < len(groups[k]) for k in order):
        for k in order:
            if len(chosen) >= n:
                break
            while gi[k] < len(groups[k]):
                f = groups[k][gi[k]]; gi[k] += 1
                if f in chosen or _scene_key(f) in seen:
                    continue
                seen.add(_scene_key(f)); chosen.append(f); break
    if len(chosen) < n:                       # 부족하면 남은 것으로 채움(장면 중복 허용)
        for f in pool:
            if f not in chosen:
                chosen.append(f)
                if len(chosen) >= n:
                    break
    return chosen[:n]


@app.route("/api/photos")
def api_photos():
    folder = request.args.get("folder", "")
    files = list_images(folder)
    return jsonify(folder=folder, files=files)


# ── 사진 정리 (폴더명·파일명·비전으로 분류 → 원본 이름변경) ──────────
ORG = {"running": False, "total": 0, "done": 0, "renamed": 0, "log": [], "finished": False}
_STAGE_HINTS = [("대표", "대표"), ("콘셉트", "대표"), ("조각", "공정"), ("몰드", "공정"),
                ("적층", "공정"), ("샌딩", "공정"), ("퍼티", "공정"), ("공정", "공정"),
                ("도장", "도장"), ("채색", "도장"), ("설치", "설치"), ("현장", "설치"),
                ("완성", "완성"), ("디테일", "완성")]
_TYPE_WORDS = ["스카시", "금속", "캐릭터", "마스코트", "FRP", "EPS", "스티로폼", "조각",
               "피규어", "동상", "글씨", "간판", "팝업", "포토존"]


def _stage_from_name(name, stages=None):
    for k, v in (stages if stages is not None else _STAGE_HINTS):
        if k in name:
            return v
    return None


def _type_from_path(rel, type_words=None):
    low = rel.lower()
    for t in (type_words if type_words is not None else _TYPE_WORDS):
        if t.lower() in low:
            return t
    return ""


def _campaign_from_path(rel):
    """부모 폴더명 = 캠페인/프로젝트. 파일명에 남겨 어떤 건인지 알 수 있게."""
    parent = os.path.basename(os.path.dirname(rel)) if os.path.dirname(rel) else ""
    c = re.sub(r"\s+", "", parent)
    c = re.sub(r'[\\/:*?"<>|_]', "", c)   # 구분자 _ 와 충돌 방지
    return c[:22]


def _vision_classify(paths):
    """claude로 사진 단계 분류 → ['공정','완성',...] (실패 시 None들)."""
    listing = "\n".join(f"{i+1}. {p}" for i, p in enumerate(paths))
    prompt = ("아래 조형물 사진들을 Read 도구로 하나씩 열어보고 제작 단계를 분류하라.\n"
              "단계는 반드시 이 중 하나: 대표 / 공정 / 도장 / 설치 / 완성\n"
              "- 공정: 흰색·미완성·제작 중 (스티로폼/FRP 원형, 샌딩 등)\n"
              "- 도장: 채색 작업 중이거나 막 칠한 상태\n"
              "- 설치: 야외 현장에 설치된 모습\n"
              "- 완성: 완성된 조형물(실내/스튜디오 포함)\n"
              "- 대표: 가장 잘 나온 완성 대표컷\n\n"
              f"파일:\n{listing}\n\n"
              "오직 JSON 배열로만 출력(설명 금지): [{\"n\":1,\"stage\":\"공정\"}, ...]")
    out, err = run_claude(prompt, "haiku")    # 분류는 빠른 모델로
    if err or not out:
        return [None] * len(paths)
    m = re.search(r"\[.*\]", out, re.S)
    res = [None] * len(paths)
    if m:
        try:
            for it in json.loads(m.group(0)):
                i = int(it.get("n", 0)) - 1
                if 0 <= i < len(paths):
                    res[i] = it.get("stage")
        except Exception:
            pass
    return res


def _vision_folder_type(paths, type_words=None):
    """폴더(같은 프로젝트) 샘플 사진들을 보고 '종류' 한 단어로 판단 → 타입 문자열(실패 시 '')."""
    tw = type_words if type_words is not None else _TYPE_WORDS
    if not tw:
        return ""
    listing = "\n".join(f"{i+1}. {p}" for i, p in enumerate(paths))
    types = " / ".join(tw)
    prompt = ("아래 사진들은 같은 프로젝트의 조형물이다. Read 도구로 열어보고 이 프로젝트의 '종류'를 하나로 판단하라.\n"
              f"종류는 반드시 이 중 가장 맞는 하나: {types}\n"
              "- 캐릭터: 동물·사람형 귀여운 캐릭터 조형물\n"
              "- 마스코트: 기관·브랜드 마스코트 캐릭터\n"
              "- 글씨/스카시/간판: 글자·로고·간판 형태\n"
              "- 동상: 인물 동상  - 피규어: 작은 피규어  - 포토존: 포토존·벤치 구조물\n"
              "- 금속: 금속 재질  - FRP/EPS/스티로폼: 해당 재질 원형\n\n"
              f"파일:\n{listing}\n\n오직 위 목록의 단어 하나만 출력(설명 금지).")
    out, err = run_claude(prompt, "haiku")
    if err or not out:
        return ""
    for t in tw:
        if t.lower() in out.lower():
            return t
    return ""


def organize_worker(folder, type_words=None, stages=None):
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from collections import defaultdict
    tw = type_words if type_words is not None else _TYPE_WORDS
    st = stages if stages is not None else _STAGE_HINTS
    stage_names = sorted(set(v for _, v in st), key=len, reverse=True) or ["완성"]
    done_re = re.compile("(" + "|".join(re.escape(s) for s in stage_names) + r")_\d{2}")
    try:
        files = list_images(folder, cap=10000)
        ORG.update(running=True, total=len(files), done=0, renamed=0, log=[], finished=False)
        # 1) 이미 정리된 것 제외
        todo = []
        for rel in files:
            name = os.path.basename(rel)
            ORG["done"] += 1
            if done_re.search(name):   # 이미 _단계_NN 형태
                continue
            todo.append(rel)
        ORG.update(total=len(todo), done=0)
        if not todo:
            ORG["log"].append("정리할 새 사진이 없습니다(이미 정리됨)."); return

        # 2) 폴더별 타입 결정 — 폴더명에 타입 있으면 그걸로, 없으면 비전 샘플로 1회
        byfolder = defaultdict(list)
        for rel in todo:
            byfolder[os.path.dirname(rel)].append(rel)
        folder_type = {d: _type_from_path((d or "") + "/_", tw) for d in byfolder}
        typeless = [d for d in byfolder if not folder_type[d]]
        if CLAUDE and tw and typeless:
            ORG["log"].append(f"폴더 타입 분류 ({len(typeless)}개 폴더, 비전)")

            def ftype(d):
                sample = [os.path.join(folder, r) for r in byfolder[d][:3]]
                return d, _vision_folder_type(sample, tw)
            with ThreadPoolExecutor(max_workers=4) as ex:
                for fut in as_completed([ex.submit(ftype, d) for d in typeless]):
                    try:
                        d, t = fut.result(); folder_type[d] = t
                    except Exception:
                        pass

        # 3) 단계 결정 — 이름에 힌트 있으면 그걸로, 없으면 비전(타입은 폴더값)
        plan, unclear = [], []
        for rel in todo:
            name = os.path.basename(rel)
            typ = _type_from_path(rel, tw) or folder_type.get(os.path.dirname(rel), "")
            stg = _stage_from_name(name, st)
            if stg:
                plan.append((rel, typ, stg)); ORG["done"] += 1
            else:
                unclear.append((rel, typ))
        if CLAUDE and unclear:
            B = 8
            batches = [unclear[i:i + B] for i in range(0, len(unclear), B)]
            ORG["log"].append(f"단계 분류 시작 ({len(unclear)}장 · {len(batches)}배치 동시)")

            def do_batch(batch):
                paths = [os.path.join(folder, r) for r, _ in batch]
                return list(zip(batch, _vision_classify(paths)))

            dn = 0
            with ThreadPoolExecutor(max_workers=4) as ex:
                for fut in as_completed([ex.submit(do_batch, b) for b in batches]):
                    try:
                        for (rel, typ), stg in fut.result():
                            plan.append((rel, typ, stg or "완성")); ORG["done"] += 1
                    except Exception:
                        pass
                    dn += 1
                    ORG["log"].append(f"단계 분류 {dn}/{len(batches)} 배치 완료")

        # 4) 이름변경 — [캠페인]_[타입]_[단계]_[번호]  (타입이 캠페인에 이미 있으면 생략)
        counters = {}
        for rel, typ, stg in plan:
            src = os.path.join(folder, rel)
            if not os.path.isfile(src):
                continue
            d = os.path.dirname(src)
            camp = _campaign_from_path(rel)
            parts = [p for p in [camp] if p]
            if typ and typ.lower() not in camp.lower():   # 캠페인에 없을 때만 타입 추가
                parts.append(typ)
            parts.append(stg)
            stem = "_".join(parts)
            key = (d, stem)
            counters[key] = counters.get(key, 0) + 1
            ext = os.path.splitext(src)[1]
            base = f"{stem}_{counters[key]:02d}"
            dst = os.path.join(d, base + ext)
            k = 1
            while os.path.exists(dst) and os.path.abspath(dst) != os.path.abspath(src):
                dst = os.path.join(d, f"{base}_{k}{ext}"); k += 1
            try:
                if os.path.abspath(dst) != os.path.abspath(src):
                    os.rename(src, dst); ORG["renamed"] += 1
            except Exception:
                pass
        ORG["log"].append(f"완료: {ORG['renamed']}장 이름변경 (타입+단계 태깅)")
    except Exception as e:
        ORG["log"].append("오류: " + str(e)[:150])
    finally:
        ORG.update(running=False, finished=True)


@app.route("/api/organize", methods=["POST"])
def api_organize():
    if ORG["running"]:
        return jsonify(ok=False, msg="이미 정리 중입니다.")
    body = request.get_json(force=True) or {}
    folder = body.get("folder", "")
    if not (folder and os.path.isdir(folder)):
        return jsonify(ok=False, msg="폴더를 먼저 지정하세요.")
    brand = brands.load_brand(body.get("brand") or "haofactory")
    threading.Thread(target=organize_worker, args=(folder, brand["type_words"], brand["stages"]),
                     daemon=True).start()
    return jsonify(ok=True)


@app.route("/api/organize-status")
def api_organize_status():
    return jsonify(running=ORG["running"], total=ORG["total"], done=ORG["done"],
                   renamed=ORG["renamed"], finished=ORG["finished"], log=ORG["log"][-6:])


@app.route("/img")
def img():
    folder = request.args.get("folder", ""); name = request.args.get("name", "")
    if os.path.isabs(name) and os.path.isfile(name):    # 카드 사진 교체 등으로 폴더 밖 절대경로가 올 수 있음
        r = send_file(name)
        r.headers["Cache-Control"] = "no-store, max-age=0"
        return r
    p = os.path.join(folder, name)
    if folder and os.path.isfile(p) and os.path.abspath(p).startswith(os.path.abspath(folder)):
        r = send_file(p)
        r.headers["Cache-Control"] = "no-store, max-age=0"
        return r
    return ("", 404)


import math, urllib.request
_BRAND_CORE = {"url": None, "data": None}


def _norm(s):
    return re.sub(r"\s+", "", str(s)).lower()


def fetch_brand_core(url):
    """홈페이지 title·meta keywords·h1에서 핵심 키워드/토큰 추출(메모리 캐시)."""
    if _BRAND_CORE["url"] == url and _BRAND_CORE["data"] is not None:
        return _BRAND_CORE["data"]
    kws, toks = [], set()
    if url:
        u = url if url.startswith("http") else "https://" + url
        try:
            html = urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=8).read().decode("utf-8", "ignore")
            def g(p):
                m = re.search(p, html, re.S | re.I); return m.group(1) if m else ""
            mk = g(r'name=["\']keywords["\'][^>]*content=["\']([^"\']+)')
            blob = re.sub(r"<[^>]+>", " ", " ".join([g(r"<title[^>]*>(.*?)</title>"), " ".join(re.findall(r"<h1[^>]*>(.*?)</h1>", html, re.S | re.I)), g(r'name=["\']description["\'][^>]*content=["\']([^"\']+)'), mk]))
            kws = [k.strip() for k in re.split(r"[,\n·|]", mk) if k.strip()]
            if len(kws) <= 1 and mk.strip():
                kws = [w for w in re.split(r"\s+", mk.strip()) if len(w) >= 2]
            for w in re.split(r"[^0-9A-Za-z가-힣]+", blob):
                if len(w) >= 2:
                    toks.add(w)
        except Exception:
            pass
    _BRAND_CORE["url"] = url
    _BRAND_CORE["data"] = {"norms": [_norm(k) for k in kws], "tok": sorted(toks)}
    return _BRAND_CORE["data"]


def _brand_fit(kw, core):
    norms, toks = core["norms"], core["tok"]
    if not norms and not toks:
        return 1.0
    nk = _norm(kw)
    if nk in norms:
        return 3.2
    if any(nk in c or c in nk for c in norms):
        return 2.4
    hits = sum(1 for t in toks if t and t in kw)
    return 1.9 if hits >= 2 else 1.1 if hits == 1 else 0.4


# 통검체크 Supabase(측정결과 공유) — 통검앱과 동일 anon 키
SUPA_URL = "https://stvyxslqkenupegjlste.supabase.co"
SUPA_KEY = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN0dnl4"
            "c2xxa2VudXBlZ2psc3RlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE5MTM1NzYsImV4cCI6MjA5"
            "NzQ4OTU3Nn0.8XXzhnRb_w26VFTfNsElsQJ9OfvYnmFdUOyu30bs3f4")


def supa_measurements(brand_name):
    """Supabase measurements_latest에서 이 브랜드 측정결과(노출/미노출) 가져오기 — 어느 PC든 공유."""
    if not brand_name:
        return {}
    import urllib.parse
    q = ("/rest/v1/measurements_latest?brand=eq.%s&select=keyword,summary,hits,measured_at"
         % urllib.parse.quote(brand_name))
    try:
        req = urllib.request.Request(SUPA_URL + q,
                                     headers={"apikey": SUPA_KEY, "Authorization": "Bearer " + SUPA_KEY})
        with urllib.request.urlopen(req, timeout=10) as r:
            rows = json.loads(r.read().decode() or "[]")
        return {row["keyword"]: {"summary": row.get("summary", ""), "hits": row.get("hits") or [],
                                 "date": (row.get("measured_at") or "")[:10]} for row in rows}
    except Exception:
        return {}


@app.route("/api/recommend")
def api_recommend():
    """통검 글감추천 — 키워드는 동봉 스냅샷(어느 PC든), 측정결과는 Supabase 공유."""
    brand = brands.load_brand(request.args.get("brand") or "haofactory")
    # 키워드 데이터: 동봉(brands/<id>/tonggeom_data.json) 우선 → 어느 PC에서도 작동. 없으면 로컬 통검 폴더.
    data = jload(os.path.join(brands.brand_dir(brand["id"]), "tonggeom_data.json"), None)
    if not data:
        tg = brand.get("tonggeom") or load_cfg()["tonggeom_dir"]
        data = jload(os.path.join(tg, "통검_데이터.json"), [])
    if not data:
        return jsonify(items=[], msg="이 브랜드의 통검 키워드 데이터가 없습니다. 프로그램을 껐다 켜서 최신 버전으로 업데이트하거나, 통검체크에서 측정을 한 번 돌려주세요.")
    # 측정결과: Supabase 공유(실시간) + 로컬 병합(로컬이 더 최신이면)
    meas = supa_measurements(brand.get("name") or "")
    tg = brand.get("tonggeom") or load_cfg()["tonggeom_dir"]
    for k, v in jload(os.path.join(tg, "통검_측정.json"), {}).items():
        if k not in meas or v.get("date", "") > meas[k].get("date", ""):
            meas[k] = v
    core = fetch_brand_core(brand.get("homepage") or "")
    impw = {"상": 3.0, "중": 2.0, "하": 1.0, "x": 0.0, "": 1.5}
    out = []
    for r in data:
        iw = impw.get(str(r.get("importance", "")).strip(), 1.5)
        if iw <= 0:
            continue
        vol = r.get("volume") or 0
        m = meas.get(r["keyword"])
        state = "미측정" if not m else ("노출" if m.get("hits") else "미노출")
        opp = 0.6 if state == "노출" else 1.0
        bare = r["keyword"].replace(" ", "")
        ach = 0.3 if (len(bare) <= 3 and vol >= 2000) else 1.0
        fit = _brand_fit(r["keyword"], core)
        sc = (fit ** 1.6) * iw * math.log10(min(vol, 12000) + 10) * opp * ach
        out.append({"keyword": r["keyword"], "category": r.get("category", ""),
                    "volume": vol, "importance": r.get("importance", ""), "state": state,
                    "score": round(sc, 2)})
    out.sort(key=lambda x: -x["score"])
    return jsonify(items=out[:40])


# ── 브랜드 관리 ──────────────────────────────────────────
@app.route("/api/version")
def api_version():
    return jsonify(version=jload(os.path.join(HERE, "version.json"), {}).get("version", "?"))


@app.route("/api/brands")
def api_brands():
    return jsonify(brands=brands.list_brands())


@app.route("/api/brand")
def api_brand():
    return jsonify(brands.load_brand(request.args.get("id") or "haofactory"))


@app.route("/api/brand-save", methods=["POST"])
def api_brand_save():
    cfg = request.get_json(force=True) or {}
    if not (cfg.get("name") or "").strip():
        return jsonify(ok=False, msg="브랜드 이름을 입력하세요.")
    # 콤마 문자열로 들어온 type_words 정규화
    tw = cfg.get("type_words")
    if isinstance(tw, str):
        cfg["type_words"] = [t.strip() for t in re.split(r"[,\n]", tw) if t.strip()]
    ch = cfg.get("card_headlines")
    if isinstance(ch, str):
        cfg["card_headlines"] = [t.strip() for t in ch.split("\n") if t.strip()]
    # 이미 있는 브랜드를 앱에서 수정하면 → 오버라이드(작성기_설정.json)에 저장해 업데이트에도 유지(C7).
    # 새 브랜드 생성은 base(brands/<id>/brand.json)에 저장해야 목록에 뜨고 배포 대상이 됨.
    bid0 = cfg.get("id") or brands.slugify(cfg.get("name", ""))
    if os.path.isfile(os.path.join(brands.brand_dir(bid0), "brand.json")):
        bid = brands.save_override(cfg)
    else:
        bid = brands.save_brand(cfg)
    return jsonify(ok=True, id=bid, brand=brands.load_brand(bid))


# 통검체크 dist 루트 + 브랜드 id/색 매핑
TONGGEOM_DIST = r"C:/Users/이건희/trevity-노출체크/dist"
_TG_MAP = {  # 통검 폴더 브랜드명 → (id, 색)
    "하오팩토리": ("haofactory", "#FD6F22"), "하오디자인": ("haodesign", "#16A34A"),
    "하오스튜디오": ("haostudio", "#7C3AED"), "퍼스트디자인": ("firstdesign", "#3B82F6"),
    "레드트랜스": ("redtrans", "#E11D48"), "윈차이나": ("winchina", "#DC2626"),
}


def sync_tonggeom_brands():
    """통검체크 dist의 '<브랜드> 통검체크' 폴더를 스캔 → 브랜드 생성/연결(기존 커스텀 필드는 보존)."""
    added, linked = [], []
    if not os.path.isdir(TONGGEOM_DIST):
        return {"added": added, "linked": linked, "err": "dist 폴더 없음"}
    for d in sorted(os.listdir(TONGGEOM_DIST)):
        full = os.path.join(TONGGEOM_DIST, d)
        if not (os.path.isdir(full) and d.endswith("통검체크")):
            continue
        bname = d.replace("통검체크", "").strip()
        bid, color = _TG_MAP.get(bname, (brands.slugify(bname), "#3B82F6"))
        hp = ""
        try:
            hp = jload(os.path.join(full, "통검_설정.json"), {}).get("homepage", "")
        except Exception:
            pass
        existed = os.path.isfile(os.path.join(brands.brand_dir(bid), "brand.json"))
        cfg = brands.load_brand(bid) if existed else dict(brands.DEFAULTS)
        cfg["id"] = bid
        cfg["name"] = bname
        cfg["tonggeom"] = full
        if hp:
            cfg["homepage"] = hp if hp.startswith("http") else "https://" + hp
        if not existed:
            cfg["color"] = color
        brands.save_brand(cfg)
        # 키워드 목록(통검_데이터.json)을 브랜드 폴더에 동봉 → 배포 시 어느 PC에서도 추천 작동
        try:
            kw = os.path.join(full, "통검_데이터.json")
            if os.path.isfile(kw):
                shutil.copy(kw, os.path.join(brands.brand_dir(bid), "tonggeom_data.json"))
        except Exception:
            pass
        (linked if existed else added).append(bname)
    return {"added": added, "linked": linked}


@app.route("/api/sync-brands", methods=["POST"])
def api_sync_brands():
    return jsonify(ok=True, **sync_tonggeom_brands())


@app.route("/api/preview-cards", methods=["POST"])
def api_preview_cards():
    """브랜드 카드 템플릿을 샘플 사진/문구로 렌더 — 최종 체크용 미리보기."""
    b = request.get_json(force=True) or {}
    bid = b.get("brand") or "haofactory"
    tpl = str(b.get("template") or "1")
    brand = brands.load_brand(bid)
    adir = brands.assets_dir(bid, tpl)
    if not os.path.isfile(os.path.join(adir, "layout.json")):
        return jsonify(ok=False, msg="이 브랜드는 카드 템플릿이 없습니다.")
    # 샘플 사진: 탭 폴더 → 데스크톱 drive-download → Pictures 순
    files, folder = [], b.get("folder") or ""
    if folder and os.path.isdir(folder):
        files = list_images(folder, cap=300)
    if not files:
        for cand in glob.glob(os.path.join(os.path.expanduser("~"), "Desktop", "drive-download*")) + \
                    [os.path.join(os.path.expanduser("~"), "Pictures")]:
            if os.path.isdir(cand):
                fl = list_images(cand, cap=300)
                if fl:
                    folder, files = cand, fl
                    break
    random.shuffle(files)
    n = len(jload(os.path.join(adir, "layout.json"), {}).get("slides", [])) or 7
    photo_paths = [os.path.join(folder, f) for f in files[:n]] or [""]
    # 샘플 문구
    heads_raw = brand.get("card_headlines") or []
    heads = []
    for i in range(7):
        h = re.sub(r"\([^)]*\)", "", heads_raw[i]).strip() if i < len(heads_raw) else ""
        heads.append(h or f"샘플 헤드라인 {i+1}")
    bodies = ["샘플 본문 설명이 들어가는 자리입니다."] * 7
    pdir = os.path.join(OUT_DIR, "_preview_" + bid)
    shutil.rmtree(pdir, ignore_errors=True)
    try:
        res = cardnews_pil.make_cards(photo_paths, heads, pdir, adir,
                                      subtitle="이 글 주제를 한 줄로 요약한 부제",
                                      bodies=bodies, title=f"{brand['name']} 샘플 제목, 핵심을 한 줄로 보여주는 미리보기")
        return jsonify(ok=True, dir=pdir, pngs=res["pngs"], name=brand["name"])
    except Exception as e:
        return jsonify(ok=False, msg=str(e)[:200])


def _sample_photo():
    """썸네일용 샘플 사진 1장(데스크톱 drive-download → Pictures)."""
    for cand in glob.glob(os.path.join(os.path.expanduser("~"), "Desktop", "drive-download*")) + \
                [os.path.join(os.path.expanduser("~"), "Pictures")]:
        if os.path.isdir(cand):
            fl = list_images(cand, cap=50)
            if fl:
                return os.path.join(cand, fl[0])
    return ""


@app.route("/api/template-thumb")
def api_template_thumb():
    """카드 디자인 슬롯의 표지를 썸네일로 렌더(선택기용). layout.json 바뀌면 자동 갱신."""
    bid = request.args.get("brand", "haofactory")
    tpl = str(request.args.get("template", "1") or "1")
    adir = brands.assets_dir(bid, tpl)
    lp = os.path.join(adir, "layout.json")
    if not os.path.isfile(lp):
        return ("", 404)
    cache = os.path.join(OUT_DIR, f"_thumb_{bid}_{tpl}.png")
    if (not os.path.isfile(cache)) or os.path.getmtime(cache) < os.path.getmtime(lp):
        brand = brands.load_brand(bid)
        heads = brand.get("card_headlines") or []
        kw = (re.sub(r"\([^)]*\)", "", heads[0]).strip() if heads else "") or "샘플 키워드"
        try:
            cardnews_pil.render_card(0, _sample_photo(), kw, (210, 90, 120), cache, adir,
                                     subtitle="주제를 한 줄로 요약한 부제", title=kw)
        except Exception as e:
            return (str(e)[:120], 500)
    r = send_file(cache)
    r.headers["Cache-Control"] = "no-store, max-age=0"
    return r


@app.route("/api/brand-template", methods=["POST"])
def api_brand_template():
    """브랜드 카드뉴스 PPTX 템플릿 등록 → 장식/레이아웃 추출."""
    b = request.get_json(force=True) or {}
    bid = b.get("id") or ""
    pptx = b.get("pptx") or ""
    if not (bid and os.path.isfile(pptx) and pptx.lower().endswith(".pptx")):
        return jsonify(ok=False, msg="브랜드 또는 PPTX 경로가 올바르지 않습니다.")
    try:
        r = cardnews_pil.extract_template(pptx, brands.assets_dir(bid))
        return jsonify(ok=True, **r)
    except Exception as e:
        return jsonify(ok=False, msg=str(e)[:200])


@app.route("/api/brand-template-file", methods=["POST"])
def api_brand_template_file():
    """브랜드 카드뉴스 PPTX 직접 업로드 → 추출(파일 선택 방식)."""
    bid = request.form.get("id", "")
    slot = str(request.form.get("slot", "1") or "1")
    f = request.files.get("file")
    if not (bid and f and f.filename.lower().endswith(".pptx")):
        return jsonify(ok=False, msg="브랜드와 PPTX 파일이 필요합니다.")
    tmp = os.path.join(OUT_DIR, f"_tpl_{bid}.pptx")
    try:
        f.save(tmp)
        r = cardnews_pil.extract_template(tmp, brands.assets_dir(bid, slot))
        return jsonify(ok=True, slot=slot, **r)
    except Exception as e:
        return jsonify(ok=False, msg=str(e)[:200])
    finally:
        try:
            os.remove(tmp)
        except Exception:
            pass


@app.route("/api/generate", methods=["POST"])
def api_generate():
    b = request.get_json(force=True)
    keyword = (b.get("keyword") or "").strip()
    folder = b.get("folder") or ""
    hint = (b.get("hint") or "").strip()
    subkeyword = (b.get("subkeyword") or "").strip()   # b는 아래 루프에서 덮어써지므로 먼저 읽음
    title = (b.get("title") or "").strip()
    question = (b.get("question") or "").strip()      # 독자의 실제 질문(선택) → 제목·글이 이 질문에 답함
    tpl = str(b.get("template") or "1")   # 카드 디자인 슬롯(b는 아래 루프에서 덮어써지므로 먼저 읽음)
    if not keyword:
        return jsonify(ok=False, msg="키워드를 입력하세요.")
    brand = brands.load_brand(b.get("brand") or "haofactory")
    card_dir = (b.get("card_dir") or "").strip()
    card_lock = []                                      # ★카드 N번에 고정할 사진(사용자가 교체·배치한 그대로)
    if b.get("use_card_photos") and card_dir and os.path.isdir(card_dir):
        # 현재 카드뉴스에 들어 있는 사진(교체 반영된 cards.json src)을 입력 사진으로 사용 — 카드 순서 그대로
        st_c = jload(os.path.join(card_dir, "cards.json"), {})
        seen, files = set(), []
        for c in (st_c.get("cards") or []):
            sp = (c.get("src") or "").strip()
            if sp and os.path.isfile(sp) and sp.lower() not in seen:
                seen.add(sp.lower()); files.append(sp)
        if not files:
            return jsonify(ok=False, msg="카드뉴스 사진을 찾지 못했습니다. 카드 폴더가 이동/삭제됐는지 확인하세요.")
        card_lock = list(files)                         # 표지(1번) 포함 순서 고정 — 다시 섞지 않는다
    else:
        picked = [f for f in (b.get("files") or []) if os.path.isfile(os.path.join(folder, f))]
        files = picked[:150] if picked else None
    if files:                                           # 특정 사진 지정(카드 사진 or 사용자가 고른 사진), 순서 그대로
        pass
    else:
        files = list_images(folder, cap=20000)          # 전체 다 가져와서
        files = filter_by_keyword(files, keyword, brand["type_words"])   # 키워드 매칭(브랜드 타입단어)
        random.shuffle(files)                           # ★매 생성마다 다른 순서(Claude도 매번 다르게 고름)
        files = files[:150]
    model = (b.get("model") or load_cfg().get("model") or "opus")
    portfolio = bool(b.get("portfolio"))               # 포트폴리오 모드(사진 직접 열어보고 사례 글)
    # web_update 브랜드(레드트랜스·윈차이나)는 작성 전 웹검색으로 최신 '공개 정보'를 먼저 확인(회사 가격·절차는 기준서 유지)
    latest = fetch_latest_info(keyword) if (brand.get("web_update") and not portfolio) else ""
    if portfolio:
        pf_files = files[:7]                            # 이 프로젝트 대표 사진 7장(읽고+배치)
        pf_paths = [os.path.join(folder, f) for f in pf_files]
        prompt = build_prompt(keyword, pf_files, hint + (("\n[독자의 질문] " + question) if question else ""), brand, subkeyword, title, latest,
                              portfolio=True, photo_paths=pf_paths)
        out, err = run_claude(prompt, model, tools="Read", timeout=480)   # 사진 읽기 → 시간 더 줌
    elif brand.get("read_photos") and files:
        # 사진을 직접 열어보는 브랜드(퍼스트디자인 방식2): 슬롯 수만큼만 추려 실제로 읽게 한다
        n_read = brands.photo_slots(brand)
        rd_files = files[:n_read]
        rd_paths = [os.path.join(folder, f) for f in rd_files]
        prompt = build_prompt(keyword, rd_files, hint, brand, subkeyword, title, latest, photo_paths=rd_paths, question=question)
        out, err = run_claude(prompt, model, tools="Read", timeout=600)
    else:
        prompt = build_prompt(keyword, files, hint, brand, subkeyword, title, latest, question=question)
        out, err = run_claude(prompt, model)
    if err:
        return jsonify(ok=False, msg=err)
    mt = re.search(r"제목\s*[:：]", out)     # 앞에 붙는 머리말(포트폴리오: '사진 확인했습니다' 등) 제거
    if mt and mt.start() > 0:
        out = out[mt.start():]
    # 카드뉴스 헤드라인 분리
    parts = re.split(r"\n\s*카드뉴스\s*[:：]\s*\n?", out, maxsplit=1)
    cards, bodies = [], []
    if len(parts) > 1:
        for ln in parts[1].split("\n"):
            mm = re.match(r"^\s*\d+\s*[.)]\s*(.+)$", ln.strip())
            if mm:
                raw = mm.group(1)
                hpart, bpart = (raw.split("|", 1) + [""])[:2] if "|" in raw else (raw, "")
                h = re.sub(r"\([^)]*\)", "", hpart).strip() or hpart.strip()
                b = re.sub(r"\([^)]*\)", "", bpart).strip()
                cards.append(h); bodies.append(b)
    if cards:
        cards[0] = keyword   # 표지 큰 제목은 항상 메인키워드로 고정(전 브랜드 공통)
    sub = ""
    ms = re.search(r"표지\s*부제\s*[:：]\s*(.+)", out)
    if ms:
        sub = re.sub(r"\([^)]*\)", "", ms.group(1)).strip() or ms.group(1).strip()
    # ★'표차트:' 데이터 섹션이 카드뉴스보다 앞(본문 쪽)에 오는 경우가 있다.
    #   그대로 두면 (1) 글자수에 잡혀 분량이 부풀고 (2) 축약 재작성 때 통째로 지워져 표를 못 그린다.
    #   → 본문에서 떼어내 꼬리에 보관하고, 축약이 끝난 뒤 다시 붙인다.
    _body0, _tc = parts[0], ""
    _m_tc = re.search(r"\n\s*표\s*차트\s*[:：].*$", parts[0], re.S)
    if _m_tc:
        _body0, _tc = parts[0][:_m_tc.start()].rstrip() + "\n", _m_tc.group(0).strip()
    post = parse_manuscript(_body0, files)
    # ★분량 자동 보정 — 상한을 넘으면 앱이 직접 재요청해 압축(최대 2회). 모델은 글자수를 정확히 못 세서 자주 넘친다.
    _lo, _hi = brands.length_range(brand)
    _tail = (("\n\n" + _tc) if _tc else "") + (("\n\n카드뉴스:\n" + parts[1]) if len(parts) > 1 else "")
    _ms, _trims = _body0, 0
    for _ in range(3):
        if post.get("char_count", 0) <= _hi:
            break
        _new = trim_manuscript(brand, keyword, _ms, post["char_count"], _lo, _hi, model)
        if not _new:
            break
        _np = parse_manuscript(_new, files)
        if not _np.get("char_count") or _np["char_count"] >= post["char_count"]:
            break                                   # 줄지 않으면 원본 유지
        _ms, post, _trims = _new, _np, _trims + 1
        out = _ms + _tail
    # ★분량 하한 보정(brand.json length_fill=true 브랜드만) — 하한보다 짧으면 앱이 재요청해 보강(최대 2회).
    #   보강 후 상한을 넘으면 한 번 더 압축한다. 늘지 않거나 실패하면 원본 유지.
    _fills = 0
    if brand.get("length_fill"):
        for _ in range(2):
            if post.get("char_count", 0) >= _lo:
                break
            _new = expand_manuscript(brand, keyword, _ms, post["char_count"], _lo, _hi, model)
            if not _new:
                break
            _np = parse_manuscript(_new, files)
            if not _np.get("char_count") or _np["char_count"] <= post["char_count"]:
                break
            if _np["char_count"] > _hi:
                _t = trim_manuscript(brand, keyword, _new, _np["char_count"], _lo, _hi, model)
                _tp = parse_manuscript(_t, files) if _t else None
                if _tp and _tp.get("char_count") and _lo <= _tp["char_count"] <= _hi:
                    _new, _np = _t, _tp
                elif _np["char_count"] > _hi + 150:
                    break                           # 너무 길어졌는데 압축도 실패 → 원본 유지
            _ms, post, _fills = _new, _np, _fills + 1
            out = _ms + _tail
    post["trimmed"] = _trims
    post["filled"] = _fills
    if title:
        post["title"] = title                 # 사용자가 정한 제목을 그대로 사용(C2)
    post["folder"] = folder
    post["keyword"] = keyword
    post["question"] = question
    post["cards"] = cards[:7]
    post["card_bodies"] = bodies[:7]
    post["subtitle"] = sub
    post["raw"] = out
    post["brand"] = brand["id"]
    post["crm_line"] = crm_line(brand, post.get("title", ""))   # CRM 추적링크(브랜드별 설정, 없으면 '')
    post["len_min"], post["len_max"] = brands.length_range(brand)   # UI 분량 배지(브랜드별)
    post["sections"] = _section_list(_ms)        # C3: 부분 수정용 구간 목록(축약 후 본문 기준)
    chart_specs = parse_charts(out)               # C6: (표N)/(차트N) 마커에 대응하는 표·차트 데이터
    chart_specs = {cid: sp for cid, sp in chart_specs.items()
                   if any(b.get("cid") == cid for b in post["blocks"] if b.get("type") == "chart")}
    post["chart_specs"] = chart_specs
    # 카드뉴스 생성 (순수 PIL)
    post["cardnews"] = ""
    # 카드 7장 = 서로 다른 사진(Claude 매칭 우선 + 폴더 전체에서 분산 채움)
    claude_picks = [b["file"] for b in post["blocks"] if b["type"] == "photo" and b.get("file")]
    adir = brands.assets_dir(brand["id"], tpl)
    has_tpl = os.path.isfile(os.path.join(adir, "layout.json"))
    n_cards = 7
    if has_tpl:
        try:
            n_cards = len(jload(os.path.join(adir, "layout.json"), {}).get("slides", [])) or 7
        except Exception:
            n_cards = 7
    if card_lock:                                       # ★사용자가 정한 카드 순서 유지(표지 = 1번 그대로)
        card_files = card_lock[:n_cards]
        if len(card_files) < n_cards:                   # 카드 수보다 사진이 적으면 나머지만 보충
            rest = pick_diverse([f for f in files if f not in card_files], claude_picks, n_cards - len(card_files))
            card_files += [f for f in rest if f not in card_files]
    else:
        card_files = pick_diverse(files, claude_picks, n_cards)
    post["cardnews_pngs"] = []
    post["cardnews_job"] = ""
    if card_files and len(cards) >= 6 and has_tpl:
        import uuid
        jid = uuid.uuid4().hex[:10]
        CARD_JOBS[jid] = {"status": "rendering"}
        post["cardnews_job"] = jid
        photo_paths = [os.path.join(folder, f) for f in card_files]
        threading.Thread(target=_cardnews_job, args=(jid, photo_paths, cards, keyword, adir, sub, bodies, post.get("title", ""), chart_specs, brand.get("table_width")), daemon=True).start()
    return jsonify(ok=True, post=post)


# ── C3: 생성 후 부분 수정 (chat으로 한 구간만 다시 쓰기) ──────────
_HEAD_RE = re.compile(r"^\s*\*\*.+\*\*\s*$")
_PHOTO_LINE_RE = re.compile(r"^\s*\(사진")
_TITLE_LINE_RE = re.compile(r"^제목\s*[:：]")


def _split_manuscript(raw):
    """raw(전체 출력)에서 '카드뉴스:' 앞의 원고 부분(ms)과 나머지(tail)를 분리."""
    ms = re.split(r"\n\s*카드뉴스\s*[:：]\s*\n?", raw, maxsplit=1)[0]
    return ms, raw[len(ms):]


def _sections(lines):
    """원고 줄 목록 → 논리 구간(도입 + 소제목1~N). 각 {id,label,start,end(줄 인덱스)}."""
    heads = [i for i, l in enumerate(lines) if _HEAD_RE.match(l)]
    title_idx = next((i for i, l in enumerate(lines) if _TITLE_LINE_RE.match(l)), None)
    secs = []
    intro_start = (title_idx + 1) if title_idx is not None else 0
    first = heads[0] if heads else len(lines)
    secs.append({"id": "intro", "label": "도입", "start": intro_start, "end": first})
    for k, h in enumerate(heads):
        end = heads[k + 1] if k + 1 < len(heads) else len(lines)
        htxt = re.sub(r"\*", "", lines[h]).strip()
        secs.append({"id": "sub%d" % (k + 1), "label": htxt or ("소제목 %d" % (k + 1)),
                     "start": h, "end": end})
    return secs


def _section_list(ms):
    """프론트 버튼용 구간 목록(글 전체 + 제목 + 도입 + 소제목들)."""
    out = [{"id": "all", "label": "📄 글 전체"}, {"id": "title", "label": "제목"}]
    for s in _sections(ms.split("\n")):
        out.append({"id": s["id"], "label": s["label"][:24]})
    return out


def _edit_call(brand, keyword, partname, old_text, instruction, model):
    """한 구간만 사용자 지시대로 다시 쓰게 하는 집중 프롬프트."""
    style = brands.build_style(brand) if brand else STYLE
    p = (style + "\n\n[부분 수정 작업 — 글 전체가 아니라 아래 한 부분만 고친다]\n"
         f"아래는 '{keyword}' 블로그 글의 '{partname}' 부분이다. 사용자의 요청대로 이 부분만 자연스럽게 다시 써라.\n"
         f"[사용자 요청] {instruction}\n"
         "[규칙]\n"
         "- 이 구간의 텍스트만 고쳐서 출력한다. 다른 구간·제목·인사말을 새로 만들지 않는다.\n"
         "- 브랜드 문체·톤·한 문장마다 줄바꿈 규칙을 그대로 유지한다.\n"
         "- (사진N: ...) 같은 사진 표시 줄은 출력에 절대 넣지 마라(자동으로 원위치 유지된다).\n"
         "- 맨 앞의 **소제목** 줄(별표 두 개)이 원문에 있으면 형식을 유지한다(요청이 소제목 변경이면 그 줄만 바꾼다).\n"
         "- 특별한 요청이 없으면 길이는 원문과 비슷하게. 억지로 늘리거나 줄이지 마라.\n"
         "- 설명·머리말·따옴표·코드블록 없이 수정된 본문 텍스트만 출력한다.\n\n"
         f"[현재 '{partname}' 원문]\n{old_text}\n\n[수정본만 출력]")
    out, err = run_claude(p, model)
    return ("" if err else (out or "").strip())


def _edit_whole(brand, keyword, ms, instruction, model):
    """글 전체에 사용자 요청을 적용해 다시 쓴다(톤·분량 등 공통 수정용). 구조·마커는 그대로 유지."""
    style = brands.build_style(brand) if brand else STYLE
    p = (style + "\n\n[글 전체 다듬기 — 아래 원고 '전체'에 사용자 요청을 반영해 다시 쓴다]\n"
         f"'{keyword}' 블로그 글 원고 전체다. 사용자 요청을 글 전체에 적용해서 다시 써라.\n"
         f"[사용자 요청] {instruction}\n"
         "[반드시 지킬 것]\n"
         "- '제목:' 줄, 소제목(정확히 6개), (사진N) 줄, (표N)/(차트N) 줄을 그대로 유지한다(개수·위치·순서 보존, 마커를 지우거나 옮기지 말 것).\n"
         f"- 브랜드 문체·톤·구조를 지키고, 요청한 부분만 바꾼다. 분량 요청이 없으면 공백 제외 {brands._fmt_len(brand)}자.\n"
         "- 설명·머리말·따옴표·코드블록 없이 '제목:'부터 마지막 문단까지 다듬은 원고 전체만 출력한다(카드뉴스/표차트 섹션은 출력하지 말 것).\n\n"
         f"[원고]\n{ms}")
    out, err = run_claude(p, model)
    return ("" if err else (out or "").strip())


@app.route("/api/edit-section", methods=["POST"])
def api_edit_section():
    b = request.get_json(force=True)
    post = b.get("post") or {}
    sid = (b.get("section") or "").strip()
    instr = (b.get("instruction") or "").strip()
    if not instr:
        return jsonify(ok=False, msg="어떻게 고칠지 입력하세요.")
    if not sid:
        return jsonify(ok=False, msg="수정할 부분을 고르세요.")
    brand = brands.load_brand(b.get("brand") or post.get("brand") or "haofactory")
    keyword = post.get("keyword") or ""
    folder = post.get("folder") or ""
    raw = post.get("raw") or ""
    if not raw:
        return jsonify(ok=False, msg="이 글은 부분 수정을 지원하지 않습니다(다시 생성 후 사용).")
    model = (b.get("model") or load_cfg().get("model") or "opus")
    ms, tail = _split_manuscript(raw)
    lines = ms.split("\n")
    if sid == "all":
        new_ms = _edit_whole(brand, keyword, ms, instr, model)
        if not new_ms:
            return jsonify(ok=False, msg="수정 실패(빈 응답). 다시 시도하세요.")
    elif sid == "title":
        new_title = _edit_call(brand, keyword, "제목", post.get("title", ""), instr, model)
        if not new_title:
            return jsonify(ok=False, msg="수정 실패(빈 응답). 다시 시도하세요.")
        new_title = new_title.splitlines()[0].strip().lstrip("제목:： ").strip()
        done = False
        for i, l in enumerate(lines):
            if _TITLE_LINE_RE.match(l):
                lines[i] = "제목: " + new_title; done = True; break
        if not done:
            lines.insert(0, "제목: " + new_title)
        new_ms = "\n".join(lines)
    else:
        secs = _sections(lines)
        sec = next((s for s in secs if s["id"] == sid), None)
        if not sec:
            return jsonify(ok=False, msg="잘못된 구간입니다.")
        seg = lines[sec["start"]:sec["end"]]
        photos = [l for l in seg if _PHOTO_LINE_RE.match(l)]
        editable = "\n".join(l for l in seg if not _PHOTO_LINE_RE.match(l)).strip()
        newtxt = _edit_call(brand, keyword, sec["label"], editable, instr, model)
        if not newtxt:
            return jsonify(ok=False, msg="수정 실패(빈 응답). 다시 시도하세요.")
        nl = [l for l in newtxt.split("\n") if not _PHOTO_LINE_RE.match(l)]  # 혹시 사진줄 뱉으면 제거
        if sid.startswith("sub") and photos:
            if nl and _HEAD_RE.match(nl[0].strip()):
                rebuilt = [nl[0]] + photos + nl[1:]          # 소제목 → 사진 → 본문
            else:
                rebuilt = photos + nl
        elif photos:
            rebuilt = photos + nl                             # 도입: 사진1 먼저
        else:
            rebuilt = nl
        lines[sec["start"]:sec["end"]] = rebuilt
        new_ms = "\n".join(lines)
    files = list_images(folder, cap=20000) if folder else []
    newpost = parse_manuscript(new_ms, files)
    # 표·차트 이미지(cid별)는 재파싱하면 img가 비므로 기존 post에서 복원
    old_charts = {b.get("cid"): b for b in post.get("blocks", []) if b.get("type") == "chart"}
    for blk in newpost["blocks"]:
        if blk.get("type") == "chart" and blk.get("cid") in old_charts:
            ob = old_charts[blk["cid"]]
            blk["img"] = ob.get("img", ""); blk["spec"] = ob.get("spec")
    out = dict(post)                                          # 카드뉴스 등 기존 필드 보존
    out["title"] = newpost["title"] or post.get("title", "")
    out["crm_line"] = crm_line(brand, out["title"])
    out["blocks"] = newpost["blocks"]
    out["char_count"] = newpost["char_count"]
    out["raw"] = new_ms + tail
    out["sections"] = _section_list(new_ms)
    return jsonify(ok=True, post=out)


# ── 카드뉴스 색상 수동 변경 (이 글 카드만, 원하는 색으로) ──────────
@app.route("/api/recolor-cards", methods=["POST"])
def api_recolor_cards():
    b = request.get_json(force=True)
    cdir = b.get("cardnews_dir") or ""
    brand = (b.get("brand") or "").strip()
    hx = re.sub(r"[^0-9A-Fa-f]", "", (b.get("color") or ""))
    if not (cdir and os.path.isdir(cdir) and os.path.isfile(os.path.join(cdir, "cards.json"))):
        return jsonify(ok=False, msg="카드뉴스를 찾을 수 없습니다(먼저 카드 생성).")
    if len(hx) != 6:
        return jsonify(ok=False, msg="색상 코드(#RRGGBB)가 올바르지 않습니다.")
    col = [int(hx[i:i+2], 16) for i in (0, 2, 4)]
    note = ""
    # 하오스튜디오: 배경(녹색 띠)이 색을 받는데 흰색에 가까우면 흰 로고와 겹쳐 안 보임 → 명도 상한
    if brand == "haostudio" and min(col) > 205:
        import colorsys
        h, s, v = colorsys.rgb_to_hsv(*[c / 255 for c in col])
        s = max(s, 0.25); v = min(v, 0.78)
        col = [int(round(x * 255)) for x in colorsys.hsv_to_rgb(h, s, v)]
        note = "하오스튜디오는 흰 로고와 겹쳐서 너무 밝은 색은 살짝 진하게 조정했어요."
    try:
        pngs = cardnews_pil.recolor_cards(cdir, tuple(col))
        # 표·차트도 같은 색으로 다시 렌더(카드뉴스와 색 통일) — 프론트가 글의 chart 블록(cid·img·spec)을 보낸다
        tw = brands.load_brand(brand).get("table_width") if brand else None
        charts = 0
        for ch in (b.get("charts") or []):
            name = os.path.basename(str(ch.get("img") or ""))
            spec = ch.get("spec")
            if not (spec and re.match(r"^chart_.+\.png$", name)):
                continue
            try:
                charts_pil.render_spec(os.path.join(cdir, name), spec, tuple(col), W=tw)
                charts += 1
            except Exception:
                pass
        return jsonify(ok=True, pngs=pngs, charts=charts, color="%02X%02X%02X" % tuple(col), msg=note)
    except Exception as e:
        return jsonify(ok=False, msg=str(e)[:200])


# ── C6: 표·차트 수동 추가(버튼) ──────────────────────────
@app.route("/api/add-chart", methods=["POST"])
def api_add_chart():
    b = request.get_json(force=True)
    post = b.get("post") or {}
    raw = post.get("raw") or ""
    cdir = post.get("cardnews_dir") or ""
    brand = brands.load_brand(post.get("brand") or "haofactory")
    if not raw:
        return jsonify(ok=False, msg="원고가 없습니다.")
    if not (cdir and os.path.isdir(cdir)):
        return jsonify(ok=False, msg="카드뉴스가 만들어진 뒤에 표·차트를 추가할 수 있어요.")
    model = (b.get("model") or load_cfg().get("model") or "opus")
    ms = _split_manuscript(raw)[0]
    existing = [(blk.get("spec") or {}).get("title", "") for blk in post.get("blocks", []) if blk.get("type") == "chart"]
    prompt = (
        "아래 블로그 글 내용에서 독자에게 실제로 도움이 되는 '표' 또는 '차트'를 딱 1개만 만들어라.\n"
        "글에 담긴(또는 자연스럽게 유추되는) 정보를 바탕으로 비교·단계·비율·추이 중 가장 잘 맞는 형식을 고른다.\n"
        + ("이미 만든 것: " + " / ".join(x for x in existing if x) + " — 이것과 겹치지 않는 다른 관점으로.\n" if any(existing) else "")
        + "[출력 — 아래 중 한 줄만, 다른 설명 없이]\n"
        "표1 | 제목 | 헤더1,헤더2,헤더3 ; 항목,값,값 ; 항목,값,값\n"
        "차트1 | 막대 | 제목 | 라벨:숫자, 라벨:숫자, 라벨:숫자   (막대 대신 원/선 가능)\n"
        "- 수치 비교·추이면 차트(막대/선), 구성비면 원, 항목별 특성 비교면 표.\n"
        "- 값은 근거 있는 것만(지어내기 금지). 정확한 수치가 없으면 표로, 억지 숫자는 만들지 말 것.\n\n"
        "[글]\n" + ms)
    out, err = run_claude(prompt, model)
    if err:
        return jsonify(ok=False, msg=err)
    specs = parse_charts("표차트:\n" + (out or "").strip())
    if not specs:
        return jsonify(ok=False, msg="표·차트를 만들지 못했어요. 다시 시도해 주세요.")
    spec = next(iter(specs.values()))
    ex_cids = [blk.get("cid", "") for blk in post.get("blocks", []) if blk.get("type") == "chart"]
    n = 1
    while ("수동%d" % n) in ex_cids:
        n += 1
    cid = "수동%d" % n
    name = "chart_%s.png" % cid
    try:
        charts_pil.render_spec(os.path.join(cdir, name), spec, article_color(cdir, brand), W=brand.get("table_width"))
    except Exception as e:
        return jsonify(ok=False, msg="렌더 실패: " + str(e)[:120])
    blk = {"type": "chart", "cid": cid, "img": name, "spec": spec}
    idx = len(post["blocks"])
    for i in range(len(post["blocks"]) - 1, -1, -1):    # 마지막 텍스트(마무리) 앞에 삽입
        if post["blocks"][i].get("type") == "text":
            idx = i; break
    post["blocks"].insert(idx, blk)
    return jsonify(ok=True, post=post)


# ── 제목 추천 (AEO/GEO — geo-tracker 고객 질문 기반) ──────────────
GEO_RESULTS_DIR = r"C:/geo-tracker/results"


def geo_questions(bid, cap=24):
    """geo-tracker 결과에서 이 브랜드 고객이 AI에 묻는 질문 + 인용 여부. 없으면 []."""
    try:
        fs = sorted(glob.glob(os.path.join(GEO_RESULTS_DIR, f"{bid}-*.json")))
        if not fs:
            return []
        d = jload(fs[-1], {})                 # 파일명에 날짜 → 마지막이 최신
        qs = d.get("questions") or []
        cells = d.get("cells") or {}
        out = []
        for i, q in enumerate(qs):
            cited = any((cells.get(f"{i}:{p}") or {}).get("cited")
                        for p in ("naver", "google", "chatgpt", "perplexity"))
            out.append({"q": q, "cited": bool(cited)})
        return out[:cap]
    except Exception:
        return []


@app.route("/api/title-suggest", methods=["POST"])
def api_title_suggest():
    """제목 제안. mode='geo' → geo-tracker 고객 질문 기반 AEO/GEO. mode='ai' → 메인/서브키워드만으로 창의적 제안."""
    b = request.get_json(force=True) or {}
    keyword = (b.get("keyword") or "").strip()
    subkeyword = (b.get("subkeyword") or "").strip()
    question = (b.get("question") or "").strip()
    mode = (b.get("mode") or "geo").strip()
    if not keyword:
        return jsonify(ok=False, msg="메인키워드를 먼저 입력하세요.")
    brand = brands.load_brand(b.get("brand") or "haofactory")
    subrule = (f"- 서브키워드 '{subkeyword}'가 있다. 메인키워드와 겹치는 부분은 빼고, 나머지 핵심어만 제목에 자연스럽게 녹인다.\n"
               if subkeyword else "")
    if question:
        subrule += (f"- ★독자의 실제 질문이 있다: \"{question}\" — 5개 모두 이 질문의 핵심 궁금증(업종·상황·조건)을 메인키워드와 결합한 제목으로 짓는다. "
                    "질문 문장을 베끼지 말고 검색창에 치는 형태로 다듬되 메인키워드는 반드시 넣는다.\n")
    kwline = f"[메인키워드] {keyword}\n" + (f"[서브키워드] {subkeyword}\n" if subkeyword else "") + (f"[독자의 질문] {question}\n" if question else "")
    used_geo = False
    if mode == "geo":
        qs = geo_questions(brand["id"])
        # 브랜드명이 든 질문은 제목 소스에서 제외 — 고객은 브랜드명으로 검색하지 않음
        _bn = (brand.get("name") or "").replace(" ", "")
        _lbl = (brand.get("label") or "").replace(" ", "").lower()
        qs = [q for q in qs if _bn not in q["q"].replace(" ", "")
              and (not _lbl or _lbl not in q["q"].replace(" ", "").lower())]
        geo_block = ""
        if qs:
            qs.sort(key=lambda x: x["cited"])     # 미인용(기회) 먼저
            qlines = "\n".join(("★ " if not x["cited"] else "· ") + x["q"] for x in qs[:20])
            geo_block = ("아래는 이 브랜드 고객이 실제로 AI(네이버 AI·ChatGPT 등)에 자주 묻는 질문이다. "
                         "★는 아직 이 브랜드가 AI 답변에 인용되지 못한 질문(=인용 기회가 큼):\n" + qlines + "\n\n")
            used_geo = True
        prompt = (f"너는 '{brand['name']}'의 네이버 블로그 제목을 짓는 SEO·AEO·GEO 전문가다.\n" + kwline + "\n" + geo_block +
                  "[규칙]\n"
                  "- 철저히 '고객 관점'으로 짓는다. 고객은 브랜드명으로 검색하지 않으니, 제목에 브랜드명('" + brand["name"] + "')을 절대 넣지 말 것(예외 없음). 브랜드를 홍보하려 하지 말고 고객의 궁금증만 담는다.\n"
                  "- 두 유형을 섞는다: (1) 메인키워드가 들어간 제목(예: '브로슈어 제작 잘하는 곳'), (2) 키워드는 없어도 고객의 상황·업종 맥락을 담은 제목(예: '전시회 준비, 지금 뭐부터 해야 할까').\n"
                  "- 위 고객 질문(특히 ★)을 정조준하고, 실제로 검색·질문하는 형태로. 질문형 우선하되 단정형도 섞어 다양하게.\n" + subrule +
                  "- 서로 다른 각도로 정확히 5개. 각 제목은 한 줄, 25자 내외.\n"
                  "오직 제목 5개만 출력한다(형식: 1. 제목 / 2. 제목 ... 다른 설명·머리말·따옴표 금지).")
    else:  # ai — geo 데이터 없이 키워드만으로 창의적 제안
        prompt = (f"너는 '{brand['name']}'의 네이버 블로그 제목을 짓는 감각 좋은 SEO 카피라이터다.\n" + kwline + "\n"
                  "[규칙]\n"
                  "- 철저히 '고객 관점'으로. 고객은 브랜드명으로 검색하지 않으니 제목에 브랜드명('" + brand["name"] + "')을 절대 넣지 말 것(예외 없음).\n"
                  "- 두 유형을 섞는다: (1) 메인키워드가 들어간 제목, (2) 키워드는 없어도 고객의 상황·업종 맥락을 담은 제목(예: '전시회 준비, 지금 뭐부터').\n"
                  "- 클릭하고 싶게, 검색에도 강하게. 질문형·단정형·숫자형·호기심형 등 서로 확실히 다른 스타일로 5개. 과장·낚시성은 금지.\n" + subrule +
                  "- 각 제목은 한 줄, 25자 내외.\n"
                  "오직 제목 5개만 출력한다(형식: 1. 제목 / 2. 제목 ... 다른 설명·머리말·따옴표 금지).")
    # 브랜드 스크립트(prompt.md)에 [제목] 규칙이 있으면 그 규칙이 위 일반 규칙(25자 내외·키워드 없는 유형 등)보다 우선
    trule = brands.title_rules(brand)
    if trule:
        prompt += ("\n\n[★이 브랜드의 제목 규칙 — 위 일반 규칙과 충돌하면 이쪽이 우선. 글자 수·키워드 포함 여부·형태 모두 이 규칙대로]\n" + trule +
                   "\n- 5개 모두 이 규칙을 만족해야 한다(메인키워드 없는 제목 금지, 글자 수 범위 준수).")
    out, err = run_claude(prompt, b.get("model") or "sonnet")   # 제목은 빠른 모델로 충분
    if err:
        return jsonify(ok=False, msg=err)
    titles = []
    for ln in (out or "").split("\n"):
        m = re.match(r"^\s*\d+\s*[.)]\s*(.+)$", ln.strip())
        if m:
            t = re.sub(r'^["\'“‘\-•\s]+|["\'”’\s]+$', "", m.group(1)).strip()
            if t:
                titles.append(t)
    return jsonify(ok=True, titles=titles[:5], geo=used_geo, mode=mode)


@app.route("/api/crm-post", methods=["POST"])
def api_crm_post():
    """네이버에 수동 게시한 글을 CRM 게시 현황에 보고. body: {brand, title, keyword, url}"""
    b = request.get_json(force=True) or {}
    brand = brands.load_brand(b.get("brand") or "firstdesign")
    url = (b.get("url") or "").strip()
    title = (b.get("title") or "").strip()
    if not title:
        return jsonify(ok=False, msg="제목이 없습니다.")
    if url and "blog.naver.com" not in url:
        return jsonify(ok=False, msg="네이버 블로그 글 URL을 붙여넣어 주세요.")
    ok, msg = crm_report_post(brand, title, (b.get("keyword") or "").strip(), url)
    return jsonify(ok=ok, msg=msg)


@app.route("/api/cardnews-status")
def api_cardnews_status():
    j = CARD_JOBS.get(request.args.get("id", ""), {"status": "unknown"})
    return jsonify(j)


# 파일 선택 대화상자를 STA PowerShell로 띄우는 스크립트(TopMost 소유자 폼 → 항상 앞에)
_PS_PICKFILE = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
# 투명(Opacity=0)·TopMost 소유자 폼을 '마우스 커서가 있는 모니터' 중앙에 둔다
# → 방금 버튼을 누른 그 화면에 대화상자가 뜨고(멀티모니터 대응), 항상 앞에 온다
$owner = New-Object System.Windows.Forms.Form
$owner.FormBorderStyle = 'None'
$owner.Opacity = 0
$owner.ShowInTaskbar = $false
$owner.TopMost = $true
$owner.StartPosition = 'Manual'
$owner.Size = New-Object System.Drawing.Size(2, 2)
$cur = [System.Windows.Forms.Cursor]::Position
$area = [System.Windows.Forms.Screen]::FromPoint($cur).WorkingArea
$owner.Location = New-Object System.Drawing.Point([int]($area.X + $area.Width / 2), [int]($area.Y + $area.Height / 2))
$owner.Add_Shown({ $owner.Activate(); $owner.BringToFront() })
$owner.Show()
[System.Windows.Forms.Application]::DoEvents()
$dlg = New-Object System.Windows.Forms.OpenFileDialog
$dlg.Title = '카드에 넣을 사진 선택'
$dlg.Filter = '이미지 파일|*.jpg;*.jpeg;*.png;*.webp;*.gif|모든 파일|*.*'
if ($env:PICKDIR -and (Test-Path -LiteralPath $env:PICKDIR)) { $dlg.InitialDirectory = $env:PICKDIR }
$res = $dlg.ShowDialog($owner)
$owner.Close()
if ($res -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($dlg.FileName) }
"""

# 폴더 선택 — 윈도우 탐색기 스타일 대화상자(OpenFileDialog의 폴더 선택 트릭:
# 파일명 검증을 끄고 가짜 파일명으로 [열기] → 그 폴더 경로를 얻는다. FolderBrowserDialog(구식 트리)보다 훨씬 편함)
_PS_PICKFOLDER = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$owner = New-Object System.Windows.Forms.Form
$owner.FormBorderStyle = 'None'
$owner.Opacity = 0
$owner.ShowInTaskbar = $false
$owner.TopMost = $true
$owner.StartPosition = 'Manual'
$owner.Size = New-Object System.Drawing.Size(2, 2)
$cur = [System.Windows.Forms.Cursor]::Position
$area = [System.Windows.Forms.Screen]::FromPoint($cur).WorkingArea
$owner.Location = New-Object System.Drawing.Point([int]($area.X + $area.Width / 2), [int]($area.Y + $area.Height / 2))
$owner.Add_Shown({ $owner.Activate(); $owner.BringToFront() })
$owner.Show()
[System.Windows.Forms.Application]::DoEvents()
$dlg = New-Object System.Windows.Forms.OpenFileDialog
$dlg.Title = '사진 폴더 선택 - 폴더째 쓰려면 그 폴더 안에서 그냥 [열기], 특정 사진만 쓰려면 사진을 클릭(Ctrl로 여러 장)'
$dlg.CheckFileExists = $false
$dlg.CheckPathExists = $true
$dlg.ValidateNames = $false
$dlg.Multiselect = $true
$dlg.FileName = '이 폴더 선택'
$dlg.Filter = '사진·폴더|*.jpg;*.jpeg;*.png;*.webp;*.gif'
if ($env:PICKDIR -and (Test-Path -LiteralPath $env:PICKDIR)) { $dlg.InitialDirectory = $env:PICKDIR }
$res = $dlg.ShowDialog($owner)
$owner.Close()
if ($res -eq [System.Windows.Forms.DialogResult]::OK) {
    # 실제 존재하는 파일을 골랐으면 그 파일들, 자리표시 이름 그대로 [열기]면 폴더 선택
    $files = @($dlg.FileNames | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf })
    if ($files.Count -gt 0) {
        [Console]::Out.Write(($files -join '|'))
    } else {
        $p = [System.IO.Path]::GetDirectoryName($dlg.FileName)
        if ($p -and (Test-Path -LiteralPath $p)) { [Console]::Out.Write($p) }
    }
}
"""


@app.route("/api/pick-file", methods=["POST"])
def api_pick_file():
    """PowerShell '파일 열기' 대화상자로 이미지 1장 선택 → 절대경로 반환(느린 썸네일 그리드 대체)."""
    b = request.get_json(silent=True) or {}
    initdir = b.get("folder") or os.path.join(os.path.expanduser("~"), "Pictures")
    # 파일 대화상자를 별도 PowerShell 프로세스(STA)로 띄운다 — TopMost 소유자 폼을 owner로 줘서
    # 앱(브라우저) 뒤로 숨지 않고 항상 앞에 뜨게 한다. (Flask 배경 스레드의 win32 대화상자는 포그라운드를 못 잡아 뒤로 숨던 문제 해결)
    try:
        ps1 = os.path.join(OUT_DIR, "_pickfile.ps1")
        with open(ps1, "w", encoding="utf-8-sig") as f:
            f.write(_PS_PICKFILE)
        env = dict(os.environ)
        env["PICKDIR"] = initdir
        r = subprocess.run(
            ["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", ps1],
            capture_output=True, timeout=300, env=env)
        path = (r.stdout or b"").decode("utf-8", "ignore").strip()
        return jsonify(ok=True, path=path)          # 취소하면 path="" → 프론트에서 조용히 무시
    except Exception:
        return jsonify(ok=False, canceled=True)


@app.route("/api/pick-folder", methods=["POST"])
def api_pick_folder():
    """PowerShell 탐색기 대화상자로 사진 폴더 선택 → 절대경로 반환(웹 폴더 브라우저 대체)."""
    b = request.get_json(silent=True) or {}
    initdir = b.get("folder") or os.path.join(os.path.expanduser("~"), "Downloads")
    try:
        ps1 = os.path.join(OUT_DIR, "_pickfolder.ps1")
        with open(ps1, "w", encoding="utf-8-sig") as f:
            f.write(_PS_PICKFOLDER)
        env = dict(os.environ)
        env["PICKDIR"] = initdir
        r = subprocess.run(
            ["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", ps1],
            capture_output=True, timeout=300, env=env)
        out = (r.stdout or b"").decode("utf-8", "ignore").strip()
        if not out:
            return jsonify(ok=True, path="")        # 취소 → 프론트에서 조용히 무시
        parts = [p for p in out.split("|") if p]
        if len(parts) == 1 and os.path.isdir(parts[0]):
            return jsonify(ok=True, path=parts[0])  # 폴더째 선택
        # 특정 사진들 선택 → 폴더 + 상대 파일명 목록(이 사진들만 사용)
        fldr = os.path.dirname(parts[0])
        names = [os.path.basename(p) for p in parts if os.path.isfile(p)]
        return jsonify(ok=True, path="", folder=fldr, files=names)
    except Exception:
        return jsonify(ok=False)


@app.route("/api/swap-card", methods=["POST"])
def api_swap_card():
    """카드 1장의 사진만 교체 → 그 카드만 재렌더(전체 재생성 X)."""
    b = request.get_json(force=True)
    cdir = b.get("cardnews_dir", "")
    folder = b.get("folder", "")
    idx = int(b.get("index", 0))
    photo = b.get("path") or os.path.join(folder, b.get("file", ""))   # path=절대경로(네이티브 선택) 우선
    if not (cdir and os.path.isdir(cdir) and os.path.isfile(photo)):
        return jsonify(ok=False, msg="파일을 찾을 수 없습니다.")
    try:
        png = cardnews_pil.edit_card(cdir, idx, src=photo)
        sync_card_sources(cdir)                       # 교체한 사진으로 원본사진/ 갱신
        return jsonify(ok=True, png=png, name=os.path.basename(png), src=photo)
    except Exception as e:
        return jsonify(ok=False, msg=str(e)[:200])


@app.route("/api/card-text", methods=["POST"])
def api_card_text():
    """카드 글(헤드라인/부제/본문/제목) 수정 → 그 카드만 재렌더."""
    b = request.get_json(force=True)
    cdir = b.get("cardnews_dir", "")
    idx = int(b.get("index", 0))
    if not (cdir and os.path.isdir(cdir)):
        return jsonify(ok=False, msg="카드 폴더를 찾을 수 없습니다.")
    kw = {k: b[k] for k in ("headline", "subtitle", "body", "title") if k in b}
    try:
        png = cardnews_pil.edit_card(cdir, idx, **kw)
        return jsonify(ok=True, png=png, name=os.path.basename(png))
    except Exception as e:
        return jsonify(ok=False, msg=str(e)[:200])


@app.route("/api/adjust-card", methods=["POST"])
def api_adjust_card():
    """같은 사진을 위치(cx,cy)·확대(zoom)만 바꿔 그 카드만 재렌더."""
    b = request.get_json(force=True)
    cdir = b.get("cardnews_dir", "")
    idx = int(b.get("index", 0))
    cx = float(b.get("cx", 0.5)); cy = float(b.get("cy", 0.5)); zoom = float(b.get("zoom", 1.0))
    if not (cdir and os.path.isdir(cdir)):
        return jsonify(ok=False, msg="카드 폴더를 찾을 수 없습니다.")
    try:
        png = cardnews_pil.edit_card(cdir, idx, center=(cx, cy), zoom=zoom)
        return jsonify(ok=True, png=png, name=os.path.basename(png))
    except Exception as e:
        return jsonify(ok=False, msg=str(e)[:200])


@app.route("/api/open", methods=["POST"])
def api_open():
    p = (request.get_json(force=True) or {}).get("path", "")
    if p and os.path.exists(p):
        try:
            os.startfile(p)
        except Exception:
            pass
        return jsonify(ok=True)
    return jsonify(ok=False)


@app.route("/api/docx", methods=["POST"])
def api_docx():
    from docx import Document
    from docx.shared import Cm, Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    b = request.get_json(force=True)
    post = b.get("post", {}); folder = post.get("folder", "")
    FONT = "Pretendard"

    def setf(run, sz, bold=False):
        run.font.name = FONT; run.font.size = Pt(sz); run.font.bold = bold
        run._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)

    pngs = post.get("cardnews_pngs", [])
    use_cards = bool(pngs) and post.get("use_cards", True)
    cdir = post.get("cardnews_dir", "")
    pidx = [0]
    doc = Document()
    for s in doc.sections:
        s.left_margin = s.right_margin = Cm(2.3)
    if post.get("title"):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(14)
        setf(p.add_run(post["title"]), 16, True)
    for blk in post.get("blocks", []):
        if blk["type"] == "chart":                       # C6: 표·차트 이미지
            img = os.path.join(cdir, blk.get("img", "")) if (cdir and blk.get("img")) else None
            if img and os.path.isfile(img):
                pp = doc.add_paragraph(); pp.alignment = WD_ALIGN_PARAGRAPH.CENTER
                pp.paragraph_format.space_before = Pt(6); pp.paragraph_format.space_after = Pt(12)
                try:
                    pp.add_run().add_picture(img, width=Cm(14))
                except Exception:
                    pass
            continue
        if blk["type"] == "photo":
            img = None
            if use_cards:
                img = pngs[pidx[0]] if pidx[0] < len(pngs) else None   # 카드 다 쓰면 여분 자리 생략
            elif blk.get("file"):
                img = os.path.join(folder, blk["file"])
            pidx[0] += 1
            if img and os.path.isfile(img):
                pp = doc.add_paragraph(); pp.alignment = WD_ALIGN_PARAGRAPH.CENTER
                pp.paragraph_format.space_before = Pt(6); pp.paragraph_format.space_after = Pt(12)
                try:
                    pp.add_run().add_picture(img, width=Cm(14))
                except Exception:
                    pass
        elif blk["type"] == "text":
            for para in blk["text"].split("\n\n"):
                lines = [x for x in para.split("\n") if x.strip()]
                if not lines:
                    continue
                hm = re.match(r"^\*\*(.+?)\*\*$", lines[0].strip())
                pp = doc.add_paragraph(); pp.paragraph_format.line_spacing = 1.5
                pp.paragraph_format.space_after = Pt(9)
                if hm and len(lines) == 1:
                    setf(pp.add_run(hm.group(1)), 13, True)
                else:
                    first = True
                    for ln in lines:
                        if not first:
                            pp.add_run().add_break()
                        setf(pp.add_run(re.sub(r"\*\*", "", ln)), 11)
                        first = False
    # 본문 자리보다 카드가 많으면(예: 자리 6개·카드 7장) 남는 카드는 끝에 붙임
    if use_cards:
        while pidx[0] < len(pngs):
            img = pngs[pidx[0]]; pidx[0] += 1
            if os.path.isfile(img):
                pp = doc.add_paragraph(); pp.alignment = WD_ALIGN_PARAGRAPH.CENTER
                pp.paragraph_format.space_before = Pt(6); pp.paragraph_format.space_after = Pt(12)
                try:
                    pp.add_run().add_picture(img, width=Cm(14))
                except Exception:
                    pass
    safe = re.sub(r"[\\/:*?\"<>|]", "_", post.get("keyword", "글"))
    stamp = datetime.datetime.now().strftime("%H%M%S")
    out = os.path.join(OUT_DIR, f"{safe}_{stamp}.docx")
    doc.save(out)
    try:
        os.startfile(out)
    except Exception:
        pass
    return jsonify(ok=True, path=out)


@app.after_request
def _no_cache(resp):
    # 브라우저가 옛 화면(HTML/JS)을 캐시해 새 기능이 안 보이는 문제 방지
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


@app.route("/")
def index():
    return PAGE


PAGE = r"""<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>블로그 작성기</title>
<style>
:root{--brand:#FD6F22;--brand-d:#e85f12;--brand-l:#fff3ec;--ink:#1b2330;--ink2:#46506180;
  --muted:#8b95a5;--line:#e9ecf1;--line2:#f1f3f7;--bg:#f3f5f8;--card:#fff;
  --ok:#079455;--okbg:#e7f7ee;--warn:#dc8400;--warnbg:#fff3df;--err:#e0483c;--errbg:#fdecea;
  --sh:0 1px 2px rgba(16,24,40,.04),0 6px 20px rgba(16,24,40,.05);
  --sh-lg:0 16px 48px rgba(16,24,40,.18);--r:16px}
*{box-sizing:border-box;font-family:'Pretendard','Malgun Gothic',sans-serif}
body{margin:0;background:var(--bg);color:var(--ink);-webkit-font-smoothing:antialiased;font-size:14px}
::selection{background:var(--brand-l)}
.top{background:rgba(255,255,255,.85);backdrop-filter:blur(10px);border-bottom:1px solid var(--line);
  padding:14px 26px;display:flex;align-items:center;gap:13px;position:sticky;top:0;z-index:20}
.top .logo{width:30px;height:30px;border-radius:9px;background:linear-gradient(135deg,var(--brand),var(--brand-2));
  display:flex;align-items:center;justify-content:center;font-size:16px;box-shadow:0 4px 12px var(--brand-sh)}
.top h1{font-size:16px;margin:0;font-weight:800;letter-spacing:-.2px}
.top .st{font-size:12px;color:var(--muted);font-weight:600}
.pill{margin-left:auto;font-size:11.5px;font-weight:700;padding:5px 12px;border-radius:99px;
  background:var(--okbg);color:var(--ok);display:inline-flex;align-items:center;gap:5px}
.pill.off{background:var(--warnbg);color:var(--warn)}
.tabs{display:flex;gap:5px;align-items:center;padding:14px 26px 0;flex-wrap:wrap;max-width:1120px;margin:0 auto}
.tab{padding:9px 16px;border:1px solid transparent;border-radius:11px 11px 0 0;background:transparent;
  cursor:pointer;font-size:13px;font-weight:700;color:var(--muted);transition:.15s;position:relative;top:1px}
.tab:hover{color:var(--ink2);background:#fff8}
.tab.on{background:var(--card);color:var(--ink);border-color:var(--line);border-bottom-color:var(--card);box-shadow:0 -2px 8px rgba(16,24,40,.03)}
.tab.on::before{content:"";position:absolute;left:14px;right:14px;top:0;height:2.5px;border-radius:2px;background:var(--brand)}
.tab .x{margin-left:8px;color:#c2c8d2;font-weight:800;border-radius:5px;padding:0 3px}
.tab .x:hover{color:var(--err);background:#fff}
.addtab{padding:8px 13px;border:1px dashed var(--line);border-radius:9px;background:#fff;cursor:pointer;font-size:13px;color:var(--muted);font-weight:700;transition:.15s}
.addtab:hover{color:var(--brand);border-color:var(--brand)}
.wrap{max-width:1120px;margin:0 auto;padding:0 26px 80px}
.card{background:var(--card);border:1px solid var(--line);border-radius:0 var(--r) var(--r) var(--r);padding:24px 26px;box-shadow:var(--sh)}
.field{margin-bottom:18px}
.field label{display:block;font-size:12px;font-weight:800;color:var(--ink2);margin-bottom:7px;letter-spacing:.1px}
.row{display:flex;gap:8px;align-items:center}
input[type=text],textarea{width:100%;border:1.5px solid var(--line);border-radius:11px;padding:11px 13px;font-size:13.5px;color:var(--ink);background:#fdfdfe;transition:.15s;outline:none}
input[type=text]:focus,textarea:focus{border-color:var(--brand);background:#fff;box-shadow:0 0 0 3.5px var(--brand-l)}
input[type=text]::placeholder,textarea::placeholder{color:#b4bcc8}
textarea{height:58px;resize:vertical;line-height:1.5}
select{border:1.5px solid var(--line);border-radius:10px;padding:10px 11px;font-size:12.5px;font-weight:700;color:var(--ink2);background:#fdfdfe;cursor:pointer;outline:none}
select:focus{border-color:var(--brand)}
.btn{padding:11px 17px;border-radius:11px;border:1.5px solid var(--line);background:#fff;font-weight:700;font-size:13px;cursor:pointer;white-space:nowrap;transition:.15s;color:var(--ink2)}
.btn:hover{background:#f7f8fa;border-color:#dde1e8;color:var(--ink)}
.btn:active{transform:translateY(1px)}
.btn.pri{background:linear-gradient(135deg,var(--brand),var(--brand-2));border-color:transparent;color:#fff;box-shadow:0 4px 14px var(--brand-sh)}
.btn.pri:hover{filter:brightness(1.05);box-shadow:0 7px 20px var(--brand-sh);color:#fff}
.btn:disabled{opacity:.6;cursor:default;transform:none}
.btn.lg{padding:13px 26px;font-size:14px}
.photos{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px}
.photos img{width:64px;height:64px;object-fit:cover;border-radius:9px;border:1px solid var(--line);transition:.15s}
.photos img:hover{transform:scale(1.06);box-shadow:var(--sh)}
.hint{margin-top:9px;font-size:12.5px;font-weight:700;display:flex;align-items:center;gap:6px}
.hint.ok{color:var(--ok)}.hint.bad{color:var(--err)}
.br-item{padding:11px 18px;font-size:13px;cursor:pointer;border-bottom:1px solid var(--line2);transition:.12s}
.br-item:hover{background:var(--brand-l);color:var(--brand-d)}
.recbox{border:1px solid var(--line);border-radius:12px;max-height:260px;overflow:auto;margin-top:10px;display:none;box-shadow:var(--sh)}
.recbox table{width:100%;border-collapse:collapse;font-size:12.5px}
.recbox td{padding:9px 12px;border-bottom:1px solid var(--line2);cursor:pointer}
.recbox tr:hover td{background:var(--brand-l)}
.recst{font-size:10px;font-weight:800;padding:3px 8px;border-radius:99px}
.recst.미노출{background:var(--warnbg);color:var(--warn)}.recst.노출{background:var(--okbg);color:var(--ok)}.recst.미측정{background:#eef1f4;color:#889}
.preview{margin-top:22px;border-top:1px solid var(--line);padding-top:20px;display:none}
.pv-head{display:flex;align-items:flex-start;gap:12px;flex-wrap:wrap;margin-bottom:6px}
.pv-title{font-size:19px;font-weight:800;letter-spacing:-.3px;flex:1;min-width:200px}
.badges{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0 16px}
.badge{font-size:11.5px;font-weight:700;padding:5px 11px;border-radius:99px;background:#eef1f4;color:var(--ink2);display:inline-flex;align-items:center;gap:5px}
.badge.ok{background:var(--okbg);color:var(--ok)}.badge.warn{background:var(--warnbg);color:var(--warn)}.badge.brand{background:var(--brand-l);color:var(--brand-d)}
.pv-body p{white-space:pre-wrap;line-height:1.75;font-size:14px;margin:11px 0;color:#2b3340}
.pv-body h3{font-size:15.5px;font-weight:800;margin:22px 0 8px;padding-left:11px;border-left:3px solid var(--brand)}
.pv-body img{max-width:320px;border-radius:12px;display:block;margin:12px 0;box-shadow:var(--sh)}
.cardsec-hint{font-size:11.5px;color:var(--muted);font-weight:600;margin:6px 0 2px;display:flex;align-items:center;gap:6px}
.editpanel{margin:10px 0 4px}
.editpanel .editbox{padding:12px 14px 14px}
.editpanel .seclabel{font-size:11.5px;font-weight:800;color:var(--ink2);margin:2px 0 6px}
.secbtns{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px}
.secbtn{font-size:12px;font-weight:700;color:var(--ink2);background:#fff;border:1px solid var(--line);border-radius:999px;padding:6px 12px;cursor:pointer;transition:.12s;max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.secbtn:hover{border-color:var(--brand);color:var(--brand)}
.secbtn.sel{background:var(--brand);border-color:var(--brand);color:#fff}
.editpanel textarea{width:100%;min-height:60px;border:1px solid var(--line);border-radius:10px;padding:10px 12px;font:inherit;font-size:13px;resize:vertical;box-sizing:border-box}
.editpanel textarea:focus{outline:none;border-color:var(--brand)}
.edithint{font-size:11px;color:var(--muted);margin-top:7px}
.secbtn.run{border-color:var(--brand);color:var(--brand);background:var(--brand-l)}
.secbtn.allsec{border-color:var(--brand);color:var(--brand);font-weight:800}
.secbtn.allsec.sel{background:var(--brand);color:#fff}
.editq{font-size:12px;font-weight:700;color:var(--brand);display:flex;align-items:center;gap:6px}
.chartwrap{position:relative;display:block;margin:14px 0;border:1px solid var(--line);border-radius:12px;overflow:hidden;box-shadow:var(--sh)}
.chartwrap img{display:block;width:100%}
.chartdel{position:absolute;top:8px;right:8px;width:28px;height:28px;border:none;border-radius:50%;background:rgba(20,24,30,.55);color:#fff;font-size:14px;cursor:pointer;opacity:0;transition:.15s}
.chartwrap:hover .chartdel{opacity:1}
.chartpend{margin:14px 0;padding:18px;border:1px dashed var(--line);border-radius:12px;color:var(--brand);font-weight:700;font-size:13px;display:flex;align-items:center;gap:8px;justify-content:center}
.pfmode{display:flex;gap:9px;align-items:flex-start;padding:12px 14px;border:1px solid var(--line);border-radius:12px;margin:2px 0 4px;cursor:pointer;background:#fafbfc;font-size:12.5px;color:var(--ink2);line-height:1.5}
.pfmode.on{border-color:var(--brand);background:var(--brand-l)}
.pfmode input{width:17px;height:17px;margin-top:1px;cursor:pointer;accent-color:var(--brand)}
.pfmode b{color:var(--brand)}
.pfhint{font-size:12px;color:var(--ink2);background:var(--brand-l);border-radius:10px;padding:10px 13px;margin:0 0 6px;line-height:1.55}
.altcap{font-size:11.5px;color:var(--muted);margin:-6px 0 12px;padding:5px 10px;background:#f6f7f9;border-radius:8px;display:inline-block;font-weight:600}
.cpick{border:1px solid var(--line);border-radius:12px;padding:13px 14px;margin:2px 0 10px;background:#fff;box-shadow:var(--sh)}
.cpick-h{font-size:12.5px;font-weight:800;color:var(--ink2);margin-bottom:10px}
.cpick-sw{display:grid;grid-template-columns:repeat(13,1fr);gap:6px;margin-bottom:12px}
.cpsw{aspect-ratio:1;border:1px solid rgba(0,0,0,.08);border-radius:7px;cursor:pointer;padding:0;transition:transform .1s}
.cpsw:hover{transform:scale(1.18);box-shadow:var(--sh)}
.cpick-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.cpspec{display:flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:var(--ink2);cursor:pointer}
.cpspec input[type=color]{width:34px;height:30px;border:1px solid var(--line);border-radius:8px;padding:0;background:none;cursor:pointer}
.cphex{display:flex;align-items:center;gap:3px;border:1px solid var(--line);border-radius:8px;padding:4px 9px;font-weight:700;color:var(--ink2)}
.cphex span{font-size:13px;color:var(--muted)}
.cphex input{width:78px;border:none;outline:none;font:inherit;font-size:13px;font-weight:700;letter-spacing:.5px;text-transform:uppercase}
.btn.sm{padding:7px 12px;font-size:12px}
.cpdrop{border:1px solid var(--line);background:#fff;border-radius:8px;padding:7px 11px;font-size:12px;font-weight:700;color:var(--ink2);cursor:pointer}
.cpdrop:hover{border-color:var(--brand);color:var(--brand)}
.cpbusy{font-size:12px;font-weight:700;color:var(--brand);display:flex;align-items:center;gap:6px}
.cardwrap{position:relative;display:inline-block;margin:10px 0;border-radius:14px;overflow:hidden;box-shadow:var(--sh);transition:.15s}
.cardwrap:hover{box-shadow:var(--sh-lg)}
.cardwrap img{display:block;border-radius:14px}
.cardbar{position:absolute;left:50%;bottom:10px;transform:translateX(-50%) translateY(6px);display:flex;align-items:center;gap:3px;
  background:rgba(20,24,32,.74);padding:5px 6px;border-radius:12px;opacity:0;transition:.16s;backdrop-filter:blur(6px);box-shadow:0 6px 18px rgba(0,0,0,.3)}
.cardwrap:hover .cardbar{opacity:1;transform:translateX(-50%) translateY(0)}
.cardbar button{height:28px;min-width:28px;border:0;border-radius:7px;background:rgba(255,255,255,.92);color:#222;font-size:12px;font-weight:800;cursor:pointer;line-height:1;padding:0 7px;transition:.1s}
.cardbar button.tb{font-size:11.5px}
.cardbar button:hover{background:var(--brand);color:#fff}
.cardbar .sep{width:1px;height:18px;background:rgba(255,255,255,.28);margin:0 2px}
#swaplist img{transition:.12s}
#swaplist img:hover{border-color:var(--brand)!important;transform:scale(1.06)}
.modal-bg{display:none;position:fixed;inset:0;background:rgba(16,22,34,.45);backdrop-filter:blur(2px);z-index:50}
.modal{background:#fff;border-radius:18px;overflow:hidden;box-shadow:var(--sh-lg)}
.pv-photo-missing{font-size:12px;color:var(--err);background:var(--errbg);padding:7px 12px;border-radius:9px;display:inline-block}
.spin{display:inline-block;width:14px;height:14px;border:2px solid currentColor;border-top-color:transparent;border-radius:50%;animation:sp .7s linear infinite;vertical-align:-2px}
@keyframes sp{to{transform:rotate(360deg)}}
.warn{background:var(--warnbg);border:1px solid #fcd9a3;color:#a85f00;padding:12px 16px;border-radius:12px;font-size:12.5px;margin:14px 26px;font-weight:600;max-width:1120px;margin-left:auto;margin-right:auto}
.gen-row{display:flex;gap:10px;align-items:center;background:var(--brand-l);border:1px solid transparent;border-radius:14px;padding:14px 16px;margin-top:4px;flex-wrap:wrap}
#toasts{position:fixed;right:22px;bottom:22px;z-index:90;display:flex;flex-direction:column;gap:9px}
.toast{background:#1f2733;color:#fff;padding:12px 16px;border-radius:12px;font-size:13px;font-weight:600;box-shadow:var(--sh-lg);display:flex;align-items:center;gap:9px;animation:tin .25s ease;max-width:340px}
.toast.ok{background:#0e7a48}.toast.err{background:#c33}.toast b{font-weight:800}
@keyframes tin{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}
.spacer{flex:1}
.opt{margin-bottom:18px;border:1px solid var(--line);border-radius:11px;overflow:hidden}
.opt summary{cursor:pointer;font-size:12.5px;font-weight:700;color:var(--ink2);padding:11px 14px;list-style:none;user-select:none;background:#fafbfc}
.opt summary::-webkit-details-marker{display:none}
.opt summary:hover{color:var(--brand)}
.opt[open] summary{border-bottom:1px solid var(--line)}
.opt textarea{border:0;border-radius:0;width:100%}
.naver-box{background:var(--brand-l);border:1px solid transparent;border-radius:13px;padding:14px 16px;margin:4px 0}
.naver-title{font-weight:800;font-size:14px;margin-bottom:10px}
.naver-steps{font-size:12px;color:var(--ink2);margin-top:10px;line-height:1.6;font-weight:600}
.naver-steps b{color:var(--brand-d)}
.tplrow{display:flex;gap:10px;flex-wrap:wrap}
.tplopt{cursor:pointer;border:2.5px solid transparent;border-radius:13px;padding:5px;background:#f3f5f7;transition:.15s;text-align:center}
.tplopt:hover{background:#e9edf1}
.tplopt img{width:124px;height:124px;object-fit:cover;border-radius:9px;display:block;background:#fff}
.tplopt span{font-size:12px;font-weight:800;color:var(--ink2);display:block;margin-top:5px}
.tplopt.sel{border-color:var(--brand);background:var(--brand-l)}
.tplopt.sel span{color:var(--brand-d)}
</style></head><body>
<div class="top"><div class="logo">🖊</div><h1>블로그 작성기</h1>
  <select id="brandsel" onchange="switchBrand(this.value)" title="브랜드 선택"></select>
  <button class="btn" style="padding:7px 12px" onclick="openBrandMgr()">⚙ 브랜드</button>
  <span class="pill" id="engine">확인 중…</span>
  <button class="btn" style="padding:7px 12px" onclick="openAccounts()" title="Claude 계정 관리">👤 계정</button>
  <span id="ver" style="font-size:11px;color:var(--muted);font-weight:700"></span></div>
<div id="loginwarn" class="warn" style="display:none"></div>
<div id="toasts"></div>
<div class="tabs" id="tabs"></div>
<div class="wrap"><div class="card" id="card"></div></div>
<div id="brmodal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:50" onclick="if(event.target==this)closeBrowse()">
  <div style="background:#fff;max-width:560px;margin:7vh auto;border-radius:14px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.25)">
    <div style="padding:14px 18px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px">
      <b style="font-size:14px">📁 사진 폴더 선택</b><span style="flex:1"></span>
      <button class="btn" onclick="closeBrowse()">닫기</button></div>
    <div id="brplaces" style="padding:9px 18px;display:flex;gap:6px;flex-wrap:wrap;border-bottom:1px solid var(--line)"></div>
    <div style="padding:9px 18px;font-size:12px;color:var(--muted);word-break:break-all" id="brpath"></div>
    <div id="brlist" style="max-height:48vh;overflow:auto;border-top:1px solid var(--line)"></div>
    <div style="padding:12px 18px;border-top:1px solid var(--line);display:flex;align-items:center;gap:10px">
      <span id="brimg" style="font-size:12px;color:var(--muted)"></span><span style="flex:1"></span>
      <button class="btn pri" id="brpick" onclick="selectFolder()" disabled>✓ 이 폴더 선택</button></div>
  </div></div>
<div id="swapmodal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:55" onclick="if(event.target==this)closeSwap()">
  <div style="background:#fff;max-width:640px;margin:8vh auto;border-radius:14px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.25)">
    <div style="padding:14px 18px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px">
      <b style="font-size:14px">🔄 이 카드 사진 교체</b><span style="font-size:12px;color:var(--muted)">바꿀 사진 클릭</span><span style="flex:1"></span>
      <button class="btn" onclick="closeSwap()">닫기</button></div>
    <div id="swaplist" style="padding:14px 18px;display:flex;gap:7px;flex-wrap:wrap;max-height:62vh;overflow:auto"></div>
  </div></div>
<div id="textmodal" class="modal-bg" onclick="if(event.target==this)el('textmodal').style.display='none'">
  <div class="modal" style="max-width:520px;margin:9vh auto">
    <div style="padding:15px 20px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px">
      <b style="font-size:15px">✏️ 카드 글 수정</b><span class="spacer"></span>
      <button class="btn" onclick="el('textmodal').style.display='none'">닫기</button></div>
    <div id="txtfields" style="padding:18px 20px;max-height:60vh;overflow:auto"></div>
    <div style="padding:0 20px 18px;display:flex;gap:8px"><button class="btn pri" onclick="applyText()">적용</button>
      <span style="font-size:11.5px;color:var(--muted);align-self:center">수정 후 그 카드만 다시 그려집니다</span></div>
  </div></div>
<div id="previewmodal" class="modal-bg" style="z-index:60" onclick="if(event.target==this)el('previewmodal').style.display='none'">
  <div class="modal" style="max-width:920px;margin:5vh auto;max-height:88vh;display:flex;flex-direction:column">
    <div style="padding:15px 20px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px">
      <b style="font-size:15px" id="pvtitle">🎴 카드 미리보기</b><span class="spacer"></span>
      <span id="pvbrandsel"></span>
      <button class="btn" onclick="el('previewmodal').style.display='none'">닫기</button></div>
    <div id="pvgrid" style="padding:18px 20px;overflow:auto;display:flex;flex-wrap:wrap;gap:14px;justify-content:center"></div>
  </div></div>
<div id="acctmodal" class="modal-bg" onclick="if(event.target==this)el('acctmodal').style.display='none'">
  <div class="modal" style="max-width:560px;margin:7vh auto;max-height:86vh;display:flex;flex-direction:column">
    <div style="padding:15px 20px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px">
      <b style="font-size:15px">👤 Claude 계정</b>
      <span style="font-size:11.5px;color:var(--muted)">한도 차면 자동으로 다른 계정으로 전환됩니다</span><span class="spacer"></span>
      <button class="btn" onclick="el('acctmodal').style.display='none'">닫기</button></div>
    <div id="acctbody" style="padding:14px 20px;overflow:auto"></div>
    <div style="padding:12px 20px;border-top:1px solid var(--line);display:flex;gap:8px;align-items:center">
      <button class="btn pri" onclick="addAccount()">➕ 다른 Claude 계정 추가</button>
      <span style="font-size:11.5px;color:var(--muted)">검은 콘솔이 열리면 브라우저에서 그 계정으로 로그인하세요</span></div>
  </div></div>
<div id="brandmodal" class="modal-bg" onclick="if(event.target==this)closeBrandMgr()">
  <div class="modal" style="max-width:640px;margin:5vh auto;max-height:88vh;display:flex;flex-direction:column">
    <div style="padding:15px 20px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px">
      <b style="font-size:15px">⚙ 브랜드 관리</b><span class="spacer"></span>
      <button class="btn" onclick="closeBrandMgr()">닫기</button></div>
    <div id="brandbody" style="padding:18px 20px;overflow:auto"></div>
  </div></div>
<script>
let TABS=[], CUR=0, REC=null, seq=1, BRAND='haofactory', BRANDS=[], BFORM=null;
const el=id=>document.getElementById(id), esc=s=>(s||'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
function newTab(){return {id:seq++, brand:((typeof BRAND!=='undefined'&&BRAND)||'haofactory'), keyword:'', subkeyword:'', question:'', title:'', titleSug:null, folder:'', files:[], hint:'', post:null, busy:false, model:'opus'};}
// ── 브랜드 ──
function hexMix(hex,amt){hex=(hex||'#FD6F22').replace('#','');if(hex.length<6)hex='FD6F22';
  const r=parseInt(hex.substr(0,2),16),g=parseInt(hex.substr(2,2),16),b=parseInt(hex.substr(4,2),16),m=v=>Math.round(v+(255-v)*amt);
  return `rgb(${m(r)},${m(g)},${m(b)})`;}
function hexA(hex,a){hex=(hex||'#FD6F22').replace('#','');if(hex.length<6)hex='FD6F22';
  return `rgba(${parseInt(hex.substr(0,2),16)},${parseInt(hex.substr(2,2),16)},${parseInt(hex.substr(4,2),16)},${a})`;}
function curBrand(){return BRANDS.find(b=>b.id==BRAND)||{};}
function applyBrandColor(){const c=curBrand().color||'#FD6F22',R=document.documentElement;
  R.style.setProperty('--brand',c);R.style.setProperty('--brand-l',hexMix(c,0.9));R.style.setProperty('--brand-d',c);
  R.style.setProperty('--brand-2',hexMix(c,0.24));R.style.setProperty('--brand-sh',hexA(c,0.32));}
function renderBrandSel(){const s=el('brandsel');if(!s)return;
  s.innerHTML=BRANDS.map(b=>`<option value="${b.id}" ${b.id==BRAND?'selected':''}>${esc(b.name)}</option>`).join('');}
function loadBrands(cb){return fetch('/api/brands').then(r=>r.json()).then(d=>{BRANDS=d.brands||[];
  if(!BRANDS.find(b=>b.id==BRAND))BRAND=(BRANDS[0]||{}).id||'haofactory';
  renderBrandSel();applyBrandColor();if(cb)cb();});}
function switchBrand(id){BRAND=id;if(TABS[CUR])TABS[CUR].brand=id;   // 현재 탭의 브랜드만 바꿈(탭별 브랜드)
  if(el('recbox')&&el('recbox').style.display=='block'){el('recbox').style.display='none';}
  render();toast('이 글 브랜드: '+(curBrand().name||id));}
function init(){TABS=[newTab()];CUR=0;loadBrands();render();
  fetch('/api/version').then(r=>r.json()).then(d=>{if(el('ver'))el('ver').textContent='v'+d.version;}).catch(()=>{});
  fetch('/api/status').then(r=>r.json()).then(s=>{
    if(!s.claude){el('engine').textContent='● 엔진 없음';el('engine').className='pill off';el('loginwarn').style.display='block';el('loginwarn').textContent='⚠ claude 실행파일을 찾지 못했습니다. Claude 데스크톱 앱 또는 CLI 설치 필요.';return;}
    checkAuth();
  });
}
function checkAuth(){el('engine').textContent='로그인 확인 중…';el('engine').className='pill off';
  fetch('/api/auth-status').then(r=>r.json()).then(a=>{
    if(a.logged_in){el('engine').textContent='● Claude 로그인됨';el('engine').className='pill';el('loginwarn').style.display='none';}
    else{el('engine').textContent='● 로그인 필요';el('engine').className='pill off';el('loginwarn').style.display='block';
      el('loginwarn').innerHTML='⚠ Claude 로그인이 필요합니다 (각자 자기 구독으로). <button class="btn" style="padding:5px 12px;margin-left:8px" onclick="doLogin()">🔑 로그인</button>';}
  });
}
function toast(msg,kind){const t=document.createElement('div');t.className='toast'+(kind?' '+kind:'');t.innerHTML=msg;
  el('toasts').appendChild(t);setTimeout(()=>{t.style.transition='.3s';t.style.opacity='0';t.style.transform='translateY(8px)';setTimeout(()=>t.remove(),300);}, kind=='err'?4200:2600);}
function doLogin(){fetch('/api/login',{method:'POST'}).then(r=>r.json()).then(d=>{
  if(!d.ok){alert(d.msg||'로그인 실행 실패');return;}
  el('loginwarn').innerHTML='🔑 로그인 창(검은 콘솔)이 열렸어요. 안내대로 브라우저에서 승인하면 자동으로 인식됩니다…';
  pollAuth();});}
function pollAuth(){let n=0;const iv=setInterval(()=>{n++;
  fetch('/api/auth-status').then(r=>r.json()).then(a=>{
    if(a.logged_in){clearInterval(iv);el('loginwarn').style.display='none';el('engine').textContent='✓ Claude 로그인됨';}
    else if(n>80){clearInterval(iv);el('loginwarn').innerHTML='아직 로그인 안 됨. 콘솔 창에서 완료 후 <button class="btn" style="padding:5px 12px" onclick="checkAuth()">다시 확인</button>';}
  });},3000);}
// ── 멀티 계정 ──
function openAccounts(){el('acctmodal').style.display='block';loadAccounts();}
function loadAccounts(){el('acctbody').innerHTML='<div style="color:var(--muted);font-size:13px">계정 상태 확인 중…</div>';
  fetch('/api/accounts').then(r=>r.json()).then(renderAccounts).catch(()=>{el('acctbody').innerHTML='<div class="warn">계정 정보를 불러오지 못했습니다.</div>';});}
function renderAccounts(d){
  el('acctbody').innerHTML = d.accounts.map(a=>{
    const on = a.id==d.active;
    const st = a.logged_in
      ? `<span style="color:#138a36;font-weight:700">● 로그인됨</span>${a.email?' · '+esc(a.email):''}${a.plan?' · '+esc(a.plan):''}`
      : `<span style="color:#c0392b;font-weight:700">● 로그인 필요</span>`;
    return `<div style="display:flex;align-items:center;gap:10px;padding:11px 12px;margin-bottom:8px;border:1.5px solid ${on?'var(--brand)':'var(--line)'};border-radius:11px;background:${on?'rgba(253,111,34,.05)':'#fff'}">
      <div style="flex:1;min-width:0">
        <div style="font-weight:800;font-size:13.5px">${esc(a.label)}${on?' <span style="color:var(--brand);font-size:11px">✓ 사용 중</span>':''}</div>
        <div style="font-size:11.5px;color:var(--muted);margin-top:2px">${st}</div>
      </div>
      ${!on?`<button class="btn" onclick="switchAccount('${a.id}')">전환</button>`:''}
      ${!a.logged_in?`<button class="btn pri" onclick="loginAccount('${a.id}')">🔑 로그인</button>`:''}
      ${a.id!='default'?`<button class="btn" style="color:#c0392b" onclick="removeAccount('${a.id}','${esc(a.label)}')">삭제</button>`:''}
    </div>`;}).join('');
}
function switchAccount(id){fetch('/api/account-switch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})})
  .then(r=>r.json()).then(d=>{if(d.ok){toast('계정 전환됨');loadAccounts();checkAuth();}else toast(d.msg||'전환 실패','err');});}
function loginAccount(id){fetch('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})})
  .then(r=>r.json()).then(d=>{if(!d.ok){toast(d.msg||'로그인 실행 실패','err');return;}
    toast('🔑 로그인 콘솔이 열렸어요');pollAccounts();});}
let PENDING_ACCT=null;
function addAccount(){const label=prompt('추가할 계정 이름 (예: 회사 계정, 두번째 구독)','추가 계정');if(label===null)return;
  fetch('/api/account-add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({label})})
  .then(r=>r.json()).then(d=>{if(!d.ok){toast(d.msg||'추가 실패','err');return;}
    PENDING_ACCT=d.id;toast('🔑 새 계정 로그인 콘솔이 열렸어요. 로그인하면 자동 전환됩니다');loadAccounts();pollAccounts();});}
function removeAccount(id,label){if(!confirm('"'+label+'" 계정을 삭제할까요? (저장된 로그인이 지워집니다)'))return;
  fetch('/api/account-remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})})
  .then(r=>r.json()).then(d=>{if(d.ok){toast('삭제됨');loadAccounts();checkAuth();}else toast(d.msg||'삭제 실패','err');});}
function pollAccounts(){let n=0;const iv=setInterval(()=>{n++;
  fetch('/api/accounts').then(r=>r.json()).then(d=>{renderAccounts(d);
    // 로그인 기다리던 새 계정이 로그인되면 그 계정으로 자동 전환
    if(PENDING_ACCT){const p=d.accounts.find(a=>a.id==PENDING_ACCT);
      if(p&&p.logged_in){clearInterval(iv);const id=PENDING_ACCT;PENDING_ACCT=null;switchAccount(id);return;}}
    else if(d.accounts.some(a=>a.id==d.active&&a.logged_in)){clearInterval(iv);checkAuth();}
    if(n>80)clearInterval(iv);});},3000);}
function renderTabs(){
  el('tabs').innerHTML = TABS.map((tb,i)=>{const bn=(BRANDS.find(b=>b.id==tb.brand)||{}).name||'';
    const load=tb.titleSug&&tb.titleSug.loading?' <span class="spin" style="width:9px;height:9px;border-width:1.5px;vertical-align:0"></span>':'';
    return `<div class="tab ${i==CUR?'on':''}" onclick="sel(${i})">${bn?'<b style="color:var(--brand)">'+esc(bn)+'</b> · ':''}글 ${i+1}${tb.keyword?': '+esc(tb.keyword.slice(0,10)):''}${load}<span class="x" onclick="event.stopPropagation();delTab(${i})">×</span></div>`;}).join('')
    + `<div class="addtab" onclick="addTab()">+ 새 글</div>`;
}
function sel(i){CUR=i;render();}
function addTab(){TABS.push(newTab());CUR=TABS.length-1;render();}
function delTab(i){if(TABS.length==1)return;TABS.splice(i,1);if(CUR>=TABS.length)CUR=TABS.length-1;render();}
function t(){return TABS[CUR];}
function render(){
  const x=t();
  if(x.brand&&BRANDS.find(b=>b.id==x.brand))BRAND=x.brand;   // 활성 탭의 브랜드로 동기화(색·선택기·카드디자인 반영)
  applyBrandColor();renderBrandSel();renderTabs();
  el('card').innerHTML=`
    <div class="field"><label>메인키워드</label>
      <div class="row"><input type="text" id="kw" value="${esc(x.keyword)}" placeholder="예: FRP조형물 — 입력 후 Enter로 바로 생성" oninput="t().keyword=this.value;renderTabs()" onkeydown="if(event.key=='Enter'){event.preventDefault();generate();}">
        <button class="btn" onclick="toggleRec()">📝 추천</button></div>
      <div class="recbox" id="recbox"></div>
    </div>
    <div class="field"><label>서브키워드 <span style="font-weight:600;color:#b4bcc8">(선택 — 비워도 됩니다)</span></label>
      <div class="row"><input type="text" id="subkw" value="${esc(x.subkeyword||'')}" placeholder="예: 제품브로슈어인쇄 — 본문에 4회 반복" oninput="t().subkeyword=this.value">
        <button class="btn" onclick="toggleRecSub()">📝 추천</button></div>
      <div class="recbox" id="recboxsub"></div>
    </div>
    <div class="field"><label>질문 <span style="font-weight:600;color:#b4bcc8">(선택 — 고객·독자가 실제로 묻는 질문. 넣으면 이 질문 + 메인·서브키워드로 제목을 짓고, 글 전체가 이 질문에 답합니다)</span></label>
      <div class="row"><input type="text" id="question" value="${esc(x.question||'')}" placeholder="예: 병원 리플렛인데 2단이 나아요 3단이 나아요?" oninput="t().question=this.value"></div>
    </div>
    <div class="field"><label>제목 <span style="font-weight:600;color:#b4bcc8">(직접 입력하거나 제목 추천 후 수정 가능 · 비우면 AI가 제목 생성 — 질문이 있으면 질문 기반)</span></label>
      <div class="row"><input type="text" id="title" value="${esc(x.title||'')}" placeholder="제목 추천으로 뽑아 쓰거나 직접 입력하세요" oninput="t().title=this.value">
        <button class="btn pri" onclick="suggestTitle('geo')" title="geo-tracker 고객 질문 기반 AEO/GEO 제목">✨ AEO/GEO 추천</button>
        <button class="btn" onclick="suggestTitle('ai')" title="메인·서브키워드로 AI가 창의적 제목 제안">🤖 AI 추천</button></div>
      <div class="recbox" id="titlebox" style="${x.titleSug?'display:block':'display:none'}">${titleBoxHtml(x)}</div>
    </div>
    <div class="field"><label>사진 폴더</label>
      <div class="row"><input type="text" id="folder" value="${esc(x.folder)}" placeholder="폴더 경로" oninput="t().folder=this.value">
        <button class="btn" onclick="pickFolder()">폴더 선택</button>
        <button class="btn" onclick="loadPhotos()">불러오기</button>
        ${x.folder&&x.files.length?`<button class="btn" onclick="organize()" title="파일명을 단계별(공정/완성 등)로 자동 정리">📷 사진 정리</button>`:''}</div>
      <div id="orgbar" style="margin-top:6px;font-size:12px;color:var(--brand);font-weight:700"></div>
      ${x.folder?`<div class="hint ${x.files.length?'ok':'bad'}">${x.files.length?(x.picked?('📌 선택한 사진 '+x.files.length+'장만 사용 (폴더 전체를 쓰려면 다시 [폴더 선택])'):('📷 사진 '+x.files.length+'장 (하위 폴더 포함) · 생성 시 키워드에 맞춰 자동 선택')):'이 폴더에 사진이 없습니다'}</div>
      <div class="photos">${x.files.slice(0,6).map(f=>`<img src="/img?folder=${encodeURIComponent(x.folder)}&name=${encodeURIComponent(f)}" title="${esc(f)}">`).join('')}${x.files.length>6?`<div style="width:62px;height:62px;border-radius:7px;background:#eef1f4;display:flex;align-items:center;justify-content:center;font-size:12px;color:#889;font-weight:700">+${x.files.length-6}</div>`:''}</div>`:''}
    </div>
    <details class="opt" ${x.hint?'open':''}><summary>＋ 프로젝트 정보 (선택 — 실제 작업 건이면 현장·소재·특이사항)</summary>
      <textarea id="hint" oninput="t().hint=this.value" placeholder="예: 전남 광양, 황소 캐릭터, 벤치 포토존, FRP">${esc(x.hint)}</textarea></details>
    <label class="pfmode ${x.portfolio?'on':''}">
      <input type="checkbox" ${x.portfolio?'checked':''} onchange="t().portfolio=this.checked;render()">
      <span><b>📁 포트폴리오 모드</b> — 폴더의 사진을 직접 열어보고 '이 프로젝트 사례'로 작성 (정보성 대신). 사진마다 alt 텍스트도 붙여줍니다</span></label>
    ${x.portfolio?`<div class="pfhint">💡 이 프로젝트의 사진 폴더 + 키워드(예: <b>삼성병원 내과 브로슈어</b>)를 넣으세요. 사진으로 알 수 없는 정보(고객·요청)는 위 프로젝트 정보에 적어주면 더 정확합니다. (사진을 읽어서 조금 더 걸립니다)</div>`:''}
    ${(curBrand().card_templates||[]).length>1?`
    <div class="field"><label>카드 디자인 (클릭해서 선택)</label>
      <div class="tplrow">${(curBrand().card_templates).map(tp=>`<div class="tplopt ${(x.cardTpl||'1')==tp?'sel':''}" onclick="t().cardTpl='${tp}';render()" title="디자인 ${tp}">
        <img src="/api/template-thumb?brand=${BRAND}&template=${tp}" loading="lazy" alt="디자인 ${tp}"><span>디자인 ${tp}</span></div>`).join('')}</div></div>`:''}
    <div class="gen-row"><button class="btn pri lg" id="genbtn" onclick="generate()" ${x.busy?'disabled':''}>${x.busy?'<span class=spin></span> 생성 중…':'✍ 생성하기'}</button>
      <select onchange="t().model=this.value">
        <option value="opus" ${(x.model||'opus')=='opus'?'selected':''}>Opus (품질)</option>
        <option value="sonnet" ${x.model=='sonnet'?'selected':''}>Sonnet (빠름)</option></select>
      <span class="spacer"></span>
      <span style="font-size:12px;color:var(--ink2);font-weight:600">Opus 원고 1~2분 · 카드는 뒤이어 채워집니다</span></div>
    <div class="preview" id="preview" style="display:block">${x.post?renderPost(x.post):(x.busy?loadingState():emptyState())}</div>`;
}
function emptyState(){return `<div style="text-align:center;padding:42px 20px;color:var(--muted)">
  <div style="font-size:38px;margin-bottom:10px;opacity:.45">📝</div>
  <div style="font-weight:800;color:var(--ink2);margin-bottom:5px">아직 생성된 글이 없어요</div>
  <div style="font-size:12.5px">키워드와 사진 폴더를 정하고 <b style="color:var(--brand)">✍ 생성하기</b>를 눌러주세요</div></div>`;}
function loadingState(){return `<div style="text-align:center;padding:42px 20px;color:var(--brand)">
  <div class="spin" style="width:28px;height:28px;border-width:3px;margin-bottom:14px"></div>
  <div style="font-weight:800;color:var(--ink2)">원고를 쓰는 중…</div>
  <div style="font-size:12.5px;color:var(--muted);margin-top:4px">Opus 기준 1~2분 정도 걸려요</div></div>`;}
function toggleRec(){const b=el('recbox');if(b.style.display=='block'){b.style.display='none';return;}
  b.style.display='block';b.innerHTML='<div style="padding:14px;color:#889;font-size:12px">불러오는 중…</div>';
  fetch('/api/recommend?brand='+encodeURIComponent(BRAND)).then(r=>r.json()).then(d=>{REC=d.items||[];
    if(!REC.length){b.innerHTML='<div style="padding:16px;color:#c0392b;font-size:12.5px;line-height:1.6">'+esc(d.msg||'추천할 키워드가 없습니다.')+'</div>';return;}
    b.innerHTML='<table>'+REC.map(it=>`<tr onclick="pickKw('${esc(it.keyword).replace(/'/g,"\\'")}')"><td><b>${esc(it.keyword)}</b></td><td style="color:#889">${esc(it.category)}</td><td style="text-align:right;color:#889">${Number(it.volume).toLocaleString()}</td><td><span class="recst ${it.state}">${it.state}</span></td></tr>`).join('')+'</table>';
  }).catch(e=>{b.innerHTML='<div style="padding:16px;color:#c0392b;font-size:12.5px">추천 불러오기 오류: '+esc(''+e)+'</div>';});
}
function pickKw(k){t().keyword=k;el('recbox').style.display='none';render();}
function toggleRecSub(){const b=el('recboxsub');if(b.style.display=='block'){b.style.display='none';return;}
  b.style.display='block';b.innerHTML='<div style="padding:14px;color:#889;font-size:12px">불러오는 중…</div>';
  fetch('/api/recommend?brand='+encodeURIComponent(BRAND)).then(r=>r.json()).then(d=>{const R=d.items||[];
    if(!R.length){b.innerHTML='<div style="padding:16px;color:#c0392b;font-size:12.5px;line-height:1.6">'+esc(d.msg||'추천할 키워드가 없습니다.')+'</div>';return;}
    b.innerHTML='<table>'+R.map(it=>`<tr onclick="pickSub('${esc(it.keyword).replace(/'/g,"\\'")}')"><td><b>${esc(it.keyword)}</b></td><td style="color:#889">${esc(it.category)}</td><td style="text-align:right;color:#889">${Number(it.volume).toLocaleString()}</td><td><span class="recst ${it.state}">${it.state}</span></td></tr>`).join('')+'</table>';
  }).catch(e=>{b.innerHTML='<div style="padding:16px;color:#c0392b;font-size:12.5px">추천 오류: '+esc(''+e)+'</div>';});
}
function pickSub(k){const cur=(t().subkeyword||'').trim();
  const parts=cur?cur.split(',').map(s=>s.trim()).filter(Boolean):[];
  if(!parts.includes(k))parts.push(k);          // 추천 누를 때마다 kw1, kw2… 누적(중복은 제외). 바꾸려면 직접 지우기
  t().subkeyword=parts.join(', ');el('recboxsub').style.display='none';render();}
function titleBoxHtml(x){const s=x.titleSug;if(!s)return '';
  if(s.loading)return '<div style="padding:14px;color:var(--brand);font-size:12.5px;font-weight:700"><span class="spin" style="border-color:var(--brand);border-top-color:transparent"></span> '+(s.mode=='ai'?'AI가 키워드로 제목 뽑는 중…':'AEO/GEO 분석해 제목 뽑는 중…')+' (다른 작업을 해도 계속 진행돼요)</div>';
  if(s.err)return '<div style="padding:16px;color:#c0392b;font-size:12.5px">'+esc(s.err)+'</div>';
  if(!s.items||!s.items.length)return '<div style="padding:16px;color:#c0392b;font-size:12.5px">제목을 뽑지 못했어요. 다시 시도해 주세요.</div>';
  const label=s.mode=='ai'?'🤖 AI 키워드 기반':(s.geo?'✨ AEO/GEO 분석 기반':'✨ AEO/GEO (geo 데이터 없어 키워드 기반)');
  return '<div style="padding:8px 12px;font-size:11px;font-weight:800;color:#8b95a5;background:#fafbfc;border-bottom:1px solid var(--line2)">'+label+' 추천 · 클릭하면 위 제목칸에 입력(수정 가능)</div>'+s.items.map(tt=>`<div class="br-item" onclick="pickTitle('${esc(tt).replace(/'/g,"\\'")}')">${esc(tt)}</div>`).join('');
}
function suggestTitle(mode){mode=mode||'geo';const x=t();if(!x.keyword){toast('메인키워드를 먼저 입력하세요','err');return;}
  x.titleSug={loading:true,mode:mode};render();                       // 상태를 탭에 저장 → 다른 작업(불러오기 등) 해도 안 끊김
  fetch('/api/title-suggest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({keyword:x.keyword,subkeyword:x.subkeyword||'',question:x.question||'',brand:x.brand||BRAND,mode:mode})})
   .then(r=>r.json()).then(d=>{
     x.titleSug = d.ok ? {items:d.titles||[],geo:d.geo,mode:d.mode||mode} : {err:d.msg||'실패',mode:mode};
     if(t()===x)render(); else {renderTabs();toast('📝 글 '+(TABS.indexOf(x)+1)+' 제목 추천 완료','ok');}   // 다른 탭이어도 완료 알림
   }).catch(e=>{x.titleSug={err:''+e,mode:mode};if(t()===x)render();else renderTabs();});
}
function pickTitle(tt){t().title=tt;t().titleSug=null;render();}
let BR={path:'',drive:true}, BRF=[], PLACES=[];
function pickFolder(){  // 윈도우 탐색기 대화상자 — 폴더째([열기]) 또는 특정 사진만(클릭·Ctrl 다중) 선택. 실패 시에만 웹 모달 폴백
  fetch('/api/pick-folder',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({folder:t().folder})})
   .then(r=>r.json()).then(d=>{
     if(!d.ok){el('brmodal').style.display='block';browse('');return;}
     const x=t();
     if(d.files&&d.files.length){x.folder=d.folder;x.files=d.files;x.picked=true;render();}
     else if(d.path){x.folder=d.path;x.picked=false;
       fetch('/api/photos?folder='+encodeURIComponent(d.path)).then(r=>r.json()).then(v=>{x.files=v.files;render();});}
   }).catch(()=>{el('brmodal').style.display='block';browse('');});}
function closeBrowse(){el('brmodal').style.display='none';}
function renderPlaces(){el('brplaces').innerHTML=PLACES.map((p,i)=>`<button class="btn" style="padding:6px 11px;font-size:12px" onclick="browse(PLACES[${i}].path)">${esc(p.name)}</button>`).join('')+`<button class="btn" style="padding:6px 11px;font-size:12px" onclick="browse('')">💽 드라이브</button>`;}
function browse(path){
  fetch('/api/browse?path='+encodeURIComponent(path)).then(r=>r.json()).then(d=>{
    if(d.error){alert('열 수 없음: '+d.error);return;}
    if(d.places){PLACES=d.places;}
    renderPlaces();
    BR=d; BRF=[];
    el('brpath').textContent=d.drive?'내 컴퓨터 (드라이브 선택)':d.path;
    el('brimg').textContent=d.drive?'':('✓ 선택 시 하위 폴더까지 사진을 찾습니다'+(d.images?(' · 여기 직접 '+d.images+'장'):''));
    el('brpick').disabled=!!d.drive;
    if(!d.drive && d.parent) BRF.push({label:'↑ 상위 폴더', full:d.parent});
    d.folders.forEach(f=>{const full=d.drive?f:(d.path.replace(/[\\/]+$/,'')+'\\'+f);BRF.push({label:'📁 '+f, full:full});});
    el('brlist').innerHTML=BRF.map((it,i)=>`<div class="br-item" onclick="browse(BRF[${i}].full)">${esc(it.label)}</div>`).join('')||'<div style="padding:14px;color:#889;font-size:12px">하위 폴더 없음</div>';
  });
}
function selectFolder(){const x=t();x.folder=BR.path;x.picked=false;closeBrowse();
  fetch('/api/photos?folder='+encodeURIComponent(BR.path)).then(r=>r.json()).then(d=>{x.files=d.files;render();});}
function loadPhotos(){const f=el('folder').value;const x=t();x.folder=f;x.picked=false;
  fetch('/api/photos?folder='+encodeURIComponent(f)).then(r=>r.json()).then(d=>{x.files=d.files;render();});}
function organize(){const x=t();
  if(!confirm('이 폴더(하위 포함) 사진을 [프로젝트]_[타입]_[단계]_[번호] 로 정리합니다.\\n· 타입=캐릭터/마스코트/글자/박스/FRP 등 (폴더명에 없으면 Claude 비전으로 폴더별 1회 판단)\\n· 단계=대표/공정/도장/설치/완성 (이름이 무의미하면 비전으로 판단)\\n타입이 파일명에 박혀 키워드 매칭이 정확해집니다.\\n원본 이름이 바뀝니다(구독 사용·시간 걸림). 진행할까요?'))return;
  fetch('/api/organize',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({folder:x.folder,brand:BRAND})})
   .then(r=>r.json()).then(d=>{if(!d.ok){alert(d.msg);return;}pollOrg();});}
function pollOrg(){const iv=setInterval(()=>{fetch('/api/organize-status').then(r=>r.json()).then(s=>{
  const last=(s.log&&s.log.length)?s.log[s.log.length-1]:'';
  if(el('orgbar'))el('orgbar').textContent='📷 정리 중… '+s.done+'/'+s.total+' · '+s.renamed+'장 변경 '+(last?('· '+last):'');
  if(!s.running&&s.finished){clearInterval(iv);if(el('orgbar'))el('orgbar').textContent='✓ 정리 완료 · '+s.renamed+'장 이름변경';loadPhotos();}
});},1500);}
function generate(extra){const x=t();if(!x.keyword){toast('키워드를 입력하세요','err');return;}
  x.busy=true;render();
  const pay=Object.assign({keyword:x.keyword,subkeyword:x.subkeyword||'',question:x.question||'',title:x.title||'',folder:x.folder,files:(x.picked&&x.files&&x.files.length)?x.files:null,hint:x.hint,model:x.model||'opus',brand:x.brand||BRAND,template:x.cardTpl||'1',portfolio:!!x.portfolio},extra||{});
  fetch('/api/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(pay)})
   .then(r=>r.json()).then(d=>{x.busy=false;
     if(!d.ok){toast(d.msg||'생성 실패','err');render();return;}
     x.post=d.post;render();toast('✍ 원고 완성','ok');
     if(d.post.cardnews_job) pollCards(d.post.cardnews_job, x);
   }).catch(e=>{x.busy=false;toast('오류: '+e,'err');render();});
}
function pollCards(job, tab){const iv=setInterval(()=>{fetch('/api/cardnews-status?id='+job).then(r=>r.json()).then(s=>{
  if(s.status=='done'){clearInterval(iv);tab.post.cardnews_pngs=s.pngs||[];tab.post.cardnews_dir=s.dir;tab.post.cardnews=s.pptx;tab.post.card_srcs=s.srcs||[];tab.post.card_state=s.cards||[];
    const ci=s.chart_imgs||{};(tab.post.blocks||[]).forEach(b=>{if(b.type=='chart'&&ci[b.cid])b.img=ci[b.cid];});   // C6: 표·차트 이미지 채우기
    if(t()===tab)render();toast('🎴 카드뉴스 '+(s.pngs||[]).length+'장 완성','ok');}
  else if(s.status=='error'){clearInterval(iv);tab.post.cardnews_png_err=s.msg||'카드 렌더 실패';if(t()===tab)render();toast('카드 렌더 실패','err');}
}).catch(()=>{});},2000);}
function renderPost(p){
  const folder=p.folder||'', cdir=p.cardnews_dir||'';
  const pngs=p.cardnews_pngs||[], useCards=pngs.length>0;
  let pi=0;
  let body=p.blocks.map((b,bi)=>{
    if(b.type=='chart'){       // C6: 표·차트 이미지
      if(b.img) return `<div class="chartwrap"><img src="/img?folder=${encodeURIComponent(cdir)}&name=${encodeURIComponent(b.img)}&v=${Date.now()}"><button class="chartdel" onclick="delChart(${bi})" title="이 표/차트 삭제">✕</button></div>`;
      return `<div class="chartpend"><span class="spin"></span> 📊 표·차트 만드는 중…<button class="chartdel" style="position:static;margin-left:10px" onclick="delChart(${bi})" title="이 표 자리 삭제">✕</button></div>`;
    }
    if(b.type=='photo'){
      const altcap=b.alt?`<div class="altcap">🏷 alt: ${esc(b.alt)}</div>`:'';
      if(useCards){
        if(pi<pngs.length){ const ci=pi; const nm=pngs[ci].split(/[\\\\/]/).pop(); pi++;
          return `<div class="cardwrap"><img id="cardimg${ci}" src="/img?folder=${encodeURIComponent(cdir)}&name=${encodeURIComponent(nm)}&v=${Date.now()}">${cardCtl(ci)}</div>${altcap}`; }
        pi++; return '';        // 카드 다 씀 — 여분 자리 숨김(빈칸 X)
      }
      pi++;
      if(b.file) return `<img src="/img?folder=${encodeURIComponent(folder)}&name=${encodeURIComponent(b.file)}">${altcap}`;
      return `<div class="pv-photo-missing">📷 사진 자리</div>${altcap}`;
    }
    return b.text.split('\n\n').map(para=>{
      const lines=para.split('\n').filter(x=>x.trim());
      if(lines.length==1 && /^\*\*.+\*\*$/.test(lines[0].trim())) return '<h3>'+esc(lines[0].replace(/\*\*/g,''))+'</h3>';
      return '<p>'+esc(para.replace(/\*\*/g,''))+'</p>';
    }).join('');
  }).join('');
  if(useCards){ while(pi<pngs.length){ const ci=pi; const nm=pngs[ci].split(/[\\\\/]/).pop(); pi++;
    body+=`<div class="cardwrap"><img id="cardimg${ci}" src="/img?folder=${encodeURIComponent(cdir)}&name=${encodeURIComponent(nm)}&v=${Date.now()}">${cardCtl(ci)}</div>`; } }
  let extra='';
  if(!pngs.length && p.cardnews_err) extra=`<div style="font-size:11px;color:#d55;margin:8px 0">카드뉴스 오류: ${esc(p.cardnews_err)}</div>`;
  else if(!pngs.length && p.cardnews_png_err) extra=`<div style="font-size:11px;color:#d55;margin:8px 0">카드 렌더 실패: ${esc(p.cardnews_png_err)}</div>`;
  else if(!pngs.length && p.cardnews_job) extra=`<div style="font-size:12px;color:var(--brand);font-weight:700;margin:8px 0"><span class="spin" style="border-color:var(--brand);border-top-color:transparent"></span> 카드뉴스 만드는 중… (원고 먼저 확인하세요. 잠시 후 본문 이미지로 채워집니다)</div>`;
  const lmin=p.len_min||1500, lmax=p.len_max||2000;
  const cc=p.char_count||0, okLen=cc>=lmin&&cc<=lmax;
  const lenmsg=(cc<lmin?(' · '+lmin+' 미달'):(cc>lmax?(' · '+lmax+' 초과'):''))+(p.trimmed?(' · 자동 축약 '+p.trimmed+'회'):'')+(p.filled?(' · 자동 보강 '+p.filled+'회'):'');
  return `<div class="pv-head"><div class="pv-title">${esc(p.title)}</div></div>
    <div class="badges">
      <span class="badge ${okLen?'ok':'warn'}">${okLen?'✓':'⚠'} 공백제외 ${cc}자${lenmsg}</span>
      ${useCards?`<span class="badge brand">🎴 카드뉴스 ${pngs.length}장</span>`:`<span class="badge">📷 본문사진 ${p.blocks.filter(b=>b.type=='photo'&&b.file).length}장</span>`}</div>
    <div class="naver-box">
      <div class="naver-title">📤 네이버 블로그로 옮기기</div>
      <div class="row" style="flex-wrap:wrap;gap:8px">
        <button class="btn pri" onclick="copyTitle()">① 제목 복사</button>
        <button class="btn pri" onclick="copyBody()">② 본문 복사</button>
        ${useCards?`<button class="btn" onclick="openFile(t().post.cardnews_dir)">③ 카드 이미지 폴더 열기</button>`:''}</div>
      <div class="naver-steps">네이버 글쓰기 열기 → <b>①</b> 제목칸에 붙여넣기 → <b>②</b> 본문에 붙여넣기 → <b>③</b> 폴더 열고 <b>${useCards?'[사진N] 자리에 card 1~'+pngs.length+'을 순서대로':'사진을'}</b> 드래그${p.crm_line?` → <b>④</b> 게시 후 아래 [게시 완료] 클릭`:''}</div>
      ${p.crm_line?`<div class="row" style="margin-top:8px"><button class="btn" onclick="crmConfirm()">📊 ④ 네이버 게시 완료 — CRM 보고</button></div>`:''}
    </div>
    <div class="row" style="margin:10px 0;flex-wrap:wrap">
      <button class="btn" onclick="saveDocx()">📄 워드로 저장</button>
      <button class="btn" onclick="generate()">↻ 다시 생성</button>
      ${(p.cardnews_dir&&(p.cardnews_pngs||[]).length)?`<button class="btn" onclick="generate({use_card_photos:true,card_dir:t().post.cardnews_dir})" title="사진 교체로 바꾼 카드 사진들을 입력 사진으로 삼아 글을 새로 씁니다">🖼 카드 사진으로 다시 생성</button>`:''}
      ${useCards?`<button class="btn" onclick="openColorPicker(event)">🎨 카드 색상 바꾸기</button>`:''}
      ${useCards?`<button class="btn" onclick="addChart()" ${t().chartBusy?'disabled':''}>${t().chartBusy?'<span class=spin></span> 표·차트 만드는 중…':'📊 표·차트 추가'}</button>`:''}</div>
    ${useCards?colorPicker(p):''}
    ${(p.sections&&p.sections.length)?editPanel(p):''}
    ${useCards?`<div class="cardsec-hint">🖱 카드에 마우스를 올리면 하단 툴바에서 <b style="color:var(--ink2)">✏️ 글 수정 · 🔄 사진 교체 · 위치 ▲▼◀▶ · 확대 ＋－</b></div>`:''}
    ${extra}
    <div class="pv-body">${body}</div>`;
}
function editPanel(p){const x=t();const sid=x.editSid||'';
  const q=x.editQueue||[]; const pending=(x.editActive?1:0)+q.length;
  const undoN=(x.undo&&x.undo.length)||0;
  return `<details class="opt editpanel" ${x.editOpen?'open':''} ontoggle="t().editOpen=this.open">
    <summary>✏️ 부분 수정 — 여러 부분을 기다리지 않고 연달아 맡기기</summary>
    <div class="editbox">
      <div class="seclabel">① 고칠 부분 선택</div>
      <div class="secbtns">${p.sections.map(s=>{
        const mk = x.editActive===s.id?'⏳ ':(q.some(e=>e.sid===s.id)?'⋯ ':'');
        return `<button class="secbtn ${s.id=='all'?'allsec':''} ${sid==s.id?'sel':''} ${mk?'run':''}" onclick="pickSec('${s.id}')">${mk}${esc(s.label)}</button>`;
      }).join('')}</div>
      <div class="seclabel">② 어떻게 고칠지 지시</div>
      <textarea id="editinstr" placeholder="예: 더 짧고 담백하게 / 구체적 사례 한 개 추가 / 이 소제목을 질문형으로" oninput="t().editInstr=this.value">${esc(x.editInstr||'')}</textarea>
      <div class="row" style="margin-top:8px;gap:8px;align-items:center;flex-wrap:wrap">
        <button class="btn pri" onclick="applyEdit()" ${!sid?'disabled':''}>➕ 이 부분 수정 맡기기</button>
        <button class="btn" onclick="undoEdit()" ${(undoN&&!pending)?'':'disabled'}>↩ 하나 전으로${undoN?' ('+undoN+')':''}</button>
        ${pending?`<span class="editq"><span class=spin></span> 처리 중 ${pending}개…</span>`:''}
      </div>
      <div class="edithint">기다릴 필요 없어요 — 한 부분 맡기고 바로 다음 부분을 골라 또 맡기면 순서대로 반영됩니다.</div>
    </div></details>`;
}
function pickSec(id){t().editSid=id;render();setTimeout(()=>{const e=el('editinstr');if(e)e.focus();},0);}
function undoEdit(){const x=t();if(x.editActive||(x.editQueue&&x.editQueue.length)){toast('처리 중엔 되돌릴 수 없어요','err');return;}
  if(x.undo&&x.undo.length){x.post=x.undo.pop();toast('↩ 되돌렸어요','ok');render();}}
function applyEdit(){const x=t();const sid=x.editSid;const instr=(x.editInstr||'').trim();
  if(!sid){toast('고칠 부분을 먼저 고르세요','err');return;}
  if(!instr){toast('어떻게 고칠지 입력하세요','err');return;}
  (x.editQueue=x.editQueue||[]).push({sid,instr});
  x.editInstr='';                       // 입력 비워서 다음 부분 바로 지시 가능
  toast('➕ 대기열에 추가 — 계속 다른 부분도 맡기세요','ok');
  render();
  runEditQueue(x);
}
function runEditQueue(tab){
  if(tab.editActive) return;             // 순차 처리 — 이미 하나 처리 중이면 대기
  const q=tab.editQueue||[];
  if(!q.length){ if(tab===t())render(); return; }
  const job=q.shift(); tab.editActive=job.sid;
  if(tab===t())render();
  fetch('/api/edit-section',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({post:tab.post,section:job.sid,instruction:job.instr,brand:tab.brand||BRAND,model:tab.model||'opus'})})
   .then(r=>r.json()).then(d=>{
     if(d.ok){(tab.undo=tab.undo||[]).push(tab.post);if(tab.undo.length>30)tab.undo.shift();tab.post=d.post;toast('✏️ 한 부분 반영됨','ok');}
     else toast(d.msg||'수정 실패','err');
     tab.editActive=null; if(tab===t())render();
     runEditQueue(tab);                  // 다음 대기 작업 이어서
   }).catch(()=>{tab.editActive=null;toast('수정 실패(네트워크)','err');if(tab===t())render();runEditQueue(tab);});
}
const CPAL=['#111111','#4B4B4B','#8A8A8A','#C4C4C4','#E9ECEF',
  '#F5A9A9','#F7DE9A','#BCE3AE','#A5DAD0','#AECBFA','#B7B1E8','#DBB7E3',
  '#F0806A','#F6B93B','#7FB069','#2FA69A','#4C9BE8','#6C79D6','#B072C4',
  '#E24A34','#E1730F','#3E7D33','#188A7B','#1668C7','#3B44A0','#7A2E9B'];
function colorPicker(p){const x=t();if(!x.colorOpen)return '';
  const cur=x.cardColor||'#63794B';
  return `<div class="cpick" onclick="event.stopPropagation()">
    <div class="cpick-h">🎨 이 글 카드 전체 색상 바꾸기</div>
    <div class="cpick-sw">${CPAL.map(c=>`<button class="cpsw" style="background:${c}" onclick="pickColor('${c}')" title="${c}"></button>`).join('')}</div>
    <div class="cpick-row">
      <label class="cpspec" title="색상환에서 직접 고르기"><input type="color" value="${cur}" onchange="pickColor(this.value)"><span>🌈 색상환</span></label>
      <div class="cphex"><span>#</span><input id="cphex" maxlength="6" value="${cur.replace('#','')}" onkeydown="if(event.key==='Enter')pickColor('#'+this.value)" placeholder="RRGGBB"></div>
      <button class="btn sm" onclick="pickColor('#'+el('cphex').value)">적용</button>
      <button class="cpdrop" onclick="pickEyedropper()" title="화면에서 색 추출(스포이드)">🔎 스포이드</button>
      ${x.colorBusy?'<span class="cpbusy"><span class=spin></span> 바꾸는 중…</span>':''}
    </div></div>`;
}
function openColorPicker(e){if(e)e.stopPropagation();const x=t();x.colorOpen=!x.colorOpen;render();}
function pickColor(hex){hex=(hex||'').trim();if(hex[0]!=='#')hex='#'+hex;
  if(!/^#[0-9a-fA-F]{6}$/.test(hex)){toast('색상 코드가 올바르지 않아요 (예: #3B82F6)','err');return;}
  applyCardColor(hex);}
function applyCardColor(hex){const x=t();const p=x.post;
  if(!p||!p.cardnews_dir){toast('먼저 카드뉴스를 만들어 주세요','err');return;}
  x.cardColor=hex;x.colorBusy=true;render();
  const cs=p.chart_specs||{};   // 표·차트도 같은 색으로 다시 그리도록 함께 보냄
  const charts=(p.blocks||[]).filter(b=>b.type=='chart'&&b.img).map(b=>({cid:b.cid,img:b.img,spec:b.spec||cs[b.cid]||null})).filter(c=>c.spec);
  fetch('/api/recolor-cards',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cardnews_dir:p.cardnews_dir,color:hex,brand:x.brand||p.brand||BRAND,charts})})
   .then(r=>r.json()).then(d=>{x.colorBusy=false;
     if(d.ok){p.cardnews_pngs=(d.pngs||[]).slice();x.cardColor='#'+d.color;toast(d.msg||(d.charts?'🎨 카드·표 색이 바뀌었어요':'🎨 카드 색이 바뀌었어요'),'ok');}
     else toast(d.msg||'색 변경 실패','err');
     render();
   }).catch(()=>{x.colorBusy=false;toast('색 변경 실패(네트워크)','err');render();});
}
async function pickEyedropper(){
  if(!window.EyeDropper){toast('이 브라우저는 스포이드를 지원하지 않아요(색상환·팔레트를 쓰세요)','err');return;}
  try{const r=await new EyeDropper().open();pickColor(r.sRGBHex);}catch(e){}
}
function copyClip(text,msg){const done=()=>toast(msg,'ok');
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(done).catch(()=>fallbackCopy(text,done));}
  else fallbackCopy(text,done);}
function fallbackCopy(text,done){const ta=document.createElement('textarea');ta.value=text;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();try{document.execCommand('copy');done();}catch(e){toast('복사 실패','err');}document.body.removeChild(ta);}
function copyTitle(){copyClip(t().post.title||'','① 제목 복사됨 · 네이버 제목칸에 붙여넣기');}
function crmConfirm(){const x=t();const p=x.post;if(!p)return;
  const u=prompt('게시한 네이버 글 URL을 붙여넣어 주세요 (예: https://blog.naver.com/gnsl0091/224…)','');
  if(u===null)return;
  fetch('/api/crm-post',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({brand:x.brand||BRAND,title:p.title||'',keyword:p.keyword||x.keyword||'',url:(u||'').trim()})})
   .then(r=>r.json()).then(d=>toast(d.ok?'📊 CRM 게시 현황에 보고됐어요':'CRM 보고 실패: '+(d.msg||'?'),d.ok?'ok':'err'))
   .catch(e=>toast('CRM 보고 실패: '+e,'err'));}
function copyBody(){const p=t().post;const pngs=p.cardnews_pngs||[],useCards=pngs.length>0;let pi=0;const out=[];
  let ti=0;
  p.blocks.forEach(b=>{
    if(b.type=='chart'){ if(b.img){ti++;out.push('📊 [표차트'+ti+']');} }
    else if(b.type=='photo'){
      const altx=b.alt?'  (alt: '+b.alt+')':'';
      if(useCards){if(pi<pngs.length){pi++;out.push('📷 [사진'+pi+']'+altx);}else pi++;}
      else out.push('📷 [사진]'+altx);
    } else { b.text.split('\n\n').forEach(para=>{const tx=para.replace(/\*\*/g,'').trim();if(tx)out.push(tx);}); }
  });
  if(useCards){while(pi<pngs.length){pi++;out.push('📷 [사진'+pi+']');}}
  try{ if(p.crm_line){ out.push(p.crm_line); } }catch(e){}
  copyClip(out.join('\n\n'),'② 본문 복사됨 · [사진N]자리에 카드, [표차트N]자리에 표·차트 이미지를 드래그');}
function delChart(bi){const x=t();const b=x.post.blocks[bi];if(!b||b.type!='chart')return;
  x.post.blocks.splice(bi,1);toast('표·차트 삭제됨','ok');render();}
function addChart(){const x=t();const p=x.post;
  if(!p||!p.cardnews_dir){toast('카드뉴스가 만들어진 뒤에 추가할 수 있어요','err');return;}
  x.chartBusy=true;render();
  fetch('/api/add-chart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({post:p,brand:x.brand||BRAND,model:x.model||'opus'})})
   .then(r=>r.json()).then(d=>{x.chartBusy=false;
     if(d.ok){x.post=d.post;toast('📊 표·차트 추가됨','ok');}else toast(d.msg||'추가 실패','err');
     render();
   }).catch(()=>{x.chartBusy=false;toast('추가 실패(네트워크)','err');render();});}
function saveDocx(){toast('📄 워드 저장 중…');fetch('/api/docx',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({post:t().post})})
  .then(r=>r.json()).then(d=>{if(d.ok)toast('📄 워드 저장됨 · 파일이 열립니다','ok');else toast(d.msg||'저장 실패','err');});}
function openFile(p){fetch('/api/open',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:p})}).then(r=>r.json()).then(d=>{if(!d.ok)toast('파일을 열 수 없습니다','err');});}
function closeSwap(){el('swapmodal').style.display='none';}   // (레거시 그리드 — 미사용)
function openSwap(ci){   // 네이티브 Windows 파일 선택창으로 바로 교체(썸네일 그리드 렉 제거)
  toast('📂 사진 선택 창을 여는 중…');
  fetch('/api/pick-file',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({folder:t().folder})})
   .then(r=>r.json()).then(d=>{
     if(!d.ok||!d.path)return;                       // 취소
     const x=t().post; toast('🔄 교체 중…');
     fetch('/api/swap-card',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cardnews_dir:x.cardnews_dir,path:d.path,index:ci})})
      .then(r=>r.json()).then(s=>{
        if(!s.ok){toast(s.msg||'교체 실패','err');return;}
        (x.card_srcs=x.card_srcs||[])[ci]=s.src||'';       // 교체된 원본 기억(위치조정용)
        (x.card_adj=x.card_adj||{})[ci]={cx:.5,cy:.5,zoom:1};
        const img=el('cardimg'+ci); if(img) img.src='/img?folder='+encodeURIComponent(x.cardnews_dir)+'&name='+encodeURIComponent(s.name)+'&v='+Date.now();
        toast('🔄 사진 교체됨','ok');
      }).catch(e=>toast('오류: '+e,'err'));
   }).catch(e=>toast('오류: '+e,'err'));
}
// ── 카드별 위치 이동 / 확대 ──
function cardCtl(ci){return `<div class="cardbar">
  <button class="tb" onclick="openTextEdit(${ci})" title="카드 글 수정">✏️ 글</button>
  <button class="tb" onclick="openSwap(${ci})" title="사진 교체">🔄 사진</button>
  <span class="sep"></span>
  <button onclick="nudge(${ci},0,-.08)" title="위로">▲</button>
  <button onclick="nudge(${ci},-.08,0)" title="왼쪽">◀</button>
  <button onclick="resetCard(${ci})" title="가운데/초기화">⟳</button>
  <button onclick="nudge(${ci},.08,0)" title="오른쪽">▶</button>
  <button onclick="nudge(${ci},0,.08)" title="아래로">▼</button>
  <span class="sep"></span>
  <button onclick="zoomCard(${ci},.15)" title="확대">＋</button>
  <button onclick="zoomCard(${ci},-.15)" title="축소">－</button></div>`;}
function _adj(ci){const x=t().post;const A=(x.card_adj=x.card_adj||{});return A[ci]||(A[ci]={cx:.5,cy:.5,zoom:1});}
function nudge(ci,dx,dy){const a=_adj(ci);a.cx=Math.max(0,Math.min(1,a.cx+dx));a.cy=Math.max(0,Math.min(1,a.cy+dy));adjustCard(ci);}
function zoomCard(ci,dz){const a=_adj(ci);a.zoom=Math.max(1,Math.min(2.5,(a.zoom||1)+dz));adjustCard(ci);}
function resetCard(ci){const x=t().post;(x.card_adj=x.card_adj||{})[ci]={cx:.5,cy:.5,zoom:1};adjustCard(ci);}
function adjustCard(ci){const x=t().post;const a=_adj(ci);const src=(x.card_srcs||[])[ci]||'';
  if(!src){toast('이 카드는 [🔄 사진 교체]를 한 번 누른 뒤 조정돼요','err');return;}
  const img=el('cardimg'+ci); if(img)img.style.opacity='.4';
  fetch('/api/adjust-card',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pptx:x.cardnews,cardnews_dir:x.cardnews_dir,src:src,index:ci,cx:a.cx,cy:a.cy,zoom:a.zoom})})
   .then(r=>r.json()).then(d=>{if(img)img.style.opacity='1';
     if(!d.ok){toast(d.msg||'조정 실패','err');return;}
     if(img)img.src='/img?folder='+encodeURIComponent(x.cardnews_dir)+'&name='+encodeURIComponent(d.name)+'&v='+Date.now();
   }).catch(e=>{if(img)img.style.opacity='1';toast('오류: '+e,'err');});}
// ── 카드 글 수정 ──
let TXT_CI=0;
function openTextEdit(ci){TXT_CI=ci;const x=t().post;const c=(x.card_state||[])[ci]||{};
  const flds=c.fields||[];const lbl={title:'제목 (블로그 글 제목)',headline:'헤드라인',subtitle:'부제',body:'본문 설명'};
  let html='';
  flds.forEach(f=>{const big=(f=='body'||f=='title');
    html+=`<div class="field"><label>${lbl[f]||f}</label>${big?`<textarea id="tx_${f}" style="height:64px">${esc(c[f]||'')}</textarea>`:`<input type="text" id="tx_${f}" value="${esc(c[f]||'')}">`}</div>`;});
  if(!flds.length) html='<div style="color:#889;font-size:13px;padding:6px 0">이 카드는 글자가 없는 디자인이에요 (사진만). 🔄 사진 교체를 써주세요.</div>';
  el('txtfields').innerHTML=html;el('textmodal').style.display='block';
  const first=el('tx_'+(flds[0]||'')); if(first)setTimeout(()=>first.focus(),50);}
function applyText(){const x=t().post;const c=(x.card_state||[])[TXT_CI]||{};const flds=c.fields||[];
  const body={cardnews_dir:x.cardnews_dir,index:TXT_CI};
  flds.forEach(f=>{const e=el('tx_'+f);if(e){body[f]=e.value;c[f]=e.value;}});
  fetch('/api/card-text',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
   .then(r=>r.json()).then(d=>{if(!d.ok){toast(d.msg||'수정 실패','err');return;}
     const img=el('cardimg'+TXT_CI);if(img)img.src='/img?folder='+encodeURIComponent(x.cardnews_dir)+'&name='+encodeURIComponent(d.name)+'&v='+Date.now();
     el('textmodal').style.display='none';toast('✏️ 글 수정됨','ok');}).catch(e=>toast('오류: '+e,'err'));}
// ── 카드 미리보기 (최종 체크용) ──
function pvBrandOptions(cur){return '<select onchange="openCardPreview(this.value)" style="border:1.5px solid var(--line);border-radius:9px;padding:6px 9px;font-size:12px;font-weight:700">'+
  BRANDS.filter(b=>b.has_cards).map(b=>`<option value="${b.id}" ${b.id==cur?'selected':''}>${esc(b.name)}</option>`).join('')+'</select>';}
function previewTpl(){openCardPreview(BRAND,(t().cardTpl||'1'));}
function openCardPreview(bid,tpl){tpl=tpl||'1';el('previewmodal').style.display='block';el('pvbrandsel').innerHTML=pvBrandOptions(bid);
  el('pvtitle').textContent='🎴 카드 미리보기';
  el('pvgrid').innerHTML='<div style="padding:44px;color:#889;font-size:13px"><span class="spin" style="border-color:var(--brand);border-top-color:transparent;margin-right:8px"></span>샘플 사진으로 카드 그리는 중…</div>';
  const folder=(t()&&t().folder)||'';
  fetch('/api/preview-cards',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({brand:bid,folder:folder,template:tpl})})
   .then(r=>r.json()).then(d=>{if(!d.ok){el('pvgrid').innerHTML='<div style="padding:24px;color:#d55">'+esc(d.msg||'실패')+'</div>';return;}
     el('pvtitle').textContent='🎴 '+d.name+' 카드 미리보기 ('+d.pngs.length+'장)';
     el('pvgrid').innerHTML=d.pngs.map((p,i)=>{const nm=p.split(/[\\\\/]/).pop();
       return '<div style="text-align:center"><img src="/img?folder='+encodeURIComponent(d.dir)+'&name='+encodeURIComponent(nm)+'&v='+Date.now()+'" style="width:224px;height:224px;object-fit:cover;border-radius:13px;box-shadow:var(--sh)"><div style="font-size:11px;color:#889;margin-top:5px;font-weight:700">'+(i==0?'표지':'카드 '+(i+1))+'</div></div>';}).join('');
   }).catch(e=>{el('pvgrid').innerHTML='<div style="padding:24px;color:#d55">오류: '+e+'</div>';});}
// ── 브랜드 관리 모달 ──
function openBrandMgr(){el('brandmodal').style.display='block';BFORM=null;loadBrands(renderBrandMgr);}
function closeBrandMgr(){el('brandmodal').style.display='none';loadBrands();}
function renderBrandMgr(){
  if(BFORM){renderBrandForm();return;}
  el('brandbody').innerHTML=`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
    ${BRANDS.map(b=>`<button class="btn" onclick="editBrand('${b.id}')"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${b.color};margin-right:7px;vertical-align:-1px"></span>${esc(b.name)} ${b.has_cards?'🎴':''}</button>`).join('')}
    <button class="btn pri" onclick="newBrand()">+ 새 브랜드</button></div>
    <div class="row" style="margin-bottom:12px;flex-wrap:wrap"><button class="btn" onclick="syncBrands()">🔗 통검 브랜드 동기화</button>
      <button class="btn pri" onclick="openCardPreview((BRANDS.find(b=>b.has_cards)||{}).id||'haofactory')">🎴 카드 미리보기 (최종 체크)</button></div>
    <div style="font-size:12px;color:var(--muted)">브랜드를 클릭하면 설정을 수정합니다 · 🎴 = 카드 템플릿 등록됨</div>`;
}
function syncBrands(){toast('🔗 통검 브랜드 동기화 중…');
  fetch('/api/sync-brands',{method:'POST'}).then(r=>r.json()).then(d=>{
    toast('🔗 동기화 완료 · 추가 '+(d.added||[]).length+'개 · 연결 '+(d.linked||[]).length+'개','ok');
    loadBrands(renderBrandMgr);}).catch(e=>toast('오류: '+e,'err'));}
function newBrand(){BFORM={id:'',name:'',homepage:'',color:'#3B82F6',industry:'',tone:'',sections:'',extra:'',cta:'',type_words:'',card_headlines:'',tonggeom:''};renderBrandForm();}
function editBrand(id){fetch('/api/brand?id='+id).then(r=>r.json()).then(b=>{
  BFORM=Object.assign({},b,{type_words:(b.type_words||[]).join(', '),card_headlines:(b.card_headlines||[]).join('\n')});renderBrandForm();});}
function renderBrandForm(){const b=BFORM;
  const fi=(label,key,ph)=>`<div class="field"><label>${label}</label><input type="text" id="bf_${key}" value="${esc(b[key]||'')}" placeholder="${esc(ph||'')}"></div>`;
  const fa=(label,key,ph)=>`<div class="field"><label>${label}</label><textarea id="bf_${key}" placeholder="${esc(ph||'')}">${esc(b[key]||'')}</textarea></div>`;
  el('brandbody').innerHTML=`
    <div class="row" style="margin-bottom:12px"><button class="btn" onclick="BFORM=null;renderBrandMgr()">← 목록</button>
      <b style="font-size:14px">${b.id?esc(b.name)+' 수정':'새 브랜드'}</b></div>
    <div class="row" style="align-items:flex-end">${fi('브랜드 이름 *','name','예: 퍼스트디자인')}
      <div class="field" style="width:130px"><label>브랜드색</label><input type="text" id="bf_color" value="${esc(b.color||'#3B82F6')}" placeholder="#3B82F6"></div></div>
    <div class="row">${fi('글 속 표기명 (비우면 이름)','label','예: FIRST DESIGN')}
      ${fi('홈페이지 (추천키워드 기준)','homepage','firstd.co.kr')}</div>
    ${fi('업종 (한 줄)','industry','예: 기업 디자인 파트너')}
    <div style="font-size:11.5px;color:var(--muted);font-weight:700;margin:6px 0 2px">▼ 구조(소제목6·제목키워드·SEO)는 전 브랜드 공통. 아래 톤·내용만 브랜드별로 다릅니다.</div>
    ${fa('🏢 회사 소개 · 서비스 · 강점','identity','예: OO는 기획부터 제작까지 원스톱으로 진행하는 회사다. 카탈로그·포스터·패키지·촬영을 다루고 다국어 디자인이 가능하다. ...')}
    ${fa('🗣 문체/톤','tone','예: 친근한 구어체 ~해요/:). 고객 말 큰따옴표 인용. (또는) 정중·신뢰 톤, 이모티콘 절제.')}
    ${fa('🏁 마무리 CTA','cta','예: 메인키워드 제대로 하고 싶다면 OO에서 시작해보세요! 식으로 마무리.')}
    <div style="border-top:1px solid var(--line2);margin:10px 0 12px"></div>
    ${fi('타입 단어 (콤마 — 사진 매칭·정리용)','type_words','예: 카탈로그, 포스터, 전단지, 명함, 패키지')}
    ${fa('카드 헤드라인 7줄 (선택)','card_headlines','표지\\n후킹\\n이유\\n강점\\n품질\\n과정\\n마무리')}
    ${fi('통검체크 dist 폴더 (선택 — 동기화로 자동입력)','tonggeom','C:/Users/.../브랜드 통검체크')}
    <details style="margin-top:10px"><summary style="font-size:12px;color:var(--muted);cursor:pointer">고급: 완전 커스텀 프롬프트 (있으면 위 설정 대신 이걸 사용)</summary>
      <textarea id="bf_prompt" style="height:120px;font-size:12px;margin-top:8px" placeholder="구조까지 완전히 직접 쓰고 싶을 때만. 비우면 공통 구조 + 위 톤/회사소개를 사용합니다.">${esc(b.prompt||'')}</textarea></details>
    <div class="row" style="margin-top:10px;flex-wrap:wrap"><button class="btn pri" onclick="saveBrand()">💾 저장</button>
      ${b.id&&b.has_cards?`<button class="btn" onclick="openCardPreview('${b.id}')">👁 카드 미리보기</button>`:''}</div>
    ${b.id?`<div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap;align-items:center">
      <span style="font-size:12px;color:var(--muted);font-weight:700">카드 디자인 (PPTX, 여러 개면 생성 시 선택):</span>
      ${['1','2','3'].map(s=>{const has=(b.card_templates||[]).includes(s);return `<button class="btn" onclick="openTemplate('${b.id}','${s}')">${has?'🎴':'＋'} 디자인 ${s} ${has?'교체':'등록'}</button>`;}).join('')}
     </div>`:'<div style="margin-top:10px;font-size:12px;color:var(--muted)">먼저 저장하면 카드 템플릿(PPTX)을 등록할 수 있어요</div>'}`;
}
function bval(k){const e=el('bf_'+k);return e?e.value:'';}
function saveBrand(){const cfg={id:BFORM.id||'',name:bval('name'),label:bval('label'),color:bval('color'),homepage:bval('homepage'),industry:bval('industry'),
   identity:bval('identity'),tone:bval('tone'),cta:bval('cta'),prompt:bval('prompt'),type_words:bval('type_words'),card_headlines:bval('card_headlines'),tonggeom:bval('tonggeom'),stages:BFORM.stages};
  if(!cfg.name.trim()){toast('브랜드 이름을 입력하세요','err');return;}
  fetch('/api/brand-save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(cfg)})
   .then(r=>r.json()).then(d=>{if(!d.ok){toast(d.msg||'저장 실패','err');return;}
     toast('💾 저장됨: '+d.brand.name,'ok');
     BFORM=Object.assign({},d.brand,{type_words:(d.brand.type_words||[]).join(', '),card_headlines:(d.brand.card_headlines||[]).join('\n')});
     BRAND=d.id;loadBrands(renderBrandForm);});}
function openTemplate(id,slot){slot=slot||'1';const inp=document.createElement('input');inp.type='file';inp.accept='.pptx';
  inp.onchange=()=>{const f=inp.files[0];if(!f)return;toast('🎴 디자인 '+slot+' 업로드·추출 중…');
    const fd=new FormData();fd.append('id',id);fd.append('slot',slot);fd.append('file',f);
    fetch('/api/brand-template-file',{method:'POST',body:fd}).then(r=>r.json()).then(d=>{
      if(!d.ok){toast(d.msg||'추출 실패','err');return;}
      toast('🎴 디자인 '+(d.slot||slot)+' 등록됨 ('+d.slides+'장, 장식 '+d.assets+'개)','ok');loadBrands(()=>editBrand(id));});};
  inp.click();}
init();
</script></body></html>"""

URL = "http://127.0.0.1:5002"


def main():
    """런처(launcher.py) 진입점 — 자동업데이트 후 이 함수를 호출."""
    if "--noopen" not in sys.argv:
        threading.Thread(target=lambda: (time.sleep(1.2), webbrowser.open(URL)), daemon=True).start()
    print("블로그 작성기 →", URL, " (engine:", CLAUDE or "없음", ")")
    app.run(host="127.0.0.1", port=5002, threaded=True)


if __name__ == "__main__":
    main()
